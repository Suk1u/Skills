---
name: swiftui-ios26-hig-pro
description: >
  Build, modify, migrate, and review SwiftUI interfaces for iOS 26/27 with Apple HIG,
  Liquid Glass, modern SwiftUI APIs, adaptive layout, accessibility, localization,
  data flow, navigation, and performance. Use whenever the user mentions SwiftUI,
  an iOS or iPadOS interface, Liquid Glass, Tab Bar, Toolbar, Sidebar, iPhone Duo,
  resizable windows, HIG compliance, or asks to review SwiftUI code, even when they
  do not name this skill. Also use for standalone SwiftUI prototypes that must look
  native on current Apple platforms.
license: MIT
metadata:
  version: "1.0.0"
  authors: "Merged from Paul Hudson's SwiftUI Pro and the attached iOS 26+ UI guide"
  sourceSwiftUIPro: "https://github.com/twostraws/SwiftUI-Agent-Skill"
  sourceSwiftUIProCommit: "ce32af1693b9e78a7d22ff48001c97a304d32063"
  sourceHIGGuide: "User-supplied iOS 26+ UI guide"
---

# SwiftUI iOS 26 HIG Pro

Use this skill for two related jobs:

1. Implement or revise production SwiftUI that follows current Apple platform guidance.
2. Review Swift/SwiftUI code for modern API use, correctness, accessibility, adaptability, and performance.

The goal is not to force every project into the newest style. The goal is native,
maintainable behavior within the project's actual SDK, deployment target, and scope.

## Operating World State

- iOS 26 introduced the Liquid Glass design system. iOS 27 continues it, and an app
  built with the iOS 27 SDK cannot retain the old appearance through compatibility keys.
- Treat iOS 27 APIs such as `GlassEffectContainer`, `ToolbarOverflowMenu`,
  `visibilityPriority(_:)`, `.topBarPinnedTrailing`, `ArrangementView`, and iPhone Duo
  vertical bars as real APIs, not speculation.
- Xcode 27.1 and the corresponding platform releases are available. The project may
  still intentionally use an older SDK or deployment target.
- Check the project before recommending version-specific code. A runtime `#available`
  branch cannot make an older SDK recognize a declaration that does not exist.
- Do not bump deployment targets, Swift language versions, project settings, or
  third-party dependencies without an explicit request.

## First Pass

Inspect the smallest useful part of the project before writing code:

- deployment target, SDK/toolchain, Swift language mode, and platform families;
- current design language, fonts, colors, spacing, state ownership, and folder structure;
- whether the task is UI generation, focused edit, migration, design guidance, or review;
- whether Xcode previews, the Swift compiler, or Xcode MCP tools are available for verification.

Preserve existing behavior and working conventions. Prefer native SwiftUI and system
components over custom approximations. Complete the requested change; report unrelated
modernization separately rather than applying it silently.

## Choose The Mode

### Implement or edit

- Follow the existing project structure, one primary type per file, and established helpers.
- Put view layout in `body`; move button actions and business logic into methods or models.
- Use native controls and semantic styles before custom drawing or styling.
- Separate the functional layer (navigation, bars, sheets, menus) from the content layer.
- Keep window-specific navigation and selection state at the scene root.
- When changing shared behavior, run the relevant build/tests and report exactly what was verified.

### Standalone prototype

- Prefer a single compilable file only when there is no host project or the user asks for a demo.
- Add an SDK/toolchain note, availability guards, and a `#Preview`.
- Use the four-part delivery below unless the user requests another format.

### Review

- Report only genuine issues: correctness, deprecations, accessibility failures,
  adaptive-layout breakage, data-flow defects, and measured or strongly indicated performance risks.
- Organize findings by file, with line references, the violated rule, and concise
  before/after code. Order findings by impact and end with a short summary.
- Skip clean files. Do not invent issues to fill a template.
- Leave large architectural changes, public helper removal, project settings, and
  third-party additions as recommendations unless requested.

### Design guidance

- Describe the component hierarchy, functional/content split, adaptive behavior,
  accessibility, and version-gated APIs.
- Do not produce unrelated source files when the user only asked for a design decision or specification.

## Build Rules

Apply these throughout implementation:

- Use Liquid Glass only for the functional layer. Content uses standard materials,
  semantic colors, imagery, and scrolling content.
- Never hand-roll glass with blur, gradients, opacity, Canvas, shaders, or third-party
  libraries. Use the native SwiftUI Liquid Glass APIs only when the project's SDK supports them.
- Prefer system bars, sheets, popovers, alerts, menus, and controls so the system
  handles Liquid Glass, safe areas, folds, cameras, and overflow.
- Use semantic fonts, colors, and spacing. Support light/dark, Dynamic Type, Increased
  Contrast, Reduce Transparency, Reduce Motion, VoiceOver, and keyboard/switch access.
- Base adaptation on horizontal/vertical size classes and available window space.
  Do not use device idiom, orientation, or `UIScreen.main` as a layout proxy.
- Keep interactive targets at least 44x44 pt on iOS and iPadOS, and 60x60 pt on visionOS.
- Give icon-only controls text labels. Use `.labelStyle(.iconOnly)` only when the visual
  must stay compact while VoiceOver text remains.
- Do not use color as the sole carrier of meaning. Pair it with text, icons, patterns, or shape.
- Use `NavigationStack` or `NavigationSplitView`; use `Tab` for tabs and semantic
  toolbar placements for actions.
- Keep section headers in normal title case. Never call `.uppercased()` merely to style a header.
- Use 120-240 ms transitions as a starting range, animate transform/opacity where
  possible, and replace large motion with opacity when Reduce Motion is on.
- Never concatenate `Text` values; preserve localization through interpolation.
- Keep derived work, filters, sorting, and expensive formatters out of frequently
  evaluated view bodies when they can be cached or moved.
- Avoid `AnyView`, index-based identity for mutable collections, force unwraps,
  Grand Central Dispatch, and unnecessary UIKit wrappers.

## Version Gates

Use the narrowest correct gate:

- Runtime API: deployment target check plus `if #available(iOS 26, *)` or `if #available(iOS 27, *)`.
- Toolchain-only API: requires the relevant Xcode/Swift compiler even if it has no
  iOS deployment restriction. Do not fake this with `#available`.
- Existing target below the API minimum: keep the old implementation and add a guarded
  enhancement only when the requested behavior needs it.
- New project with an explicitly requested current target: use iOS 26+ or iOS 27+
  APIs directly and keep availability debt low.

When exact API availability is uncertain, inspect the local SDK or Apple documentation.
A warning-free build does not prove an API is current because many SwiftUI declarations
are soft-deprecated.

## Reference Routing

Load only references relevant to the current job. Paths are relative to this skill.

### Visual system and components

- `references/hig-liquid-glass.md` - Liquid Glass layers, materials, color, layout,
  typography, motion, SF Symbols, app icons, and the visual-system checklist.
- `references/hig-components.md` - tabs, toolbars, sidebars, buttons, sheets,
  lists/forms, search, scroll effects, menus, windows, and iPhone Duo behavior.
- `references/design.md` - shared design tokens, system styling, flexible frames,
  concentric corners, and accessible visual hierarchy.
- `references/resizability.md` - size classes, safe areas, iPad windows, folding,
  reserved regions, arrangements, and vertical bars.

### Code correctness and modernization

- `references/api.md` - modern API substitutions, soft deprecations, toolbars, and Xcode-gated changes.
- `references/views.md` - view composition, animation, reordering, and swipe actions.
- `references/data.md` - observation, state ownership, bindings, identity, and SwiftData.
- `references/navigation.md` - navigation stacks/splits and data-driven presentations.
- `references/swift.md` - modern Swift, Foundation, formatting, and concurrency.
- `references/hygiene.md` - secrets, tests, launch screens, resizing declarations, and build cleanliness.

### Product quality

- `references/accessibility.md` - Dynamic Type, VoiceOver, Reduce Motion, labels, and color differentiation.
- `references/localization.md` - string resources, generated symbols, locale, calendar, and time zone.
- `references/performance.md` - view identity, lazy containers, observation cost, and update behavior.
- `references/performance-plus.md` - invasive structural optimization. Load only for a
  requested deep performance review or a demonstrated update-frequency problem.

For a general review, read the relevant correctness references rather than all files at
once. For a visual task, read both HIG references plus `design.md` and `resizability.md`.
For a focused accessibility review, read only `accessibility.md` and the view code.

## Standalone Delivery Format

For a from-scratch prototype or when the user asks for a complete UI deliverable, use:

1. **Architecture**: target platform/SDK, functional versus content layer, state flow,
   adaptive behavior, and version-gated APIs.
2. **Implementation**: complete compilable SwiftUI source, or the actual project files
   when working in a repository.
3. **Design and accessibility**: Liquid Glass choices, color strategy, Dynamic Type,
   labels, values, hints, and Reduce Motion behavior.
4. **Compatibility and verification**: iOS 26/27 fallbacks, build/preview/test results,
   and any manual checks still required.

For edits inside an existing project, do not force the four-part response. Make the
change, summarize the affected behavior, and report verification.

## Final Checks

- Does the code use the project's real SDK and deployment target?
- Is Liquid Glass confined to native functional surfaces with no polyfill?
- Does the interface adapt to narrow/short windows, iPad resizing, and iPhone Duo?
- Are state ownership, navigation, row identity, and animation value-bound correctly?
- Are controls named, readable, and at least the minimum touch target?
- Are text, dates, numbers, and lists locale-aware?
- Is expensive work outside repeated body evaluation?
- Were irrelevant modernizations and project-setting changes left alone?
- If code could not be built or previewed, is that stated plainly?

# Liquid Glass And iOS 26/27 Visual System

Use this reference when choosing materials, color, hierarchy, typography, motion,
icons, or app assets. Read `hig-components.md` for component behavior.

## Platform Direction

- iOS 26 introduced Liquid Glass as a functional layer that floats above content.
- iOS 27 removes the effective compatibility escape when built with the iOS 27 SDK.
- Liquid Glass is not a generic card background. It is part of navigation, controls,
  menus, sheets, sidebars, toolbars, and other functional surfaces.
- System components adopt the material automatically. Add APIs only when a custom
  functional surface needs the same behavior.

## Two-Layer Model

### Functional layer

Tab bars, toolbars, sidebars, menus, alerts, sheets, popovers, and custom controls use
native Liquid Glass or system materials. Content remains visible beneath them and the
system manages legibility.

### Content layer

Scrollable content, images, media, charts, text, and data surfaces use standard
materials and semantic colors. Do not put `.glassEffect()` on ordinary cards, rows,
content backgrounds, or every button.

## Materials

### Regular

Use the default regular glass for most functional surfaces, especially those containing
text or appearing over busy content. It preserves legibility while allowing context
to show through.

### Clear

Clear glass is appropriate only over media such as photos or video when the content
should remain prominent. If the underlying media is bright, add an intentional dark
scrim; if it is already dark or the system media controls provide their own scrim,
do not add another.

### Content materials

Use `.ultraThinMaterial`, `.thinMaterial`, `.regularMaterial`, or `.thickMaterial` for
content-layer separation. These are not substitutes for Liquid Glass.

## Native APIs Only

For iOS 26+, use native declarations such as:

- `.glassEffect()`, `.glassEffect(.regular)`, `.glassEffect(.clear)`;
- `GlassEffectContainer(spacing:)` for related custom glass elements;
- `.glassEffectID(_:in:)` for coordinated transitions;
- `.buttonStyle(.glass)` and `.buttonStyle(.glassProminent)` when a native glass button is appropriate.

Never create a `glassEffect` extension, fake refraction with Canvas or gradients,
simulate glass with `.ultraThinMaterial`, or add a third-party glass library.

Prefer system toolbar, tab, sheet, menu, and popover components over custom glass
containers. Use `GlassEffectContainer` to group custom controls, not as decoration.

## Color

- Apply color sparingly to functional glass. Use it to emphasize one or two important actions.
- Communicate primary actions through a tinted background where the platform supports it,
  not by coloring every icon or label.
- Use semantic colors: `.primary`, `.secondary`, `.tint`, `Color(.systemBackground)`,
  `Color(.secondarySystemBackground)`, and `Color(.separator)`.
- Brand color belongs primarily in the content layer. Functional bars normally stay monochrome.
- Provide light and dark variants for custom colors, and verify Increased Contrast.
- Never use color alone to distinguish state, category, or error.
- Keep text and controls legible against both static and scrolling content.

## Hierarchy And Backgrounds

- Let imagery and content extend beneath system bars rather than placing solid bars above them.
- On iOS 26+, use `backgroundExtensionEffect()` for the recommended mirrored/blurred
  extension behind sidebars, inspectors, or vertical bars.
- Use unqualified `ignoresSafeArea()` for decoration and backgrounds. Limit it to
  specific edges for readable or interactive content.
- Use `safeAreaBar()` for custom bars on iOS 26+ and `safeAreaInset()` for other pinned
  content or earlier targets. Do not guess safe-area clearance with fixed padding.
- Use one scroll edge effect per view; prefer `.automatic` and reserve `.soft` or other
  styles for a concrete visual need.

## Layout

- Organize around flexible containers, grids, stacks, lazy stacks, `ViewThatFits`, and
  `containerRelativeFrame()`.
- Do not use absolute `.position()` or device-specific offsets for primary layout.
- Do not hard-code screen dimensions, bar heights, row heights, or safe-area values.
- Use `@Environment(\.horizontalSizeClass)` and `@Environment(\.verticalSizeClass)`.
  Test `== .regular`; do not treat `nil` as regular.
- Support compact and regular width, portrait and landscape, multiwindow, iPad resizing,
  and iPhone Duo's changing display.
- Use `ConcentricRectangle()` next to a screen or sheet edge on iOS 26+ so corners follow
  their container. Use normal rounded rectangles farther inside content.
- Keep essential actions available at every size. A compact layout may reorganize
  content, but should not remove a capability.

## Typography

- Use semantic text styles such as `.body`, `.headline`, and `.title`.
- Do not fix a font size for ordinary interface text.
- For custom sizing on iOS 26+, use `.font(.body.scaled(by:))`; for earlier targets,
  use `@ScaledMetric`.
- Use system fonts for body and supporting text. Custom typefaces are acceptable for
  distinctive headings when the project already uses them.
- Keep body line length around 45-75 characters when practical.
- Use `.bold()` rather than hard-coded bold weights. Avoid scattering medium or
  semibold weights without a visual-system reason.
- Use normal title case for list, form, and section headers. Do not uppercase headers for style.

## SF Symbols

- Use filled symbol variants for tab bar items.
- Match symbol weight to adjacent text weight.
- Every icon-only control needs an accessible text label.
- Treat decorative symbols and images as hidden from accessibility.
- Use `symbolEffect()` for meaningful state feedback, not constant decoration.
- Prefer standard system actions and labels so menus receive the expected symbols.

## Motion

- Use motion to explain state or hierarchy, not to decorate every appearance.
- Standard interface transitions generally sit around 120-240 ms.
- Animate transform and opacity where possible.
- Read `@Environment(\.accessibilityReduceMotion)`. When true, replace large motion
  with opacity or remove it.
- Use `withAnimation(..., completion:)` for chained stages rather than guessing delays.
- Use `GlassEffectContainer` and `glassEffectID` when related glass elements should
  merge or morph as one system.

## App Icons

- iOS 26/27 icons are layered and can receive Liquid Glass highlights and lighting from the system.
- Use Icon Composer in Xcode 26+ rather than flattening the icon into one bitmap.
- Keep the foreground artwork crisp and avoid soft, feathered edges that expose layers.
- Provide Default, Dark, Clear, and Tinted appearance variants when the project supports them.
- Preserve the same core silhouette and recognition across variants.

## Visual Checklist

- Liquid Glass appears only on functional surfaces.
- Content backgrounds use standard materials or semantic backgrounds.
- No hand-built glass or third-party glass imitation exists.
- Clear glass is used only over media and has an appropriate scrim when needed.
- Functional color is restrained and brand color remains in content.
- Every custom color has light and dark behavior.
- Text uses Dynamic Type and semantic hierarchy.
- Section headers are title case, not uppercased.
- Backgrounds extend behind bars without covering readable content.
- Safe areas, window resizing, folds, and vertical bars are handled by system containers.
- Reduce Motion, Increased Contrast, Differentiate Without Color, and Reduce Transparency remain usable.
- Icon artwork is layered and tested in all supplied appearance variants.

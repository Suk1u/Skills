# iOS 26/27 Component Behavior

Use system containers first. They provide Liquid Glass, safe-area behavior, overflow,
keyboard access, and adaptation to iPad windows and iPhone Duo. Add version-specific
APIs only when the requested behavior benefits from them.

## Navigation Architecture

- Use `NavigationStack` for a single progression and `NavigationSplitView` for
  sidebar/detail or multi-column navigation.
- Never use `NavigationView` for new work.
- Register `navigationDestination(for:)` once per type in each stack.
- Do not mix data-driven destinations with direct `NavigationLink(destination:)` in one hierarchy.
- Put navigation state at the scene root so resizing or switching layouts does not reset the user's place.
- Use `inspector` for adjacent detail/settings when that behavior is needed; do not
  hand-build both an inspector column and a compact sheet.

## Tab Bar

- Tabs are for navigation, not actions.
- Use `Tab` values backed by an enum, not integer or string tabs.
- Give every tab an icon and a short label.
- Keep tabs available. If a tab has no data, show an empty state inside it rather than hiding it.
- Use badges only for important, actionable counts or state.
- On iOS 26+, `.tabViewStyle(.sidebarAdaptable)` can adapt between tabs and sidebar.
- On iOS 27+, `.tabBarMinimizeBehavior(.onScrollDown)` is appropriate for long,
  content-led screens. Do not minimize a tab bar merely because the API exists.
- On wide iPhone layouts, `.sidebarAdaptable` plus `.defaultTabBarPlacement(.sidebar)`
  must be requested explicitly; it is not automatic.

## Toolbar

- Toolbars contain actions. Tabs and sidebars contain navigation.
- Use semantic placements such as `.cancellationAction`, `.confirmationAction`, and
  `.primaryAction` before `.topBarLeading` or `.topBarTrailing`.
- Keep titles useful and concise. Do not use the app name as the navigation title.
- Let system materials and scroll-edge effects distinguish the toolbar from content.
  Do not paint a solid custom toolbar background without a concrete requirement.
- Group related controls in `ToolbarItemGroup`.
- On iOS 27+, use `visibilityPriority(.high/.standard/.low)` to preserve important
  actions when space is limited.
- Reserve `.topBarPinnedTrailing` for at most one indispensable action.
- Use `ToolbarOverflowMenu` for overflow actions so they appear directly rather than
  as a nested custom ellipsis menu.
- On iOS 27+, use `.toolbarMinimizationBehavior(.onScrollDown, for: .navigationBar)`
  only for content-led screens that benefit from the extra space.
- Apply `.contentMarginsRemoved()` to a toolbar item only when custom imagery should
  fill the glass surface.
- Attach dialogs outside `ToolbarOverflowMenu`; presentation from an item inside the
  system-owned menu can fail to appear.

## Sidebar

- A sidebar is part of the functional layer and adapts to Liquid Glass automatically.
- Keep hierarchy to two levels. Deeper structures need another navigation pattern.
- Allow user customization of content and order when the product calls for it.
- Do not hide critical actions at the bottom where a window edge or vertical bar can cover them.
- Use `NavigationSplitView` column widths and `backgroundExtensionEffect()` rather than
  manually drawing a panel.
- On narrow layouts, let the system adapt the sidebar instead of preserving an
  unreadable compressed column.

## Buttons And Controls

- Use standard roles: normal, primary, cancel, destructive.
- Keep one or two prominent actions per screen. Never make a destructive action primary.
- Use clear verbs for labels and preserve the label for VoiceOver when showing only an icon.
- Use `labelStyle(.iconOnly)` to keep a compact visual while retaining accessible text.
- For controls with meaningful values, provide a dynamic accessibility value.
- Use `.buttonStyle(.glass)` and `.glassProminent` only for intentional functional
  actions on supported systems; do not wrap every button in custom glass.
- Use `Toggle`, `Slider`, `Stepper`, `Picker`, and `DatePicker` natively so transient
  interaction receives system Liquid Glass behavior automatically.
- Never add `.glassEffect()` to sliders, toggles, or pickers to simulate these states.

## Sheets, Alerts, And Action Sheets

- Prefer `.sheet`, `.alert`, `.confirmationDialog`, and `.popover` over custom overlays.
- Use `sheet(item:)` when presenting optional data.
- Attach `confirmationDialog()` to the triggering control so the presentation can
  originate from the correct source.
- In SwiftUI, the system chooses the source automatically. In UIKit, set the popover
  presentation controller's `sourceItem` or `sourceView` and `sourceRect` when using an action sheet.
- On iOS 27, sheets gain larger rounded corners and inset half-sheet presentation.
  Do not put custom backgrounds on the system sheet chrome.
- Check that content is not clipped by larger corners or extends underneath bottom actions.
- On iOS 27+, side placement via `.presentationPlacement(.leading/.trailing)` is a
  deliberate choice for wide windows, not a default for every sheet.

## Lists, Tables, And Forms

- Let the system own row heights, insets, corner radii, and section spacing.
- Do not hard-code row heights to preserve an older visual rhythm.
- Use title-case section headers and never call `.uppercased()`.
- Prefer `LabeledContent` inside forms to align titles and controls.
- Use `List`, `Form`, and lazy containers according to content size and behavior.
- In lazy rows, keep each element's top-level view count and kind stable. Wrap
  conditional row content in a consistent container or filter the source collection.
- Use stable element identity. Never identify mutable rows by index or offset.
- Keep top context-menu actions and swipe actions consistent for the same item.
- Empty states should use `ContentUnavailableView` before custom empty-state artwork.

## Search

Choose one primary search entry:

- a dedicated search tab when search is a major navigation destination;
- a bottom toolbar when search is frequent and thumb reach matters;
- a navigation toolbar search when the bottom area should remain available for content.

Use `.searchable` and `searchSuggestions` with system behavior. For empty search
results, `ContentUnavailableView.search` supplies the query automatically. On iOS 27,
use the semantic search tab role when available so the system can position it correctly.

## Scroll Views

- Prefer one vertical scrolling surface. Avoid nested scroll views in the same direction.
- Use `LazyVStack` and `LazyHStack` for large collections.
- Use `.scrollIndicators(.hidden)` rather than initializer-only indicator flags.
- Use `scrollTransition()` or `visualEffect()` for scroll-driven appearance instead of
  writing raw offsets into the environment.
- Apply scroll-edge styling only where system bars float over content. Prefer `.automatic`.
- Use `.safeAreaBar()` for custom bars on iOS 26+ and `safeAreaInset()` otherwise.

## Menus

- Prefer native `Menu`, `contextMenu`, and toolbar overflow behavior.
- Give the menu trigger a text label for VoiceOver; hide the visual label only when necessary.
- Use standard responder actions where appropriate so the system supplies symbols and shortcuts.
- Keep one menu focused on one task. A filter menu may remain a submenu when grouping
  helps, but it should use a descriptive symbol rather than an ellipsis.
- A custom ellipsis inside `ToolbarOverflowMenu` becomes a nested submenu; use
  `ToolbarOverflowMenu` for direct actions.
- Use semantic destructive roles and keep confirmation behavior consistent.

## Windows, iPad, And iPhone Duo

- Treat every scene as resizable. iPad windows change freely, and iPhone Duo changes
  between outer and inner displays without relaunching.
- Choose layout from size classes and available space, not device idiom or orientation.
- Use `toolbarVerticalEdge`, `axisBehavior`, and vertical-bar geometry only on
  supported iOS 27.1+ systems and only for concrete custom-bar problems.
- Standard tabs, toolbars, and navigation adapt to vertical bars. Custom bars do not,
  so avoid replacing standard bars when iPhone Duo support is required.
- Keep the same features available on both displays. Additional width may expose more
  hierarchy, but must not add capabilities unavailable in compact layouts.
- Put selections and navigation paths above size-class branches so they survive a fold.
- Do not use `UIRequiresFullScreen` as a guarantee on iOS 27; it no longer prevents resizing.
- Use `ArrangementView` only for a requested primary/secondary adaptive layout or a
  demonstrated fold/resize issue. It is not a general stack replacement.
- Never plan for simultaneous app content on both iPhone Duo displays.

## Component Checklist

- Navigation is stack/split based and data-driven.
- Tabs navigate; toolbars act.
- Toolbar actions have semantic placement and sensible overflow priority.
- Sidebar hierarchy is shallow and adapts at compact width.
- Buttons have roles and accessible labels; destructive actions are not primary.
- Presentations use system sheets, alerts, dialogs, or popovers with correct anchoring.
- Lists use stable identity, system metrics, and stable row shape.
- Search uses the right entry point and system empty-state behavior.
- Scroll views avoid nesting and use lazy containers for large datasets.
- Menus preserve VoiceOver labels and standard action semantics.
- Layouts remain useful in resized windows, rotated devices, and both iPhone Duo displays.

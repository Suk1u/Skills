# HTTP 处理与重写参考

Surge 的 HTTP 处理包括：MITM 解密、URL Rewrite、Header Rewrite、Body Rewrite、Map Local、HTTP 脚本。除 MITM 外都要求流量进入 Surge 的 HTTP 引擎，HTTPS 还必须对该主机启用 MITM。

## 1. 处理流水线

请求方向：

```
Header Rewrite → URL Rewrite → Body Rewrite → Script
```

- Map Local 也在请求路径上求值：命中后直接返回本地响应，**不再请求上游**。
- 响应方向：Header Rewrite → Body Rewrite → Script（按规则匹配）。
- Header/Body Rewrite 可顺序叠加；URL Rewrite 的 header 模式只应用第一条匹配规则（以 URL Rewrite 专题页为准）。**每个方向最多一个 HTTP 脚本**：第一条启用且 pattern 命中的脚本获胜。
- Body Rewrite 先于脚本执行，脚本收到的是重写后的 body。
- 重写对明文 HTTP 自动生效；HTTPS 需要 MITM。
- 非标准端口的明文 HTTP 可能嗅探不到：用 `[General] force-http-engine-hosts` 强制；不想被解析的主机用 `always-raw-tcp-hosts` 排除。
- Map Local / Rewrite 还受 "Rewrite" 总开关控制。

## 2. MITM

```ini
[MITM]
hostname = -*.apple.com, -*.icloud.com, api.example.com, cdn.example.com
ca-passphrase = password
ca-p12 = MIIKPg...
h2 = true
auto-quic-block = true
```

> 手册另有一个 "MitM All Hostnames" 的极端示例（排除少数域名后用 `*`）。它只适合临时全量调试；常驻使用会扩大 TLS 暴露面并破坏证书固定（Pinning）的 App。生产模块应精确列出所需主机。

- `hostname` 是 **Host List**：逗号分隔；`-` 前缀排除，按顺序匹配，先匹配先生效；`*`/`?` 通配；`:port` 指定端口（缺省 443）；`:0` 所有端口；`<ip-address>` 匹配直接连 IP 的请求；带 SNI 的 TLS/QUIC 连接即使非标准端口，裸域名也能匹配。
- `hostname-disabled`：从有效列表中移除这些主机（UI 临时禁用用），可手动编辑。
- `ca-p12` + `ca-passphrase`：内联 CA；`ca-keystore-name` 指向 `[Keystore]` 的 p12 项，优先于 `ca-p12`。
- `skip-server-cert-verify`：默认 false；设为 true 会不校验上游证书（有安全风险，仅调试/特殊场景）。
- `h2 = true`：MITM 时接受 HTTP/2，提升并发性能。
- `client-source-address`：只对指定客户端启用 MITM，支持 CIDR 与 `-` 排除；Mac 6.1+ 支持 MAC。
- `auto-quic-block = true`（iOS 5.8+/Mac 5.4+）：命中 MITM 列表的 QUIC 连接自动阻断，迫使客户端回退 HTTP/2 或 HTTP/1.1。
- **模块只能改 `hostname` 与 `skip-server-cert-verify`**，不能改 CA 证书。
- iOS 安装 CA 后还必须在"关于本机 → 证书信任设置"中手动信任；否则 HTTPS 无法解密。
- SSL Pinning 的 App 会出现 MITM Failed，通常无法绕过。

## 3. URL Rewrite

```ini
[URL Rewrite]
^http://www\.google\.cn http://www.google.com header
^http://yachen\.com https://yach.me 302
^http://example\.com/old https://example\.com/new 307
^http://ad\.com/ad\.png _ reject
```

格式：`正则 替换 [类型]`，类型缺省为 `header`。

| 类型 | 行为 |
|---|---|
| `header` | 就地修改请求 URL/Host，客户端无感；多条命中只应用第一条；替换必须是合法 http/https/ws URL |
| `302` | 返回 302，Location 为替换值 |
| `307` | 返回 307，保留方法与 body |
| `reject` | 直接拒绝，替换值用 `_` 占位 |

- 正则对完整 URL 匹配，替换支持 `$1` 捕获组。
- 302/307 的替换值可用 `{{{GATEWAY_ADDRESS}}}` 占位为当前出口网关地址。
- 匹配时还会尝试用 Host 头与底层连接主机名重建的 URL。

## 4. Header Rewrite

```ini
[Header Rewrite]
http-request ^http://example.com header-add DNT 1
http-request ^http://example.com header-del Cookie
http-request ^http://example.com header-replace User-Agent Unknown
http-response ^http://example.com header-replace-regex Date 2022 2023
```

格式：`[http-request|http-response] 正则 动作 字段 [值] [替换模板]`；方向缺省为 `http-request`。

| 动作 | 说明 |
|---|---|
| `header-add` | 追加一行，即使字段已存在 |
| `header-del` | 删除该字段 |
| `header-replace` | 字段存在时替换值；不存在则无操作 |
| `header-replace-regex` | 用正则+模板替换字段值 |

- "有则替换、无则添加" = `header-del` + `header-add` 两行。
- **不能改消息分帧**：修改 `Content-Length`/`Transfer-Encoding` 会被拒绝并导致请求失败。

## 5. Body Rewrite（iOS 5.10+ / Mac 5.6+）

### 正则模式

```ini
[Body Rewrite]
http-response ^https?://example\.com/ "old" "new"
http-request  ^https?://example\.com/api "a=1" "a=2"
```

格式：`http-request|http-response URL正则 正则1 替换1 [正则2 替换2 ...]`。

- 可连续多组替换；替换支持 `$1`。
- `^`/`$` 匹配**每一行**的首尾。
- 多条规则按顺序执行；即使原 body 为空也可用 `^$` 生成内容。
- body 必须是合法 UTF-8 文本；否则跳过并记录 note。
- 请求 body 最多缓冲 32 MB；响应 body 修改上限 iOS 1 MB / macOS 10 MB，超限则原样透传。
- `Transfer-Encoding: chunked` 或 `Expect: 100-continue` 的请求不支持改 body。
- 修改后会自动解压、重算 `Content-Length`。

### JQ 模式（iOS 5.14+ / Mac 5.9+）

```ini
[Body Rewrite]
http-response-jq ^https?://httpbingo.org/anything '.headers |= with_entries(select(.key | test("^X-") | not))'
http-request-jq  ^https?://example\.com/api 'del(.ads)'
```

- body 必须是合法 JSON；jq 输出为空则保留原 body；表达式非法则警告并跳过。

## 6. Map Local（Mock）

text/tiny-gif/base64 数据类型：iOS 5.9.1+ / Mac 5.5.1+。

```ini
[Map Local]
^http://surgetest\.com/json data-type=text data="{}" status-code=500
^http://surgetest\.com/gif data-type=tiny-gif status-code=200
^http://surgetest\.com/file data-type=file data="data/map-local.json" header="a:b|foo:bar"
^http://surgetest\.com/base64 data="dGVzdA==" data-type=base64
```

| 参数 | 说明 |
|---|---|
| `data-type` | `file`（默认）、`text`、`tiny-gif`、`base64` |
| `data` | file: 路径或 URL；text: 内容；base64: base64 数据；tiny-gif: 无意义 |
| `header` | 自定义响应头，`|` 分隔多个键值，如 `header="a:b|foo:bar"` |
| `status-code` | 200–999，默认 200 |

- 命中后**跳过上游请求**。
- `data-type=text data=""` 返回空内容。
- Content-Type：file 按扩展名推断；text 默认 `text/plain`；tiny-gif 为 `image/gif`；base64 为 `application/octet-stream`。可用 `header` 覆盖。
- iOS/tvOS 的 file 数据上限 15 MB。

## 7. HTTP 脚本

- `http-request` / `http-response` 需要 `pattern`，可用 `requires-body`、`max-size`、`binary-body-mode`、`full-header-mode`、`timeout`、`engine`。
- `$request` / `$response` 字段与 `$done()` 返回结构见 `scripting.md`。
- 脚本可返回 `response` 直接短路请求，或 `abort: true` 断开。

## 8. 组合与选择

| 需求 | 首选 |
|---|---|
| 纯域名/URL 拦截 | `[Rule]` + `REJECT` |
| URL 重定向/改 Host | `[URL Rewrite]` |
| 增删改请求/响应头 | `[Header Rewrite]` |
| 返回固定 JSON/空 body/1px GIF | `[Map Local]` |
| 简单文本替换、删 JSON 字段 | `[Body Rewrite]`（jq 优先） |
| 动态计算、读存储、发网络请求 | `[Script]` |
| 需要条件逻辑/多步处理 | 脚本 |

## 9. 常见坑

- 忘记开 MITM 或 hostname 未覆盖目标 → 所有 HTTPS 重写静默失效。
- MITM hostname 用正则写法（如 `^api\.example\.com$`）——它是 Host List，不是正则。
- `%APPEND%` 与 `%INSERT%` 用于文档支持的键值列表，不是所有段通用；WireGuard 模块覆写也有独立说明。
- 正则过宽：`.*example.*` 会命中无关域名；尽量锚定 `^https?://`。
- 正则回溯爆炸：避免 `(.*)+`、嵌套量词；先在小样本上测试。
- Map Local 的 `data` 含空格/引号时必须正确加引号；JSON 内的双引号容易破坏行解析，必要时用 base64。
- Map Local 的 `data-type` 缺省是 `file`，不是 `text`；写 `data="{}"` 却忘了 `data-type=text` 会把它当文件路径。
- `header` 值不含 `:` 时 Surge 会按 base64 解码；必须写 `header="Content-Type:application/json"`，不能只写 `header="application/json"`。
- Body Rewrite 只处理 UTF-8 文本；gzip 会自动解压，但二进制/Protobuf 需脚本 + `binary-body-mode`。
- Header Rewrite 改 `Content-Length` 会失败；改 body 时让 Surge 自己重算。
- 一个请求只跑一个 http-request 和一个 http-response 脚本；多个脚本想串联时合并逻辑。
- 模块中的 HTTP 段落会插入到主配置顶部，可能与已有规则冲突，用 `surge-cli profile diff` 验证。
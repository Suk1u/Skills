# Surge 策略与策略组参考

## 1. 策略（[Proxy]）

```ini
Name = <type>, <host>, <port>[, 参数...]
Name = <type>, <host>, <port>[, username, password][, key=value...]
```

- 前两个位置参数通常是主机与端口；其余为 `key=value`。
- 含逗号的值用引号包住。
- 策略名可用于规则目标、策略组成员、`underlying-proxy`。

### 协议类型

| 关键字 | 协议 | 备注 |
|---|---|---|
| `http` / `https` | HTTP / HTTPS 代理 | HTTPS = TLS 上的 HTTP 代理 |
| `h2-connect` | HTTP/2 CONNECT | Mac 6.6+；多路复用 |
| `socks5` / `socks5-tls` | SOCKS5 | `udp-relay=true` 才转发 UDP |
| `ss` | Shadowsocks | AEAD 2022 支持 |
| `snell` | Snell | v1–v6 |
| `vmess` | VMess | 自动 UDP |
| `trojan` | Trojan | 始终 TLS，自动 UDP |
| `tuic` / `tuic-v5` | TUIC v4/v5 | QUIC |
| `hysteria2` | Hysteria 2 | QUIC |
| `masque` | MASQUE | HTTP/3 CONNECT |
| `anytls` | AnyTLS | 始终 TLS，UDP over TCP |
| `trust-tunnel` | Trust Tunnel | Mac 6.4.4+ |
| `ssh` | SSH 动态转发 | 无 UDP |
| `wireguard` | WireGuard | L3 隧道作为策略 |
| `tailscale` | Tailscale | iOS 5.20+/Mac 6.7+ |
| `external` | 外部代理程序 | 仅 Mac；iOS 视为 REJECT |

### 通用参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `interface` | 自动 | 绑定出口网卡；WireGuard/Tailscale 不支持 |
| `allow-other-interface` | false | 指定网卡不可用时允许默认网卡 |
| `dns-follow-interface` | false | DNS 也走该网卡 |
| `no-error-alert` | false | 不弹错误提示（仅代理策略） |
| `ip-version` | dual | `v4-only`/`v6-only`/`prefer-v4`/`prefer-v6`；有 `underlying-proxy` 时无效 |
| `hybrid` | auto | 仅 iOS，蜂窝+Wi-Fi 同时 |
| `tfo` | false | TCP Fast Open |
| `tos` | 0 | IP TOS |
| `ecn` | auto | 仅 QUIC/WireGuard/Tailscale 有效 |
| `block-quic` | auto | `auto`/`on`/`off`/`adaptive` |
| `test-url` | 全局 | 覆盖测速 URL |
| `test-timeout` | 全局 | 覆盖测速超时 |
| `test-udp` | 全局 | `hostname@ipv4` |
| `underlying-proxy` | — | 代理链入口策略/组 |

### TLS 参数

适用于 HTTPS、SOCKS5-TLS、h2-connect、Trust Tunnel、Trojan、TUIC、Hysteria2、AnyTLS、VMess(`tls=true`)：

| 参数 | 说明 |
|---|---|
| `skip-cert-verify` | 不校验服务器证书（可被 MITM） |
| `sni` | 自定义 SNI；`off` 关闭 |
| `server-cert-verify-name` | 用独立名称校验证书（iOS 5.21+/Mac 6.8+） |
| `server-cert-fingerprint-sha256` | 证书指纹固定 |
| `alpn` | 自定义 ALPN；TUIC/Hysteria2 默认 `h3` |
| `client-cert` | `[Keystore]` 中的客户端证书名 |
| `shadow-tls-password` / `shadow-tls-sni` / `shadow-tls-version` | Shadow TLS 包装 TCP 协议；不能用于 TUIC/WireGuard/Tailscale |

### 协议专属要点

**HTTP/HTTPS**

```ini
Proxy = http, example.com, 8080, username, password
Proxy = https, example.com, 443, username, password, sni=example.com
```

- `always-use-connect`：明文 HTTP 也走 CONNECT。
- `headers`（Mac 6.6+）：`Header:Value;Header2:Value2`，支持 `<random-string(16-32)>`。
- `h2-connect`：`max-streams` 默认 3；`udp-relay` 需服务端支持 CONNECT-UDP。

**Shadowsocks**

```ini
Proxy = ss, 1.2.3.4, 8388, encrypt-method=chacha20-ietf-poly1305, password=pwd, udp-relay=true
```

- 2022 方法密码必须是 16/32 字节 Base64 key；多用户 `serverKey:userKey`。
- `obfs=http|tls`、`obfs-host`、`obfs-uri`。
- `udp-relay=true` 才转发 UDP；`udp-port` 可指定独立 UDP 端口。

**VMess**

```ini
Proxy = vmess, host, 443, username=<UUID>, encrypt-method=aes-128-gcm, tls=true, ws=true, ws-path=/ws, ws-headers=Host:example.com|X-Token:abc, vmess-aead=true
```

**Trojan**

```ini
Proxy = trojan, host, 443, password=pwd, ws=true, ws-path=/ws
```

**Snell**

```ini
Proxy = snell, 1.2.3.4, 8000, psk=pwd, version=5, reuse=true
```

- version 1–6，缺省 1，建议显式写以匹配服务端。v6 用 mode=default/unshaped/unsafe-raw；unsafe-raw 没有机密性，不用于公网或不可信网络。
- `reuse` 仅 v4+ 有意义；v2 总是复用。
- v1–v3 支持 `obfs=http|tls`；v4/v5 只支持 `http`；v6 不支持。
- v3+ 自动 UDP。

**TUIC**

```ini
Proxy = tuic, host, 443, token=pwd, alpn=h3
Proxy = tuic-v5, host, 443, uuid=<uuid>, password=pwd, alpn=h3
```

- `port-hopping` / `port-hopping-interval`；不能与 `underlying-proxy` 同用。

**Hysteria 2**

```ini
Proxy = hysteria2, host, 443, password=pwd, download-bandwidth=100
```

- `port-hopping="1234;5000-6000"`；`salamander-password` / `gecko-password` 二选一。

**AnyTLS**

```ini
Proxy = anytls, host, 443, password=pwd, reuse=true
```

**MASQUE**

```ini
Proxy = masque, host, 443, username=user, password=pwd
```

**Trust Tunnel**

```ini
Proxy = trust-tunnel, proxy.example.com, 443, username=user, password=REPLACE_WITH_SECRET
```

TLS 隧道，支持 headers/max-streams；h3（iOS 5.22+/Mac 6.9+）切到 HTTP/3。保存手册说明不转发 UDP，不能因为底层用 QUIC 就假定它能承载任意 UDP。

**SSH**

```ini
Proxy = ssh, host, 22, username=root, private-key=key1, idle-timeout=180
```

- 需要 `password` 或 `private-key`；仅 `curve25519-sha256` + `aes128-gcm`，服务端 OpenSSH 7.3+。
- `server-fingerprint` 可固定；无 UDP。

**WireGuard**

```ini
[Proxy]
Office WG = wireguard, section-name=office-wg

[WireGuard office-wg]
private-key = <client-private-key>
self-ip = 10.20.0.2
mtu = 1280
peer = (public-key = <server-public-key>, allowed-ips = "10.20.0.0/24, 192.168.50.0/24", endpoint = vpn.example.com:51820)
```

- 有 `dns-server` → 通用代理策略（URL 测速）；无 → 点对点策略（原生 RTT 探测）。
- `allowed-ips` 只决定选哪个 peer；能否转发取决于服务端。
- WireGuard 支持 allow-peer-access/listen-port（iOS 6.0+ / Mac 6.11+）；没有文档中的 `advertise` 键，advertise-exit-node/advertise-routes 属于 Tailscale。

**Tailscale**

```ini
[Proxy]
My Tailnet = tailscale, section-name=my-tailnet

[Tailscale my-tailnet]
auth-key = tskey-auth-example
hostname = surge-mac
```

- `exit-node=none|auto|<selector>`、`derp-only`、`auto-add-magic-dns-rule`。
- 默认自动把 MagicDNS 后缀与 peer 地址路由到该策略。
- 不会替代系统 Tailscale 客户端。

**External（Mac）**

```ini
external = external, exec="/usr/bin/ssh", args="11.22.33.44", args="-D", args="127.0.0.1:1080", local-port=1080, addresses=11.22.33.44
```

- 首次使用时启动进程，转发到本地 SOCKS5；进程退出会重启；日志在 `/tmp/Surge-External-*.log`。

### 内置策略

`DIRECT`、`REJECT`、`REJECT-TINYGIF`、`REJECT-DROP`、`REJECT-NO-DROP`。

iOS 额外：`CELLULAR`、`CELLULAR-ONLY`、`HYBRID`、`NO-HYBRID`。

`[Proxy]` 中可定义别名：

```ini
[Proxy]
On = direct
Off = reject
Corp-VPN = direct, interface=utun0
```

- 别名可用 `direct`/`reject`/`reject-drop`/`reject-no-drop`/`reject-tinygif`。
- 重定义 `DIRECT` 被静默忽略；重定义其他内置名是配置错误。

### REJECT 家族

| 策略 | 行为 |
|---|---|
| `REJECT` | 拒绝；HTTP 显示错误页（受 `show-error-page-for-reject` 控制） |
| `REJECT-TINYGIF` | 1px GIF，网页广告常用 |
| `REJECT-DROP` | 静默丢弃，抑制重试风暴 |
| `REJECT-NO-DROP` | 拒绝但不会被自动升级为 DROP |

- 30 秒内同主机 50 次请求会自动升级为 DROP。
- pre-matching 下：REJECT → DNS 无记录/TCP RST；DROP → 丢弃；NO-DROP → sink `198.18.0.244`，TCP 由 Surge 回 RST。

### UDP

- UDP 与 TCP 走同一套规则；命中的策略必须支持 UDP。
- 需要显式 `udp-relay=true`：SOCKS5、SOCKS5-TLS、SS、External、h2-connect。
- 自动支持：Snell v3+、VMess、Trojan、TUIC、Hysteria2、MASQUE、AnyTLS、WireGuard、Tailscale。
- 不支持：HTTP/HTTPS、Trust Tunnel、SSH。
- 策略不支持 UDP 时，udp-policy-not-supported-behaviour 决定 REJECT（Mac 6.0+ 默认）或 DIRECT。
- SOCKS5 入站 UDP ASSOCIATE（iOS 6.0+/Mac 6.11+）不同于出站 udp-relay：不依赖 VIF，每个 association 由首个 datagram 决定策略，后续目的地仍沿用该策略。不要假定每个数据报重新分流；更完整的限制见 official-manual 的 policies__udp 专题。

## 2. 策略组（[Proxy Group]）

```ini
Proxy = select, ProxyA, ProxyB, DIRECT
Auto = url-test, ProxyA, ProxyB
Smart = smart, ProxyA, ProxyB
```

格式：`Name = type, 成员..., key=value...`。含 `=` 的是参数，其余是成员名。

| 类型 | 行为 |
|---|---|
| `select` | 手动选择；选择按配置保存；无选择/选择失效时用第一个成员 |
| `url-test` | 自动选延迟最低 |
| `fallback` | 按声明顺序选第一个可用 |
| `load-balance` | 在可用成员间分摊 |
| `smart` | 按真实连接质量与站点历史动态选择 |
| `subnet` | 按当前网络选择（旧名 `ssid`） |

### 通用参数

| 参数 | 说明 |
|---|---|
| `no-alert` | 不弹"有新最优"通知（仅 url-test/fallback 会弹） |
| `hidden` | 在 UI/菜单中隐藏 |
| `icon-url` | 组图标（Mac 6.5+） |
| `category` | UI 分类（iOS 5.23+/Mac 6.10+） |
| `underlying-proxy` | 整组代理链（iOS 5.22+/Mac 6.9+）；成员显示为 `Name (via Relay)` |

### 自动测试组的参数

| 参数 | 适用 | 默认 | 说明 |
|---|---|---|---|
| `interval` | url-test/fallback/load-balance | 600 秒 | 结果有效期；懒重测 |
| `tolerance` | url-test | 100 ms | 新最优必须快出超过该值才切换 |
| `timeout` | url-test/fallback/load-balance | 无 | 按测速延迟过滤成员，不是连接超时 |
| `evaluate-before-use` | 全部自动组 | false | 首次使用前等待测试完成 |
| `persistent` | load-balance | false | 同一目标主机固定同一策略 |
| `policy-priority` | smart | 1.0 | `正则:系数`，分号分隔；`<1` 提高优先级；必须为正 |

### 测试细节

- 对每个成员发 HTTP HEAD；两轮：建连 + 复用连接再测一次，第二轮的耗时作为分数。
- URL：成员 `test-url` → 全局 `proxy-test-url`（代理）/`internet-test-url`（直连），默认 `http://bing.com/`。
- 超时：成员 `test-timeout` → 全局 `test-timeout` → 5 秒（直连 10 秒）。
- 测试 URL 应支持 keep-alive，否则分数偏高并有警告。
- `timeout` 过滤与 `test-timeout` 不是一回事。

### Smart

版本：iOS 5.11.0+ / Mac 5.7.0+；iOS 还需已解锁该订阅功能。不能只检查安装版本；到期后的可用性以 App 显示的授权资格为准。

- 成员只能是代理策略；嵌套组与内置策略会被静默忽略。
- 评分概念：(首字节延迟的时变加权平均 + TCP 重传丢包惩罚) × policy-priority；具体实现可随版本变化，不把估计公式作为外部控制契约。
- 固定 5 分钟重测，`interval` 无效；成员 >12 时只测常用/最久未测的子集。
- 每个站点约 1 小时的成功/失败记忆。
- 显示的选择是"最近最常使用"，不一定是下一条连接实际使用的。
- 适合线路质量相近的组；不考量带宽；对 IP 敏感的服务单独绕开。

### subnet

```ini
Subnet Group = subnet, default = ProxyA, SSID:MyHome = ProxyB, TYPE:CELLULAR = ProxyC
```

- `default` 必填；条件按声明顺序求值，第一条命中生效；网络变化时重算。
- 表达式与 `SUBNET` 规则相同：`SSID:`、`BSSID:`、`ROUTER:`、`TYPE:`、`MCCMNC:`。
- 只支持 `hidden`、`icon-url`、`category`，不支持 `policy-path`/`include-*` 等成员导入参数。
- 旧关键字 `ssid` 仍被接受。

### 成员导入

```ini
Group = select, policy-path=https://example.com/nodes.conf
Group = url-test, include-all-proxies=true, policy-regex-filter=US
Group = select, include-other-group="GroupA, GroupB"
```

| 参数 | 说明 |
|---|---|
| `policy-path` | 外部策略列表或完整配置；默认 86400 秒更新 |
| `include-all-proxies` | 包含 `[Proxy]` 全部策略（不含内置/组） |
| `include-other-group` | 包含其他组的成员；多个组名要加引号 |
| `policy-regex-filter` | 按名称正则过滤（不作用于显式列出的成员） |
| `external-policy-name-prefix` | 给导入策略加前缀 |
| `external-policy-modifier` | 覆盖导入策略参数，如 `"test-url=...,tfo=true"` |

远程 `policy-path` 资源会缓存；iOS 5.11+ 单个外部策略组资源上限约 2 MB，超限会加载失败。

处理顺序：`policy-regex-filter` → `external-policy-name-prefix` → `external-policy-modifier`。

成员组装顺序：显式成员 → `include-other-group` → `include-all-proxies` → `policy-path`。重名保留第一个。

### 嵌套与故障

- 除 smart 外都可以嵌套组。
- 循环引用会告警，相关组临时表现为 reject（日志 `FAILED`）。
- 组没有任何可用成员时回退 `DIRECT`（日志 `SUBSTITUTE`）并一次性告警。

### 临时覆盖

自动组（url-test/fallback/load-balance/subnet/smart）可手动临时指定策略：

- Mac：组菜单中的 override。
- iOS：长按策略项。

覆盖期间不再自动测试；组消失后覆盖在配置重载时清除。

## 3. 常见坑

- `url=` 是旧参数，现在无效；用 `test-url`。
- `timeout` 是延迟过滤，不是连接超时；连接超时用 `test-timeout`。
- `tolerance` 太小会导致出口 IP 频繁变化。
- `include-other-group` 多个组名必须加引号。
- `external-policy-modifier` 只影响 `policy-path` 导入的成员。
- Smart 组塞入大量低质线路会频繁切换；组内线路质量应相近。
- Smart 不判断地区限制，只能对连接失败/超时/卡死作出反应。
- 对 IP 变化敏感的银行/支付服务，单独写规则绕开自动组。
- HTTP/HTTPS 代理不支持 UDP；需要 UDP 时选支持 UDP 的协议或加 `udp-relay=true`。
- WireGuard 的 allowed-ips 与 Tailscale 的控制面路由不能保证远端开启转发/NAT；不要把 Tailscale 动态 peer 路由误当成同名可手写配置键。
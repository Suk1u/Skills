# Surge 工具与控制接口

## 1. 信息面板（Panel）

```ini
[Panel]
PanelA = title="Panel Title", content="Content\nSecond line", style=info
PanelB = title="Dynamic", content="Loading…", style=info, script-name=panel, update-interval=60
```

- `style`：`good` / `info` / `alert` / `error`。
- `script-name` 指向 `[Script]` 中 `type=generic` 的脚本名。
- update-interval 是在打开策略页/菜单时检查结果是否到期，不是后台严格定时器；设1可在每次打开时重测。省略该参数用于手动刷新。社区的 -1 用法未被手册明确承诺。
- 手动刷新也可能传入 $trigger="button"，不能据此区分“执行操作的点击”与“只读刷新”。面板默认只读。
- 首次运行前显示静态 `content`；之后缓存上次脚本结果，直到下次刷新。
- 脚本返回 `{title, content, style, icon, "icon-color"}`；`icon` 用 SF Symbol 名，`icon-color` 为 HEX。
- Panel 版本：iOS 4.9.3+ / Mac 5.7.5+。iOS 显示受手册所述有效订阅资格影响（提到 2021-09-22 的资格边界）；确认 App 实际资格，不承诺订阅到期仍显示。

## 2. HTTP API

```ini
[General]
http-api = REPLACE_WITH_STRONG_KEY@127.0.0.1:6171
http-api-tls = false
http-api-web-dashboard = false
http-api-mcp = false
```

- 使用自己的强随机 key；请求优先 X-Key，Bearer 认证需 iOS 6.0+ / Mac 6.11+。query 的 x-key 会泄露到 URL/历史/日志，只有已理解影响的必要场景才用。局域网设备访问需显式配置可信地址，不能直接公开到互联网。
- 只有 GET/POST；GET 用 query，POST 用 JSON body；响应始终 JSON（`/v1/metrics` 除外）。
- `http-api-tls = true` 时用 MITM CA 生成服务器证书，客户端需手动信任。
- API key 拥有完全控制权（含执行脚本、停止 Surge）；不要暴露在不可信网络。

### 端点速查

**能力开关**

```
GET  /v1/features/mitm
POST /v1/features/mitm        {"enabled":true}
GET/POST /v1/features/capture
GET/POST /v1/features/rewrite
GET/POST /v1/features/scripting
GET/POST /v1/features/system_proxy      # Mac
GET/POST /v1/features/enhanced_mode     # Mac
```

**出站模式**

```
GET  /v1/outbound                  {"mode":"rule"}   # direct|proxy|rule
POST /v1/outbound
GET  /v1/outbound/global           {"policy":"ProxyA"}
POST /v1/outbound/global
```

**策略与策略组**

```
GET  /v1/policies
GET  /v1/policies?include_external=true
GET  /v1/policies/detail?policy_name=ProxyA
POST /v1/policies/test             {"policy_names":["A","B"],"url":"http://bing.com"}
GET  /v1/policy_groups
GET  /v1/policy_groups/test_results
GET  /v1/policy_groups/select?group_name=Group
POST /v1/policy_groups/select      {"group_name":"Group","policy":"ProxyA"}
POST /v1/policy_groups/test        {"group_name":"Group"}
```

**请求**

```
GET  /v1/requests/recent
GET  /v1/requests/active
POST /v1/requests/kill             {"id":100}
```

**配置**

```
GET  /v1/profiles/current?sensitive=0
POST /v1/profiles/reload
POST /v1/profiles/switch           {"name":"Profile2"}      # Mac
GET  /v1/profiles                                          # Mac
POST /v1/profiles/check            {"name":"Profile2"}      # Mac
GET  /v1/profiles/sections
GET  /v1/profiles/section?name=Rule
POST /v1/profiles/section          {"name":"Rule","content":"...","revision":"..."}
```

- `profiles/section` 会校验整份配置后写回实际持有该段的文件，并自动重载。
- 托管/企业配置、URL/托管配置引入的段、多文件拼装的段、混排 `#!include` 的段为只读。

**模块**

```
GET  /v1/modules
POST /v1/modules                   {"Module Name": true, "Other": false}
```

**外部资源**

```
GET  /v1/external_resources
POST /v1/external_resources/update {"key":"..."}   # "all" 更新全部远程资源
```

返回的 `fromModule` 可定位资源由哪个模块引入。

**DNS**

```
POST /v1/dns/flush
GET  /v1/dns
POST /v1/test/dns_delay
GET  /v1/geoip?ip=1.1.1.1
```

**脚本**

```
GET  /v1/scripting
POST /v1/scripting/evaluate        {"script_text":"...","mock_type":"cron","timeout":5}
POST /v1/scripting/cron/evaluate   {"script_name":"script1"}
```

**抓包过滤（iOS 6.0+/Mac 6.11+）**

```
GET  /v1/capture/filters
POST /v1/capture/filters           {"scope":"on-disk","httpOnly":true,"type":"with-keywords","keywords":["example.com"]}
```

**其他**

```
GET  /v1/events
GET  /v1/rules
GET  /v1/traffic
POST /v1/log/level                 {"level":"verbose"}
GET  /v1/mitm/ca                   # DER 证书
POST /v1/stop
GET  /v1/metrics                   # Prometheus 文本
POST /v1/mcp                       # MCP，需 http-api-mcp=true
```

### 设备（Mac）

```
GET  /v1/devices
POST /v1/devices                   {"physicalAddress":"F0:9F:C2:00:00:00","name":"Computer","address":"192.168.1.200","shouldHandledBySurge":true}
```

### Prometheus

`GET /v1/metrics` 暴露 `surge_uptime_seconds`、`surge_memory_bytes`、`surge_active_requests`、`surge_dns_cache_entries`、`surge_interface_{in,out}_bytes_total`、`surge_policy_{in,out}_bytes_total` 等。Prometheus 不支持自定义头时用 query 传 key。

### MCP

```bash
claude mcp add --transport http surge http://192.168.1.10:6171/v1/mcp --header "X-Key: examplekey"
```

工具覆盖状态、策略组、规则匹配解释、DNS/GeoIP、请求、日志、Logbook、测试、临时规则、配置段、模块、功能开关、抓包过滤、脚本，Mac 还有网关设备。每个工具标注只读/发测试流量/改设置/破坏性。

## 3. surge-cli（Mac）

路径：`/Applications/Surge.app/Contents/Applications/surge-cli`；无参数进入交互模式。下面的 surge-cli 是该路径的简写，并非系统自带命令；若没有配置 PATH，使用完整路径。此环境没有安装 Surge，未验证这些 CLI 的实际运行，具体参数先读目标版本 help。

```bash
surge-cli status
surge-cli version
surge-cli mode rule
surge-cli policy-group list
surge-cli profile diff
surge-cli help rule match
surge-cli help rule explain
surge-cli dns lookup example.com
surge-cli dns trace example.com
surge-cli geoip 1.1.1.1
surge-cli http probe https://example.com
surge-cli module list
surge-cli feature mitm
surge-cli script list
surge-cli script run <cron-name>
surge-cli log watch
surge-cli logbook
surge-cli reload
surge-cli --check profile.conf
```

具体子命令与参数以 `surge-cli --help` / `surge-cli help <command>` 为准；`rule match` 的匹配属性按文档是 `key=value` 形式。

### 命令组

| 组 | 命令 |
|---|---|
| Status | `status`、`summary`、`version` |
| Routing | `mode`、`global-policy`、`policy-group`、`rule match`、`rule explain`、`rule temp` |
| Profile | `profile`、`module`、`feature`、`capture-filter`、`managed-profile`、`external-resource` |
| Network | `dns`、`geoip`、`http probe`、`test`、`diagnostics`、`flush dns` |
| Inspection | `dump`、`watch`、`log`、`logbook`、`proxy-runtime-status` |
| Automation | `script`、`script-log`、`benchmark` |
| Gateway | `device`、`vmnet`、`security ban` |
| Control | `reload`、`switch-profile`、`kill`、`stop`、`unattended-upgrade` |
| Environment | `environment`、`set`、`set-log-level` |

### 远程

```bash
surge-cli --remote 192.168.1.20:6170 status
surge-cli -r 192.168.1.20:6170 --password-stdin status < password.txt
```

- 需要被控端配置 `external-controller-access = password@0.0.0.0:6170`。
- 密码优先级：`--password-stdin` / `SURGE_CLI_PASSWORD` / 安全提示；不要写在命令行。
- 兼容 Surge iOS/tvOS 5.21+（`--remote`）。
- 局域网连接不加密；30 秒内 10 次失败会封禁来源。

### 诊断利器

- `profile diff`：主配置 vs 应用模块后的有效配置。
- `rule match` / `rule explain`：不进真实流量，直接解释命中规则与策略组决策。
- `rule temp`：临时规则，立即生效、先于所有规则、Surge 停止后丢弃。
- `dns trace`：完整解析链路、响应服务器、接口、耗时、缓存 TTL。
- `dump rule-usage`：每条规则命中计数，找出永不命中的规则。
- `dump performance`：内存、运行时长、活跃请求、DNS/虚拟 IP/临时规则表大小。

### 配置段编辑（iOS 6.0+/Mac 6.11+）

```bash
surge-cli profile section list
surge-cli profile section get Rule > rule.txt
surge-cli profile section set Rule rule.txt <revision>
```

## 4. URL Scheme

iOS 与 macOS 都支持 `surge:///`；其中 `start`/`stop`/`toggle` 仅 iOS，`install-config`/`install-module` 两端可用。

```
surge:///start
surge:///stop
surge:///toggle
surge:///install-config?url=<percent-encoded>
surge:///install-module?url=<percent-encoded>
surge:///email-license?email=x&key=y
surge:///enterprise-license?companyID=x&userID=y&passcode=z
```

- `autoclose=true` 可在动作完成后自动关闭 Surge（iOS，不能与 install-config 同用）。
- 支持 x-callback-url 的 `start`/`stop`/`toggle`。
- macOS 6.7+ 也接受 `surgeconfig:///install-config`。

## 5. Logbook（Mac 6.6+）

- 持久记录配置重载、网络切换、崩溃恢复、更新、DHCP 变化等事件，默认保留最近 7 天。
- Dashboard 可远程查看 Mac/iOS 的 Logbook；脚本记录支持查看输入、输出、日志。
- CLI：`surge-cli logbook`。

## 6. 排障常用接口

| 场景 | 操作 |
|---|---|
| 模块是否生效 | `surge-cli profile diff` |
| 规则为何走这条线 | `surge-cli rule explain` |
| DNS 解析异常 | `surge-cli dns trace` / `GET /v1/dns` |
| 外部资源没更新 | `GET /v1/external_resources` → `POST .../update` |
| 脚本没跑 | `GET /v1/scripting`、`POST /v1/scripting/cron/evaluate`、脚本日志 |
| 面板拿不到数据 | 检查 `script-name`、`update-interval`、`$trigger` |
| 性能瓶颈 | `GET /v1/metrics`、`dump performance`、`benchmark rule-matching` |
# 实战模式库：从真实模块中提炼的写法

语料：Rabbit-Spec/Surge（37 个模块，Panel/Spec 分层）与 QingRex/LoonKissSurge 的 Surge 目录（506 个模块，根/Beta/Official 三套）。以下模式按"要解决的问题"组织，而不是按语法。

## 0. 语料概览

- **KISS 506 个文件**：根目录214、Beta214、Official78。删除 category 行后214对根/Beta文本一致；去掉这批镜像后剩292个分析条目，不等于292种独立功能。具体每个文件的固定commit、SHA-256和结构见 corpus-catalog.json。
- **Rabbit 37 个**：`Panel/` 16 个（面板 + 本地 JS + README），`Spec/` 21 个（单一职责小模块）。
- 段落使用（全部 543 个文件，按模块计）：`[MITM]` 489、`[Map Local]` 329、`[Body Rewrite]` 229、`[Script]` 213、`[Rule]` 155、`[URL Rewrite]` 109、`[Panel]` 31、`[General]` 27、`[Header Rewrite]` 7、`[Host]` 7（含 1 个写成小写 `[host]`）。
- 全部543文件的脚本声明：http-response678、http-request117、generic34、cron25、event2、dns1，没有type=rule；这些包含Beta重复，不代表857种独立脚本。
- Map Local 共2200行：text2136、tiny-gif22、file/缺省42；其中2049行是text的空JSON对象（约93.1%），不保证每行都使用相同header/status。Body Rewrite共3293行，3283行jq（约99.7%）、10行普通http-response。
- 全量元数据声明：loon_version426、tag426、openUrl424；它们说明生态风格，不能证明Surge会展示或执行。完整计数与口径见 corpus-stats.json。
- 结论：这份语料最擅长"中国区 iOS App 去广告"，不能代表全部 Surge 能力；语料未覆盖的请求体改写、二进制 mock、复杂解锁等，必须回到手册逐条核对。

## 1. 技术选型矩阵

| 目标 | 首选 | 次选 | 不建议 |
|---|---|---|---|
| 屏蔽整个域名 | `[Rule] DOMAIN-SUFFIX,...,REJECT` | `DOMAIN-SET`/`RULE-SET` | 脚本 |
| 屏蔽特定 URL | `[URL Rewrite] ... _ reject` | `URL-REGEX` + `REJECT` | 脚本 |
| 返回空/固定 JSON | `[Map Local] data-type=text` | 脚本 | Body Rewrite 生成整段 |
| 删除 JSON 字段 | `[Body Rewrite] http-response-jq` | 脚本 | 正则改 JSON |
| 替换文本片段 | `[Body Rewrite]` 正则 | 脚本 | Map Local |
| 改请求/响应头 | `[Header Rewrite]` | 脚本 | — |
| 需要读 Cookie/Token | 脚本（http-request） | — | 静态重写 |
| protobuf/gRPC | 脚本 + `binary-body-mode=1` | — | Body Rewrite |
| 定时签到 | `type=cron` + `$httpClient` | 快捷指令 | 常驻脚本 |
| 展示信息 | `[Panel]` + `type=generic` | 静态 Panel | 通知轰炸 |
| 按 SSID/进程分流 | `[Rule] SUBNET`/`PROCESS-NAME` | `type=rule` 脚本 | MITM 脚本 |

## 2. 去广告

### 2.1 纯域名拦截（不需要 MITM）

```ini
[Rule]
DOMAIN-SUFFIX,ads.example.com,REJECT
DOMAIN,track.example.com,REJECT,extended-matching,pre-matching
```

- `extended-matching`：客户端直接连 IP 时，仍用 TLS SNI/Host 匹配域名。
- `pre-matching`：在 DNS/握手阶段就拒绝，开销最低；策略必须是 REJECT 家族。
- 域名规则不触发 DNS，适合大范围拦截。

### 2.2 路径级拦截

```ini
[URL Rewrite]
^https?://api\.example\.com/ad/ _ reject

[Rule]
URL-REGEX,"^https?://api\.example\.com/(ad|promo)/",REJECT-TINYGIF,extended-matching
```

- URL Rewrite 更精确、无需 MITM 也能对明文 HTTP 生效；HTTPS 仍需 MITM。
- `REJECT-TINYGIF` 只适合网页图片类广告；App API 用普通 `REJECT`。

### 2.3 返回空响应 / 固定 JSON（Map Local）

```ini
[Map Local]
^https?://api\.example\.com/v1/ad/config\? data-type=text data="{}" status-code=200 header="Content-Type:application/json"
^https?://cdn\.example\.com/ad\.gif data-type=tiny-gif status-code=200
^https?://api\.example\.com/v1/empty data-type=text data="" status-code=204
```

- `data-type=text data="{}"` 是最常用的"假成功"。
- 需要精确模拟字段时用 `data-type=file` + 本地/远程 JSON；iOS 文件上限 15 MB。
- `header` 用 `|` 分隔多个头。

### 2.4 删除 JSON 里的广告字段（jq）

```ini
[Body Rewrite]
http-response-jq ^https?://api\.example\.com/v1/feed 'del(.data.ads) | del(.data.banners)'
http-response-jq ^https?://api\.example\.com/v1/list '.items |= map(select(.isAd != true))'
http-response-jq ^https?://api\.example\.com/v1/config '.config |= with_entries(select(.key | test("^ad") | not))'
```

- body 必须是合法 JSON；jq 输出为空则保留原 body。
- 比正则安全，能处理字段顺序/空白变化。
- 上限：响应 body iOS 1 MB / macOS 10 MB。

### 2.5 正则删除文本

```ini
[Body Rewrite]
http-response ^https?://api\.example\.com/v1/feed '"showAds":true' '"showAds":false'
http-response ^https?://example\.com/ "广告" ""
```

- `^`/`$` 匹配每一行；替换支持 `$1`。
- body 必须是 UTF-8 文本。

### 2.6 动态/加密/protobuf（脚本）

```ini
[Script]
ads = type=http-response, pattern=^https?://api\.example\.com/v1/feed, script-path=https://example.com/js/ads.js, requires-body=true, max-size=2097152, timeout=10
```

```js
let obj = JSON.parse($response.body);
obj.data = (obj.data || []).filter(x => !x.isAd);
$done({body: JSON.stringify(obj)});
```

protobuf：

```ini
[Script]
tb = type=http-response, pattern=^https?://tiebac\.baidu\.com/c/f/, requires-body=true, binary-body-mode=true, max-size=1048576, timeout=15, script-path=https://example.com/js/tieba-proto.js
```

### 2.7 别忘了 QUIC

App 可能走 HTTP/3，绕开 HTTP 引擎与 MITM：

```ini
[Rule]
AND,((DOMAIN-SUFFIX,example.com,extended-matching),(PROTOCOL,QUIC)),REJECT
```

或在策略上 `block-quic=on` / 全局 `[General] block-quic=all-proxy`，让客户端回退 TCP。

### 2.8 去广告模块的最小骨架

```ini
#!name=Example: Remove Ads
#!desc=Blocks ads in Example App.
#!system=ios

[Rule]
DOMAIN-SUFFIX,ads.example.com,REJECT
DOMAIN-SUFFIX,analytics.example.com,REJECT
```

有脚本/重写才需要 MITM；纯 Rule 模块不要声明 MITM。

## 3. 解锁 / 区域切换

模块通常只负责改写请求/响应和 MITM；**分流规则不能指向用户的策略组**（模块规则只允许 `DIRECT`/`REJECT`/`REJECT-TINYGIF`）。需要把目标域名导到某个代理时，让用户在主配置里加：

```ini
# 用户自己的主配置，不在模块里
[Rule]
DOMAIN-SUFFIX,example.com,YourProxyGroup
```

模块本身只写脚本与 MITM：

```ini
[Script]
unlock-request  = type=http-request,  pattern=^https?://api\.example\.com/, script-path=https://example.com/js/req.js, requires-body=true, argument="{{{Region}}}"
unlock-response = type=http-response, pattern=^https?://api\.example\.com/, script-path=https://example.com/js/resp.js, requires-body=true

[MITM]
hostname = %APPEND% api.example.com
```

- 模块内不要写 `{{{Proxy}}}` 作为规则策略：占位符会替换成用户组名，但模块规则文档只允许内置策略，属于越界写法。
- 模块参数 `{{{Region}}}` 须声明；请求与响应脚本不必一律成对，按实际协议变化选择。
- 解锁类脚本常依赖固定版本；升级接口就可能失效。

## 4. 签到 / Cookie / 定时任务

### 4.1 抓 Cookie 或 Token

```ini
[Script]
capture = type=http-request, pattern=^https?://api\.example\.com/user, script-path=https://example.com/js/capture.js, requires-body=true
```

```js
const cookie = $request.headers.Cookie || "";
const m = cookie.match(/token=([^;]+)/);
if (m) $persistentStore.write(m[1], "example_token");
$done({});
```

### 4.2 定时执行

```ini
[Script]
checkin = type=cron, cronexp="0 8 * * *", wake-system=1, timeout=120, script-path=https://example.com/js/checkin.js
```

```js
const token = $persistentStore.read("example_token");
if (!token) { $notification.post("签到", "未获取到 Token", ""); $done(); }
else {
  $httpClient.post({url: "https://api.example.com/checkin", headers: {Authorization: "Bearer " + token}, timeout: 10},
    (err, resp, data) => {
      $notification.post("签到", err ? "失败" : "完成", err || data);
      $done();
    });
}
```

- 5 分钟一次属于每小时 12 次，超过手册的 10 次警告阈值；仅在业务确有需要且用户接受能耗时使用。
- wake-system 默认 false；iOS 需要空闲时唤醒且用户接受能耗时再设为 true。不要保证每次调度都准时执行。
- 通知去重：`$persistentStore` 存"上次执行日期/内容"。

### 4.3 四类脚本共用一个 JS（KISS 常见）

```ini
[Script]
capture = type=http-request, pattern=^https?://api\.example\.com, script-path=https://example.com/js/all.js, requires-body=true
cron    = type=cron, cronexp="{{{cron}}}", wake-system=1, script-path=https://example.com/js/all.js
panel   = type=generic, script-path=https://example.com/js/all.js
```

脚本内用 `$script.type` / `$trigger` / `$event` 分流。优点：一份代码；缺点：任一分支出错影响全部。

## 5. Panel 模式

### 5.1 最小动态面板

Panel：iOS 4.9.3+ / Mac 5.7.5+；iOS 显示还受订阅资格影响。示例只展示结构；公网 IP 接口需可信且可达。

```ini
[Panel]
IP-Check = script-name=IP-Check, title="节点详情", content="请刷新", style=info, update-interval=1

[Script]
IP-Check = type=generic, timeout=3, script-path=https://example.com/js/ip-check.js
```

```js
$httpClient.get("https://api.ipify.org?format=json", (err, resp, data) => {
  if (err) return $done({title: "节点详情", content: "请求失败", style: "error"});
  $done({title: "节点详情", content: data, style: "info", icon: "network", "icon-color": "#007aff"});
});
```

### 5.2 刷新间隔

| 值 | 行为 | 用途 |
|---|---|---|
| `-1` | 不自动刷新，点击刷新按钮才执行（社区约定，手册未明确） | 测速、解锁检测、手动工具 |
| `1` | 每次打开面板都刷新 | 启动时长、连通性 |
| `60`/`600` | 按秒缓存 | 公网 IP、DNS |
| `3600`+ | 低频 | 订阅流量、油价、节假日 |

首次执行前显示静态 `content`；之后显示上次缓存，直到下次刷新。

### 5.3 手动刷新不是独立的动作确认

手册明确：手动刷新会调用脚本并传入 `$trigger="button"`，到期刷新为 `auto-interval`。它不是可靠的“点击卡片执行操作 / 点刷新只读”区分器。

默认面板保持只读；切换策略、清 DNS、执行签到等动作放到独立 generic 脚本或用户明确触发的快捷指令。若刻意让手动刷新触发动作，必须在标题和说明写明副作用，并检查 `$surge` setter 返回值，不能无条件展示“已成功”。

`$input` = `{purpose:"panel", position, panelName}`。

### 5.4 常用面板

- 策略组：`$httpAPI("GET", "/v1/policy_groups", null, cb)` + `$surge.setSelectGroupPolicy`。
- 清 DNS：`$httpAPI("POST", "/v1/dns/flush", null, cb)`，再查 `dns_delay`。
- 订阅流量：读响应头 `subscription-userinfo`（`upload; download; total; expire`）。
- 网络信息：`$network` + 外部 IP API。
- 动态图标：按国家/剩余天数/速度返回不同 SF Symbol 与 `icon-color`。

### 5.5 面板返回字段

```js
$done({
  title: "标题",            // 必填
  content: "第一行\n第二行",
  style: "info",            // good/info/alert/error
  icon: "bolt.horizontal.circle.fill",
  "icon-color": "#FF0000"   // 必须加引号
});
```

没有 `style` 时卡片只显示文字和图标；`content` 用 `\n` 换行。

## 6. DNS 类模块

### 6.1 强制 DoH/DoQ

```ini
[General]
encrypted-dns-server = https://dns.example.com/dns-query
encrypted-dns-follow-outbound-mode = false
```

- 直接覆写用户的 DNS 风险高；建议做成独立模块，desc 说明会覆盖。
- 指定域名走特定 DNS 用 `[Host]` 的 `server:`，不要全局改。

### 6.2 按域名分流 DNS

```ini
[Host]
example.com = server:https://doh.example.com/dns-query
*.example.com = server:8.8.8.8
```

### 6.3 拦截 HTTPDNS

```ini
[Rule]
DOMAIN,httpdns.example.com,REJECT,extended-matching,pre-matching

[General]
force-http-engine-hosts = %APPEND% 119.29.29.29:80, dns.example.com:80
```

force-http-engine-hosts 只强制识别明文 HTTP；不能把原始 DNS 协议或 QUIC 变成 HTTP。硬编码 UDP DNS 用 hijack-dns；DoH/DoT/应用 HTTPDNS 应按真实协议分别分析。

### 6.4 自定义解析脚本

```ini
[Host]
example.com = script:dnspod

[Script]
dnspod = type=dns, engine=jsc, script-path=https://example.com/js/dns.js
```

```js
$httpClient.get("http://119.29.29.29/d?dn=" + $domain, (err, resp, data) => {
  if (err) return $done({});
  $done({addresses: data.split(";"), ttl: 600});
});
```

## 7. 规则集 / 域名集

- 大量纯域名：`DOMAIN-SET`（每行 `example.com` 或 `.example.org`），内存/索引更优。
- 混合类型：`RULE-SET`（文件内不写策略）。
- 内联：`[Ruleset Name]` + `RULE-SET,Name,Policy`；可嵌套 8 层。
- 模块只能向同名内联规则集追加行，不能删除。
- 远程列表设 `update-interval`；本地文件会自动监视变更。
- 同一 URL 不能同时作为 RULE-SET 和 DOMAIN-SET。

## 8. 正则速查（模块里最常用的）

| 目标 | 写法 |
|---|---|
| 锚定域名 | `^https?://api\.example\.com/` |
| 可选子域 | `^https?://([a-z0-9-]+\.)?example\.com/` |
| 路径段 | `/v1/(feed|list|config)(\?|$)` |
| 查询参数 | `[?&]ad=1(&|$)` |
| 数字 ID | `/item/(\d+)/` |
| 不匹配某路径 | 用 `REJECT` 规则 + 例外规则，别写复杂负向前瞻 |
| JSON 字段 | `"ads"\s*:\s*\[[^\]]*\]` |

原则：能锚定就锚定；能用 jq 就不用正则改 JSON；正则里 `?`、`.`、`/` 该转义就转义；避免嵌套量词。

## 9. 模块组合与参数化

- **可关闭功能**：用独立模块开关，或把 enabled 传给脚本并在关闭时原样放行；不要用非法脚本名/域名实现禁用。行首占位符变成注释才是可解释的文本替换，行中 `#` 不可靠。
- **策略选择**：模块规则不能指向用户的策略组；需要指定出口时，让用户在主配置写规则，或把策略名放在脚本逻辑里处理。
- **多面板**：`{{{NAME_1}}}`…`{{{NAME_4}}}` 生成多个面板，每个对应一条脚本。
- **参数化 MITM**：`hostname = %APPEND% {{{hostname}}}`，但默认值必须是真实域名。
- **版本门控**：`#!requirement=CORE_VERSION>=20`。
- **平台门控**：`#!system=mac` 或行级 `#!MACOS-ONLY`。

## 10. 反模式清单

1. 在 http-request 里同步发多个网络请求，拖垮请求。
2. `requires-body=true` + `max-size=-1` 处理大响应，iOS OOM。
3. 忘记 `$done()`，或异常时没有兜底。
4. 改 header 破坏分帧。
5. MITM 范围过宽（`*`、`*.tencent.com`）。
6. 脚本 URL 写死个人域名/`latest`，失效或静默变更。
7. 明文密码/Token 写进模块。
8. cron 过频、面板 `update-interval=1`。
9. 参数占位符未声明、大小写不一致、引号不闭合。
10. 直接覆写用户的 DNS/加密 DNS。
11. 照搬 Loon 的 `[Plugin]`/`[Rewrite]` 写法，或误用 `max-size=0`。
12. 成品里残留 `example.com` 占位域名。
13. 用 `REJECT-DROP` 作为模块规则的默认策略（超出模块文档）。
14. 忽略 HTTP 引擎/MITM 的前提；新增分流规则不是让脚本生效的通用要求。

## 11. 案例索引（语料路径）

| 主题 | 文件 |
|---|---|
| 最简面板 | `rabbit/Module/Panel/IP-Check/Moore/IP-Check.sgmodule` |
| 可交互策略组面板 | `rabbit/Module/Panel/Group-Panel/Moore/Group-Panel.js` |
| 清 DNS 面板 | `rabbit/Module/Panel/Flush-DNS/Moore/Flush-DNS.js` |
| 订阅信息面板（参数/字节/到期） | `rabbit/Module/Panel/Sub-info/Moore/Sub-info.sgmodule` + `.js` |
| 单功能 Spec 模块 | `rabbit/Module/Spec/TestFlight/Moore/TestFlight.sgmodule` |
| 四种脚本共用一个 JS | `kiss/Surge/Official/联通余量.official.sgmodule` |
| 请求+事件+面板共用 | `kiss/Surge/Official/网络信息 X.official.sgmodule` |
| protobuf/gRPC | `kiss/Surge/Official/🍟 BiliGlobal.official.sgmodule` |
| 地区解锁 + 参数化策略 | `kiss/Surge/Official/🍟 Apple News 解锁.official.sgmodule` |
| DNS 分流/DoH | `kiss/Surge/Official/🍟 DNS 分流.official.sgmodule`、`rabbit/Module/Spec/DoH/` |
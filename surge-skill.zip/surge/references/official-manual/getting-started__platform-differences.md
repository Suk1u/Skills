https://manual.nssurge.com/getting-started/platform-differences.html

# Platform Differences

# Platform Differences

Surge Mac and Surge iOS share the same core engine and profile format, and most options behave identically. This page consolidates the differences: features exclusive to one platform and where each is documented.

Surge tvOS is included with the Surge iOS app and generally behaves like Surge iOS; features marked iOS-only usually apply to tvOS as well unless noted on the feature's page.

## Surge Mac Only

| Feature  | Notes  | Documentation

| Enhanced Mode toggle  | The VIF must be enabled manually on Mac; on iOS it is part of the VPN takeover and enabled by default.  | Enhanced Mode

| Gateway Mode  | Operate as a layer-3 gateway handling traffic for other LAN devices.  | Gateway Mode

| DHCP server  | Provide DHCP service for gateway-managed devices, with the [DHCP] section for lease tuning.  | DHCP

| Ponte server role  | Any Surge device can act as a Ponte client, but only Surge Mac can serve as the Ponte server (home network access point).  | Surge Ponte

| External Proxy Program  | Launch and manage an external proxy executable as a policy. Surge iOS treats external policies as REJECT.  | External Proxy Program

| PROCESS-NAME rule  | Match traffic by the originating process. Surge iOS ignores these rules.  | Process Rules

| MAC-ADDRESS rule  | Match LAN client devices by MAC address.  | Source and Port Rules

| surge-cli  | Command-line tool for controlling local and remote instances.  | CLI

| Surge Dashboard app  | The Dashboard app ships with Surge Mac; it can also connect to remote Surge iOS instances over network or USB.  | Dashboard

| Mac-only [General] keys  | http-listen, socks5-listen, read-etc-hosts, set-system-socks-proxy, subnet-exp-wifi-always-match.  | General Section

### Metered Network Mode

Surge Mac can restrict which applications and processes may access the Internet, which is useful on metered connections such as a phone hotspot. The allowed application list is configured in the Surge Mac interface. The mode can be turned on automatically for specific networks with the cellular-mode parameter in Subnet Settings.

## Surge iOS Only

| Feature  | Notes  | Documentation

| Works on cellular  | Surge iOS runs as a Network Extension VPN, so all functions work on Wi-Fi and cellular networks alike.  | How Surge Works

| compatibility-mode  | Selects the takeover mode (proxy takeover, VIF takeover, or combinations) to work around app-specific issues.  | General Section

| CELLULAR policy family  | CELLULAR, CELLULAR-ONLY, HYBRID, NO-HYBRID built-in policies for controlling interface usage.  | Built-in Policies

| hybrid policy parameter  | Set up proxy connections over Wi-Fi and cellular simultaneously.  | Policy Parameters

| CELLULAR-RADIO / CELLULAR-CARRIER rules  | Match by radio access technology or carrier (also available on tvOS).  | Protocol and Network Rules

| Cellular Fallback subnet setting  | Per-network override of Wi-Fi Assist / All-Hybrid behavior.  | Subnet Settings

| URL scheme start/stop actions  | start, stop, and toggle URL scheme actions are iOS-only.  | URL Scheme

| iOS-only [General] keys  | allow-wifi-access, allow-hotspot-access, wifi-access-http-port, wifi-access-socks5-port, wifi-access-http-auth, wifi-assist, all-hybrid, hide-vpn-icon, include-all-networks, include-local-networks, include-apns, include-cellular-services, include-device-communication, auto-suspend.  | General Section

Platform-specific keys are simply ignored on the other platform, so a single profile can be shared between Surge Mac and Surge iOS. To restrict individual profile lines to one platform, use line requirement expressions such as #!MACOS-ONLY.

#  results matching ""

# No results matching ""

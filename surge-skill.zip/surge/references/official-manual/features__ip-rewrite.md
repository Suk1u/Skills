https://manual.nssurge.com/features/ip-rewrite.html

# IP Rewrite

# IP Rewrite iOS 5.23.0+ Mac 6.10.0+

The [IP Rewrite] section decides what happens to a packet entering Surge VIF based on its destination address. It works at the IP layer: a matching packet is handled as soon as it arrives, before it reaches Surge's TCP/UDP stacks, rules or policies, and it never shows up as a request.

```

[IP Rewrite]
10.7.0.1 = reflect
203.0.113.0/24 = reject
2001:db8::/32 = drop

```

Each line takes the form:

```

<IP address or CIDR> = <action>

```

The lines are evaluated from top to bottom, and the first matching line wins. IPv4 and IPv6 addresses are both supported.

This section only applies to traffic handled by Surge VIF, i.e. Enhanced Mode and Gateway Mode. Requests sent to Surge's proxy server are not affected.

The packets must be routed to Surge VIF in the first place. If an address is covered by tun-excluded-routes or a local network route, add it to tun-included-routes.

## Actions

#### reflect

The packet is sent straight back to its sender with the source and destination addresses swapped. To the sender, the address behaves like a peer that loops all its traffic back to the sender itself. In Gateway Mode, a packet from a LAN device is reflected back to that device.

#### reject

A TCP connection attempt is answered with a TCP RST, and other packets with an ICMP "administratively prohibited" message, so the sender fails immediately instead of waiting for a timeout.

#### drop

The packet is silently discarded.

## Example: On-Device Developer Services

Tools such as SideStore talk to the device's own developer services through 10.7.0.1, and normally require a dedicated VPN such as LocalDevVPN that loops this address back to the device. Since only one VPN can be active at a time, Surge can take over this role:

```

[General]
ipv6-vif = disabled
tun-included-routes = %INSERT% 10.7.0.1/32

[IP Rewrite]
10.7.0.1 = reflect

```

The snippet is written as a module so it can be toggled on its own. SideStore ignores VPN interfaces with an IPv6 address when looking for this loopback, hence ipv6-vif = disabled. tun-included-routes makes sure 10.7.0.1 reaches Surge VIF even when it belongs to an excluded or local network range.

#  results matching ""

# No results matching ""

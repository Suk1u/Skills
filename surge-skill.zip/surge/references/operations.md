# 场景工作流与资格检查

来源与版本以 sources.md / source-index.json 为准。所有操作先读状态；本 skill 的维护和审查不等于授权修改用户的运行中网络。

## 1. 接入服务商 / 机场订阅

三种模式：

| 模式 | 适合 | 代价 |
|---|---|---|
| 托管 Profile | 服务商维护线路、规则和全局配置 | 本地不能随意改，更新会覆盖 |
| 分离段 / 关联配置 | 用 #!include 跟踪服务商某些段，其余本地维护 | 需理解哪些段跟踪上游 |
| policy-path 外部策略组 | 本地完整控制规则，仅从服务商取代理列表 | 需自己写组和规则 |

术语：**分离段**是 #!include 指向的配置部分；**关联配置（Linked Profile）**是持续跟踪远程配置的本地层，建立在 include/分层机制上；**模块**是可独立开关的补丁，三者不是同义词。

主配置示例（不是模块）：

```ini
[Proxy Group]
Provider = select, policy-path=https://provider.example/subscription, hidden=true
US = smart, include-other-group=Provider, policy-regex-filter="US|美国"
Proxy = select, US, Provider, DIRECT

[Rule]
DOMAIN-SUFFIX,example.com,Proxy
FINAL,Proxy,dns-failed
```

- policy-path 接受每行一个 [Proxy] 格式的策略列表，或含 [Proxy] 的完整 Surge Profile。
- Smart 不直接嵌套 Provider 组；include-other-group 导入其成员后再过滤。过滤结果为空时可能出现 SUBSTITUTE/DIRECT 回退，先检查成员，不把它视为防泄漏配置。
- 多供应商给 external-policy-name-prefix 加前缀避免重名；include-other-group 多组要引号包住。
- external-policy-modifier 只修改 policy-path 导入的策略；组级 underlying-proxy（iOS 5.22+/Mac 6.9+）覆盖多种成员来源。
- 更新间隔不是每次启动立即强制更新。可用 external_resources 查看 ready/error/updatedAt，再按需更新。
- 订阅 URL 通常包含凭据。不要上传第三方转换服务、截图公开、写入公共报告；固定仓库模块 commit 并不固定其外部脚本的分支 URL 内容。

## 2. iOS 版本、订阅与功能资格

安装版本和功能解锁资格是两回事。

- iOS Smart 从 5.11.0 起引入并属于订阅功能；用户可能安装了新版本但未解锁该功能。先看 App 的授权/功能页面，再决定是否用 smart；不符合时使用 url-test/fallback。
- Panel 手册有独立说明：iOS 4.9.3+，并依赖符合条件的有效订阅。不能把“其他已解锁功能可继续用”的一般规则机械套用到 Panel 显示。
- Mac 与 iOS 授权独立；Mac 维护订阅与 iOS 功能订阅也不同。不要写死价格或把续费作为技术排障的默认答案。
- tvOS 知识库说明已购 iOS 用户可使用，不另购 tvOS 功能订阅；实际部署资格以账号和 App 界面为准。

## 3. tvOS 部署与排障

知识库指南：tvOS 17 引入 Network Extension，配置由 Surge iOS（5.7.0+）部署，Apple TV 与控制端账号条件必须满足。

1. 在 Apple TV 安装 Surge tvOS，按 Surge iOS 的“更多 → Surge tvOS”向导部署配置。
2. tvOS 不能像 iOS 一样直接从 iCloud Drive 打开本地 Profile；不要给 tvOS 用户本地文本编辑操作。
3. 初次加载外部资源可能尚未完成，导致外置组/规则为空或回退；看远程控制器的资源状态与日志，完成下载后再判定分流。
4. 使用 iOS 远程控制器或 Mac Dashboard 检查请求、模块和脚本。tvOS 仅 JSC，依赖 WebView/fetch/crypto 的脚本必须重新评估兼容性。
5. 指南记录主界面按三次播放键可进入调试菜单；UI 路径随版本变化，以设备界面为准。

**冲突说明**：tvOS/Ponte 的知识库旧文曾称 Apple TV 可作 Ponte 服务端，保存的现行手册却只列 Mac 服务端。这里不把两者强行合并；不要以本 skill 保证 tvOS 的服务端角色，先查目标版本 UI/最新官方说明。Snell 内置服务端是另一个功能，不能与 Ponte 服务端混为一谈。

## 4. 远程控制的连接边界

- 外部 Controller、HTTP API、Web Dashboard 是不同入口，密码/端口不要混淆。
- 从 Mac 用 surge-cli --remote 控制符合版本条件的 iOS/tvOS；iOS 本机没有 Mac CLI 程序。
- iOS Controller 默认倾向 USB；局域网访问需在设备启用 Wi-Fi 访问。蜂窝连接边界按官方指南与当前 UI；不要把本地 0.0.0.0 自动视为安全的互联网服务。
- Controller 局域网直连不加密；HTTP API 未启 TLS 时 key 也明文传输。默认用 loopback/可信局域网，不配置公网端口转发或 DMZ。
- 读取请求 body/脚本日志会接触 Cookie/个人信息；先缩小捕获过滤器，报告中脱敏。
- DNS 清空、策略切换、重载、模块开关、脚本执行、停止 Surge 都有副作用。先说明影响，按用户本次授权执行，完成后恢复临时设置。

## 5. 游戏 / STUN / NAT 类型

知识库把 UDP NAT 分成：A Full Cone、B Address Restricted、C Port Restricted、D Symmetric。名称在不同检测软件里可能不同。

- VIF 引入地址转换可能把原 A 类型变成 B；已有 B/C/D 不因这层转换自动改善。
- 游戏/STUN 确有需求时，针对相关域名返回真实 IP，而不是全局关闭 Fake IP：

```ini
[General]
always-real-ip = *.srv.nintendo.net, *.stun.playstation.net, xbox.*.microsoft.com, *.xboxlive.com
```

- 上面是主配置示例；模块扩展已有列表时加 %APPEND%。不是所有游戏都只用这些域名，要根据流量和 NAT 检测验证。
- 走代理时出口 NAT 类型主要取决于代理端；本地 DNS 设置不能修复代理服务器的 UDP 防火墙或 NAT。
- 丢包和检测失败也会让 NAT 结果变差。先测 UDP relay、线路丢包与目标可达性，别机械把失败判成 Symmetric NAT。

## 6. TFO 与网关性能

- tfo 默认关闭，服务端与网络都需要支持；打开后并不保证一定降低延迟。
- 系统 blackhole 检测可能因丢包/切网而抑制 TFO。只有实测当前网络支持时才考虑 SSID Setting 的 tfo-behaviour=force-enabled。
- 不建议为了修复单条线路而全局关闭系统 TCP heuristics，或把 force-enabled 当通用优化。
- 带宽测试会产生真实下载/上传流量并计入服务商用量。比较空配置/DIRECT/代理结果时使用同一测试目标与窗口，先获准，不凭“延迟低”断言带宽高。

## 7. L3 策略与访问控制

- WireGuard/Tailscale 的 allowed-ips、exit-node、subnet route 决定数据可送到哪里，不等于目标端开启转发、NAT 或防火墙放行。
- 这是 Surge 的出站策略，不自动替换系统全局 WireGuard/Tailscale 客户端。
- allow-peer-access、listen-port、advertise-exit-node、advertise-routes 会扩大入站/转发能力。先按精确 peer/source 范围写规则，不默认公开。
- 保存的 Tailscale 手册明确提示 Surge 不在入站连接上自行执行 tailnet ACL；allow-peer-access 场景需要补充 SRC-IP 等限制，不能仅凭“已登录 tailnet”假设所有访问受 ACL 保护。
- 网络、control-url、DERP 或 DNS 的 underlying-proxy 关系不同，避免依赖自身产生循环；复杂问题查 official-manual 中相应专题，而不是只复制最小样例。

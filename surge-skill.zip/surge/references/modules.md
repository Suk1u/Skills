# Surge 模块（.sgmodule）编写指南

模块是对当前配置的**补丁**，优先级高于主配置，可独立开关。适合：给不可编辑的托管配置打补丁、一键切换某项设置、分发别人写好的功能、按设备/场景定制。

## 1. 模块 vs 分离配置

| | 模块 `.sgmodule` | 分离配置 `.dconf` |
|---|---|---|
| 本质 | 覆盖/追加主配置的某些段 | 把主配置的段拆到另一个文件 |
| 生效 | 启用后覆盖主配置 | 始终是主配置的一部分 |
| 可关闭 | 是，独立开关 | 否 |
| 能改 Proxy/策略组 | 否 | 是（作为配置的一部分） |
| 适合 | 临时补丁、功能分发 | 线路/规则拆分、多设备共享 |

模块启用状态**不会**通过 iCloud 同步到其他设备。

## 2. 模块能改什么

官方文档列出的可覆盖段：

| 段 | 合并语义 |
|---|---|
| `[General]`、`[MITM]` | `key = value` 覆盖；`key = %APPEND% value` 追加；`key = %INSERT% value` 前插。MITM 只能操作 `hostname` 和 `skip-server-cert-verify` |
| `[WireGuard *]` | 覆盖/追加键 |
| `[MTProto]` | 整段替换；iOS 5.21.0+ / Mac 6.8.0+ |
| `[Snell Server]` | 整段替换；iOS 5.23.0+ / Mac 6.10.0+ |
| `[Ruleset *]` | 合并同名内联规则集或新建；不能删除/重排；iOS 5.23.0+ / Mac 6.10.0+ |
| `[Rule]`、`[Script]`、`[URL Rewrite]`、`[Header Rewrite]`、`[Host]`、`[IP Rewrite]` | 新行插入到原内容**顶部** |

仓库样例还广泛使用 `[Map Local]`、`[Body Rewrite]`、`[Panel]`；模块专题列表没有完整列出它们，且 requirement 章节明确以 Body Rewrite 为例。不能据此断言功能不存在，也不能仅凭样例推断所有合并细节；在目标版本查看有效配置并实测。`[Keystore]`、`[Tailscale *]`、`[DHCP]` 等主配置段不在模块覆写列表，检查器会提示核对。

**不能做**：

- 不能定义或修改 `[Proxy]`、`[Proxy Group]`。
- 不能改 MITM 的 CA 证书（`ca-p12`/`ca-passphrase`/`ca-keystore-name`）。
- 模块中的 `[Rule]` 只能用内置策略：`DIRECT`、`REJECT`、`REJECT-TINYGIF`（语料里也见 `REJECT-DROP`/`REJECT-NO-DROP`，但超出文档承诺，不建议依赖）。
- 模块可以覆盖原本可在 UI 编辑的设置；覆盖生效期间该设置受模块控制，不能直接通过 UI 调整有效值。

## 3. 文件与元数据

文件名任意，扩展名 `.sgmodule`；UTF-8 纯文本。`#!` 行必须位于第一个 `[Section]` 之前。

```ini
#!name=Example: Remove Ads
#!desc=Blocks banner and splash ads in Example App. Requires MITM.
#!system=ios
#!category=Ads
#!author=Your Name
#!homepage=https://example.com/module
#!icon=https://example.com/icon.png
#!date=2026-11-05
#!version=1.0.0
#!arguments=enableLog:false
#!arguments-desc=Optional debug logging for this module.
```

### 官方文档保证的键

| 键 | 说明 |
|---|---|
| `#!name` | 模块显示名；本 skill 要求交付时提供，手册把 metadata 描述为可添加 |
| `#!desc` | 描述（强烈建议） |
| `#!system` | 限制平台，如 `ios`、`mac`、`tvos` |
| `#!arguments` | 参数表声明 |
| `#!arguments-desc` | 参数表整体说明（不是逐项说明，但社区普遍当逐项文档用） |
| `#!requirement` | 版本/平台条件表达式 |

### 客户端识别但手册未列的键

category 有 iOS 更新日志的分类功能证据。author/homepage/icon/version/date 等在仓库里常见，但保存的模块手册未逐项说明渲染效果；不能保证每个平台/版本都会展示。loon_version/openUrl/tag/system_version/repo 等也不作为 Surge 的功能或版本门槛，应移除无关项或保留为说明，不凭它们判断可用性。

统一使用规范写法 `#!system=ios` 或 `#!system=mac`；手册未列全所有可接受 platform 别名，不能断言多一个空格一定失效。`#!auther` 是拼写问题，建议改为 author。

## 4. 参数表（Module Arguments）

手册标注 Mac 5.5.0+；iOS 更新日志在 5.9.0 记录了模块参数表。以安装设备的功能版本与 UI 为准。

```ini
#!arguments=hostname:example.com, enable_mitm:true
#!arguments-desc=配置目标域名与是否启用 MITM。
```

- 逗号分隔 `键:默认值`；默认值可省略，但发布前必须验证用户未填写时的实际行为，检查器不会把它自动当成可靠的空字符串。含逗号/空格的值用双引号包住。
- 键名建议只用字母、数字、下划线；文档明确要求。中文键、`Languages[0]`、`UPDATE-INTERVAL` 在语料中存在且似乎可用，但不要主动使用。
- `#!arguments-desc` 按手册是**整表说明**；社区常写成逐项说明（用 `\n` 分隔），但不要依赖它作为唯一的参数文档——逐项说明最好同时写进 `#!desc` 或 README。
- 引用：`{{{键}}}`，**大小写敏感**；应用模块前做纯文本替换，可出现在任意段、任意位置（包括脚本名、规则值、面板名、MITM 主机名）。注意：替换不改变模块规则只能用内置策略的限制，不能把策略位替换成用户策略组。
- 未声明的占位符不会被替换，且可能导致配置校验失败；声明了但未使用的参数是死参数。
- 用户填写的值保存在模块实例中，下次编辑会回显。
- 不支持 `%PARAMETER%` 和 query-string 形式。

```ini
[General]
force-http-engine-hosts = %APPEND% {{{hostname}}}

[MITM]
hostname = %APPEND% {{{hostname}}}

[Script]
example = type=generic, script-path=script/example.js, argument="{{{enable_mitm}}}"
```

脚本里通过 `$argument` 读取 `argument=` 的字符串。约定可用 `k=v&k=v`（Rabbit 风格），脚本自行 split；值含 `=`/`&` 时先 `encodeURIComponent`。

**参数是文本替换，不是条件语法**。不要通过不存在的脚本名、非法域名或空策略来禁用功能，这可能导致校验失败。社区把行首占位符替换为 `#` 的用法只有在替换后确实形成注释行时才有明确含义；行中 `#` 并不可靠。推荐用多个独立模块，或把 `enabled` 参数传给脚本，由脚本在关闭时 `$done({})` 放行（缓冲开销仍可能存在）。

## 5. 版本与平台条件

模块头 `#!requirement=`：iOS 5.10.0+ / Mac 5.6.0+；不要与稍晚出现的行级 `#!REQUIREMENT` 混淆。

```ini
#!requirement=CORE_VERSION>=20
#!requirement=CORE_VERSION>=20 && (SYSTEM=='iOS' || SYSTEM=='tvOS')
```

变量：`CORE_VERSION`（数字）、`SYSTEM`（macOS/iOS/tvOS）、`SYSTEM_VERSION`、`DEVICE_MODEL`、`LANGUAGE`。运算符与行级条件相同（`>=`、`&&`、`||`、`==`、`CONTAINS` 等）。

Core Version 参考：

- `20` = Surge Mac 5.6.0 / iOS 5.10.0（Body Rewrite、内联 Map Local）
- `22` = Mac 5.7.0 / iOS 5.11.0（Smart Group）
- 新规则：`major*1000000 + minor*1000 + patch`，如 Mac 6.8.0/iOS 5.21.0 = `6008000`

## 6. [Script] 在模块中的写法

```ini
[Script]
ads = type=http-response, pattern=^https?://api\.example\.com/v1/feed, script-path=https://example.com/js/ads.js, requires-body=true, max-size=1048576, timeout=10, engine=webview, argument="{{{enableLog}}}"
```

- 现代写法 `name = type=...,pattern=...,script-path=...`；旧式 `<type> <pattern> script-path=...` 仍兼容但不推荐。
- 模块内脚本名要唯一、稳定；Panel 的 `script-name` 必须逐字一致。
- **相对 `script-path` 相对 profile 目录，不是模块所在目录**。分发给他人时用 https URL；本地开发才用相对路径。
- 远程脚本建议固定版本，审查时最好固定 commit；`latest` 或分支 URL 的内容可能变化。语料常见 `script-update-interval=0`，但手册未明确 0 的语义，新写默认保持 86400 或填写合理正数，不把 0 解释成每次运行必下载。
- `requires-body` 尽量少开；`max-size` 用明确字节数，`-1` 才是不限制（`0` 的语义未文档化）。
- protobuf/gRPC 用 `binary-body-mode=1`；大 JSON 用 `engine=webview`；`rule`/`dns` 用 `jsc`。
- cron 脚本在 iOS 上加 `wake-system=1`，并避免每小时超过 10 次。
- 脚本里的 `$done()` 必须恰好一次；异常要兜底。

## 7. [MITM] 在模块中的写法

```ini
[MITM]
hostname = %APPEND% api.example.com, cdn.example.com
```

- `hostname` 是 Host List，不是正则：`*`/`?` 通配，`-` 排除且要放前面，`:port` 指定端口。
- 模块只能改 `hostname` 与 `skip-server-cert-verify`。
- 只列脚本/重写真正需要的域名；不要习惯性 `*`。
- 非标准端口的明文 HTTP 用 `[General] force-http-engine-hosts = %APPEND% host:port`；不想被解析的主机用 `always-raw-tcp-hosts`。
- 对 HTTPS 消息的重写和 http-request/http-response 脚本需要对应 MITM；纯规则、cron、generic、DNS 与 rule 脚本不依赖 MITM。

## 8. 模块与 Loon / 其他客户端

KISS（LoonKissSurge）语料里仍有大量 Loon 痕迹。移植到 Surge 时：

| Loon 写法 | Surge 处理 |
|---|---|
| loon_version/openUrl/system_version/tag | 不作为 Surge 功能保证；是样例中的额外元数据，可删除不相关项 |
| `hostname-disabled = ...` | **Surge 支持**（MITM 段，从有效 hostname 列表中移除主机）；模块只能改 `hostname` 与 `skip-server-cert-verify`，不要依赖它 |
| `[Plugin]` 段 | Surge 不识别；内容是元数据，移到 `#!` 头 |
| `[Rewrite]` 段 | Surge 拆成 `[URL Rewrite]` / `[Header Rewrite]`；需按行转换 |
| `^url - reject`（Loon URL Rewrite） | Surge 文档写作 `^url _ reject`（正则、替换占位、类型）。`-` 在实践中也能被接受（语料大量使用），但新写用 `_` |
| `type=...,pattern=...,script-path=...` | Surge 支持（现代写法） |
| `requires-body=true` / `1` | 两者都支持 |
| `max-size=0` | 未文档化；改用 `-1` 或明确字节数 |
| `%APPEND%` / `%INSERT%` | Surge 支持（General/MITM） |
| `$httpClient`、`$persistentStore`、`$notification`、`$done`、`$argument` | 基本兼容，但参数顺序/字段需逐个核对 |
| `argument="[...]"` 数组式 | Surge 只把它当普通字符串；脚本自行解析 |
| 中文/带连字符参数名 | 可能可用，但非文档保证；发布建议 ASCII+下划线 |

转换后务必用 linter + 真机验证；语法"看起来对"不等于 Surge 会接受。

## 9. 模块分发

- 托管：把 `.sgmodule` 放在可公开访问的 HTTPS URL（GitHub raw 最常用）。
- 安装：Surge 内"模块 → 安装模块 → 输入 URL"，或 `surge:///install-module?url=<URL-encoded>`。
- 本地模块：把 `.sgmodule` 放进 profile 目录。
- 建议同时提供：`#!name`、`#!desc`、`#!author`、`#!homepage`（README/使用说明）、`#!icon`、`#!category`、`#!date`、`#!version`。
- README 写清：用途、安装链接、必填参数、如何获取 Cookie/Token、更新方式、已知限制、兼容版本。
- 不要分发个人密码、Cookie、token。参数表和 `$persistentStore` 也不是加密保险库；敏感值可能出现在本地配置、备份、日志或传给远程脚本。最小化存储、避免日志输出，向用户说明脚本访问范围。
- 远程脚本 = 远程代码执行；只引用可信来源，并尽量固定版本。

## 10. 应用顺序与冲突

- 模块设置覆盖主配置；多个模块同时启用时，相对顺序会影响冲突结果。
- 行式段是"插入到顶部"：模块规则先于主配置规则；模块之间的相对行序也可能受应用顺序影响。
- 不要依赖隐式顺序。用 `surge-cli profile diff` 查看应用模块后的最终配置。
- 与其他模块冲突时：缩小 MITM/规则范围、用更具体的域名、把可选项做成参数。

## 11. 调试与验证

1. 安装/启用模块，确认没有配置校验错误。
2. `surge-cli profile diff` 看最终合并结果。
3. 请求查看器确认请求进入 HTTP 引擎、命中规则/脚本，查看 Notes。
4. 脚本：`debug=true` + `console.log`；或脚本编辑器手动运行；Logbook 远程看日志。
5. 面板：先看静态 content，点刷新看脚本返回；省略 update-interval 可用于手动验证。社区使用 -1 的行为未在手册明确承诺。
6. 关掉模块再测一次，确认问题确实由模块引起。
7. iOS 上注意 NE 内存：大 body、`max-size=-1`、WebView 大对象都可能导致进程被系统终止。

## 12. 发布前检查清单

**结构**
- [ ] `#!name`、`#!desc` 存在；需要时加 `category/icon/homepage/author/date/version`。
- [ ] 只改允许的段；没有 `[Proxy]`/`[Proxy Group]`/CA。
- [ ] 扩展列表时优先 `%APPEND%`/`%INSERT%`；布尔值、数值等标量应直接赋值，不能机械追加。
- [ ] 模块规则只用 `DIRECT`/`REJECT`/`REJECT-TINYGIF`。
- [ ] 所有 `{{{占位符}}}` 都在 `#!arguments` 中声明，且没有多余参数。
- [ ] 没有残留 `example.com` 占位域名。

**脚本**
- [ ] 每条脚本有 `type`、`script-path`；HTTP 类有 `pattern`。
- [ ] `requires-body` 只在必要 URL 开启；`max-size` 合理。
- [ ] 远程脚本固定版本；本地脚本不用于分发。
- [ ] 每个分支恰好一次 `$done()`；异常有兜底。
- [ ] 脚本名与 Panel `script-name` 一致。

**MITM**
- [ ] hostname 只覆盖必要域名；排除项在前。
- [ ] 需要 MITM 的模块在 desc 中明确提示用户开启 MITM 并安装 CA。
- [ ] 不需要 MITM 的模块（纯 cron/panel）不要声明 MITM。

**发布**
- [ ] 真机验证：安装 → 启用 → 触发 → 看 Notes/日志 → 关闭 → 确认无残留。
- [ ] README 完整；参数有说明；版本/日期更新。
- [ ] 用 `python3 -I ~/.claude/skills/surge/scripts/surge_module_lint.py module.sgmodule` 跑一遍；依赖本地脚本时加 `--profile-dir`，另用 Surge/LSP 检查与真机验证。

## 13. 语料中的真实反模式

- 在 http-request 脚本里串行发网络请求，导致请求卡到 timeout。
- `requires-body=true` + `max-size=-1` 处理 MB 级 protobuf，iOS 上 OOM。
- 缺少 `$done()` 或异常路径不兜底，表现为"装上了但没效果"。
- 修改 header 时破坏 Content-Length/Transfer-Encoding。
- MITM 用 `*` 或 `*.tencent.com` 这类过宽范围。
- 脚本 URL 写死个人域名，域名失效后模块全挂。
- 把账号密码写进 JS 或模块。
- cron `*/5 * * * *` + 面板 `update-interval=1`，耗电。
- 参数占位符未声明/大小写不一致、`argument` 引号不闭合。
- 在模块里直接覆写用户的 `dns-server`/`encrypted-dns-server`，与用户配置冲突。
- 直接照搬 Loon 的 `max-size=0`、中文参数名，或误以为 Surge 不支持 `hostname-disabled`。

## 14. 模板

- `assets/module-minimal.sgmodule`
- `assets/module-rewrite.sgmodule`
- `assets/module-script.sgmodule`
- `assets/module-panel.sgmodule`
- `assets/script-http-response.js`（响应改写脚本模板）
- `assets/script-panel.js`（面板脚本模板）

用 `python3 -I ~/.claude/skills/surge/scripts/surge_module_lint.py <file>` 做辅助检查。

检查器不是 Surge 解析器：支持现代/旧式脚本声明，展开已提供的参数默认值与 `--arg`（只用于非敏感值），允许多个不同名 WireGuard/Ruleset 段；未提供参数值或 profile 目录的部分会明确标为未检查。`--strict` 把警告升级为错误，但并不能完成 Surge 实际加载验证。
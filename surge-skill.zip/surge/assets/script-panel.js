// Template: generic script used as a Surge Panel data source.
// Module lines:
//   [Panel]
//   ExampleStatus = title="Example Status", content="Loading…", style=info, \
//                   script-name=example-status, update-interval=60
//   [Script]
//   example-status = type=generic, timeout=10, script-path=https://example.com/js/status-panel.js
//
// Rules:
// - Panel results require {title, content, style?, icon?, "icon-color"?}.
// - Manual refresh can set $trigger="button"; it is not a separate action confirmation.
// - update-interval is checked when the panel is opened, not an always-running timer.
// - This panel is read-only; never change policy selections on refresh.
// - Call $done() exactly once.

(function () {
  function fail(message) {
    $done({ title: "Example Status", content: message, style: "error" });
  }

  if (typeof $httpClient === "undefined") {
    fail("This script must run inside Surge.");
    return;
  }

  $httpClient.get({ url: "https://api.ipify.org?format=json", timeout: 8 }, function (err, resp, data) {
    if (err) {
      fail("Request failed: " + err);
      return;
    }
    if (!resp || resp.status !== 200) {
      fail("HTTP " + (resp ? resp.status : "missing response"));
      return;
    }
    try {
      var body = JSON.parse(data);
      if (!body || typeof body.ip !== "string" || !body.ip) {
        fail("Unexpected IP service response");
        return;
      }
      $done({title: "Example Status", content: "Public IP: " + body.ip, style: "info"});
    } catch (e) {
      fail("Invalid IP service response");
    }
  });
})();
#!/usr/bin/env python3
"""Mocked JS template tests using macOS JavaScriptCore, no real HTTP or Surge.

Run: python3 -I /absolute/path/to/this_file.py
Skips explicitly if JavaScriptCore CLI is unavailable. Passing proves only
syntax and mocked branches, NOT Surge loading, APIs or network interception.
"""
import json
import subprocess
import unittest
from pathlib import Path

JSC = Path('/System/Library/Frameworks/JavaScriptCore.framework/Versions/Current/Helpers/jsc')
ASSETS = Path(__file__).resolve().parent.parent / 'assets'


@unittest.skipUnless(JSC.is_file(), 'macOS JavaScriptCore CLI unavailable')
class JSTemplateTests(unittest.TestCase):
    def run_template(self, name, setup):
        source = (ASSETS/name).read_text(encoding='utf-8')
        program = '''
var results = [], logs = [], requests = 0;
var console = {log:function(x){logs.push(String(x));}};
var $done = function(value){results.push(value || {});};
''' + setup + '\n' + source + '\nprint(JSON.stringify({results:results,logs:logs,requests:requests}));'
        proc = subprocess.run([str(JSC), '-e', program], text=True, capture_output=True,
                              cwd=str(ASSETS.parent), timeout=10)
        self.assertEqual(0, proc.returncode, proc.stderr + proc.stdout)
        value = json.loads(proc.stdout)
        self.assertEqual(1, len(value['results']), 'Every branch must complete exactly once')
        return value

    def test_response_filter_handles_schemas(self):
        for payload in [None, [], {}, {'data':None}, {'data':[]}, {'data':'opaque'}, 12]:
            with self.subTest(payload=payload):
                data = json.dumps(payload)
                result = self.run_template('script-http-response.js',
                           'var $response={body:'+json.dumps(data)+'};')['results'][0]
                self.assertEqual(payload, json.loads(result['body']))
        obj = {'data':{'ads':[1], 'banners':[2], 'items':[{'isAd':True}, {'id':1}], 'other':'keep'}}
        r = self.run_template('script-http-response.js',
                   'var $response={body:'+json.dumps(json.dumps(obj))+'};')['results'][0]
        self.assertEqual({'data':{'items':[{'id':1}], 'other':'keep'}}, json.loads(r['body']))

    def test_response_filter_failure_and_empty(self):
        for body in ['', '{bad json']:
            with self.subTest(body=body):
                r=self.run_template('script-http-response.js', 'var $response={body:'+json.dumps(body)+'};')
                self.assertEqual({}, r['results'][0])

    def test_response_logging_omits_payload(self):
        secret = 'PRIVATE_TEST_MARKER'
        setup='var $argument="true"; var $response={body:'+json.dumps(json.dumps({'token':secret}))+'};'
        r=self.run_template('script-http-response.js', setup)
        self.assertNotIn(secret, ''.join(r['logs']))
        self.assertTrue(r['logs'])

    def test_panel_success_and_errors(self):
        cases = [
            (None, {'status':200}, '{"ip":"203.0.113.4"}', 'info'),
            ('network error', None, None, 'error'),
            (None, {'status':500}, 'failed', 'error'),
            (None, None, '', 'error'),
            (None, {'status':200}, '{bad', 'error'),
            (None, {'status':200}, '{}', 'error'),
            (None, {'status':200}, 'null', 'error'),
        ]
        for err, resp, data, style in cases:
            with self.subTest(err=err,resp=resp,data=data):
                setup='var $trigger="button"; var $httpClient={get:function(o,cb){requests++;cb('+','.join(json.dumps(x) for x in (err,resp,data))+');}};'
                r=self.run_template('script-panel.js', setup)
                self.assertEqual(1, r['requests'])
                self.assertEqual(style, r['results'][0]['style'])
                self.assertTrue(r['results'][0]['title'])

    def test_panel_without_client(self):
        self.assertEqual('error', self.run_template('script-panel.js', '')['results'][0]['style'])


if __name__ == '__main__':
    unittest.main(verbosity=2)

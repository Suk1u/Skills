#!/usr/bin/env python3
"""Offline regression tests. Run: python3 -I /absolute/path/to/this_file.py

No network; no repository JS/jq evaluation. Temporary modules are synthetic.
"""
import contextlib
import importlib.util
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('surge_module_lint', BASE / 'surge_module_lint.py')
L = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = L
spec.loader.exec_module(L)
PREFIX = '#!name=Test\n#!desc=Synthetic regression case\n'


class LintTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def check(self, content, **kwargs):
        p = self.base / 'module.sgmodule'
        p.write_text(content, encoding='utf-8')
        return L.lint(str(p), **kwargs)

    def codes(self, module, level=None):
        return {i.code for i in module.issues if level is None or i.level == level}

    def test_required_and_invalid_fields(self):
        cases = [
            ('name', '#!desc=Only desc\n[Rule]\nDOMAIN,x.com,REJECT', 'meta-name'),
            ('unclosed-quote', PREFIX+'[Script]\ns=script-path=https://x.com/s.js,argument="missing', 'quotes-unclosed'),
            ('malformed-url', PREFIX+'[URL Rewrite]\n^http://x.com http://[bad header', 'urlrewrite-target'),
            ('proxy', PREFIX+'[Proxy]\nx=http,1.2.3.4,80', 'section-forbidden'),
            ('proxy-group', PREFIX+'[Proxy Group]\ng=select,DIRECT', 'section-forbidden'),
            ('empty-value', PREFIX+'[Rule]\nDOMAIN,,REJECT', 'rule-fields'),
            ('empty-policy', PREFIX+'[Rule]\nDOMAIN,x.com,', 'rule-fields'),
            ('wrong-rule', PREFIX+'[Rule]\nDOMAIN_SUFFIX,x.com,REJECT', 'rule-type'),
            ('user-policy', PREFIX+'[Rule]\nDOMAIN,x.com,MyGroup', 'rule-policy-module'),
            ('reject-drop', PREFIX+'[Rule]\nDOMAIN,x.com,REJECT-DROP', 'rule-policy-undocumented'),
            ('reject-no-drop', PREFIX+'[Rule]\nDOMAIN,x.com,REJECT-NO-DROP', 'rule-policy-undocumented'),
            ('no-script-path', PREFIX+'[Script]\ns=type=generic', 'script-path'),
            ('bad-script-type', PREFIX+'[Script]\ns=type=wrong,script-path=https://x.com/a.js', 'script-type'),
            ('no-pattern', PREFIX+'[Script]\ns=type=http-response,script-path=https://x.com/a.js', 'script-required'),
            ('bad-regex', PREFIX+'[Script]\ns=type=http-response,pattern=[,script-path=https://x.com/a.js', 'regex-review'),
            ('max-size', PREFIX+'[Script]\ns=type=generic,script-path=https://x.com/a.js,max-size=MB', 'script-max-size'),
            ('timeout', PREFIX+'[Script]\ns=type=generic,script-path=https://x.com/a.js,timeout=0', 'script-timeout'),
            ('cron', PREFIX+'[Script]\ns=type=cron,cronexp="0 1",script-path=https://x.com/a.js', 'script-cron'),
            ('boolean', PREFIX+'[Script]\ns=script-path=https://x.com/a.js,requires-body=maybe', 'script-boolean'),
            ('map-type', PREFIX+'[Map Local]\n^http://x.com data-type=json data="{}"', 'maplocal-type'),
            ('map-default', PREFIX+'[Map Local]\n^http://x.com status-code=200', 'maplocal-data'),
            ('map-status', PREFIX+'[Map Local]\n^http://x.com data-type=text data="" status-code=199', 'maplocal-status'),
            ('map-base64', PREFIX+'[Map Local]\n^http://x.com data-type=base64 data="???"', 'maplocal-base64'),
            ('url-type', PREFIX+'[URL Rewrite]\n^http://x.com _ 999', 'urlrewrite-type'),
            ('url-fields', PREFIX+'[URL Rewrite]\n^http://x.com', 'urlrewrite-fields'),
            ('header-action', PREFIX+'[Header Rewrite]\n^http://x.com header-merge A b', 'headerrewrite-action'),
            ('header-arity', PREFIX+'[Header Rewrite]\n^http://x.com header-replace-regex A x', 'headerrewrite-arity'),
            ('header-framing', PREFIX+'[Header Rewrite]\n^http://x.com header-del Content-Length', 'header-framing'),
            ('body-jq-empty', PREFIX+"[Body Rewrite]\nhttp-response-jq ^http://x.com ''", 'bodyrewrite-jq'),
            ('body-pairs', PREFIX+'[Body Rewrite]\nhttp-response ^http://x.com a b c', 'bodyrewrite-pairs'),
            ('mitm-ca', PREFIX+'[MITM]\nca-p12 = secret', 'mitm-ca'),
            ('broad-with-exclusions', PREFIX+'[MITM]\nhostname = %APPEND% -*.apple.com, *', 'mitm-broad'),
            ('duplicate-section', PREFIX+'[Host]\na.com=1.1.1.1\n[Host]\nb.com=1.0.0.1', 'section-duplicate'),
            ('keystore-unverified', PREFIX+'[Keystore]\nk = base64=x', 'section-unverified'),
            ('panel-missing', PREFIX+'[Panel]\np=script-name=missing', 'panel-script-missing'),
            ('panel-type', PREFIX+'[Panel]\np=script-name=s\n[Script]\ns=type=cron,cronexp="0 2 * * *",script-path=https://x.com/s.js', 'panel-script-type'),
        ]
        for label, content, code in cases:
            with self.subTest(label=label):
                self.assertIn(code, self.codes(self.check(content)))

    def test_valid_and_weird_but_supported_cases(self):
        cases = [
            PREFIX+'[Rule]\nDOMAIN,x.com,REJECT',
            PREFIX+'[Rule]\nAND,((DOMAIN,x.com),(DEST-PORT,443)),REJECT',
            PREFIX+'[Map Local]\n^http://x.com data-type=text data="" status-code=204',
            PREFIX+'[Map Local]\n^http://x.com data-type=base64 data="aGVsbG8="',
            PREFIX+'[Map Local]\n^http://x.com data-type=text data="{\\"message\\":\\"hello world\\"}" header="Content-Type:application/json|X-Test:yes"',
            PREFIX+"[Body Rewrite]\nhttp-response-jq ^http://x.com 'del(.ads)'",
            PREFIX+"[Body Rewrite]\nhttp-response ^http://x.com 'old text' 'new text'",
            PREFIX+'[Header Rewrite]\nhttp-request ^http://x.com header-replace User-Agent "hello world"',
            PREFIX+'[Header Rewrite]\nhttp-response ^http://x.com header-replace-regex Date 2022 2023',
            PREFIX+'[URL Rewrite]\n^http://x.com https://y.com 307',
            PREFIX+'[URL Rewrite]\n^http://x.com _ reject',
            PREFIX+'[URL Rewrite]\n^http://x.com https://y.com',
            PREFIX+'[Script]\nhttp-response ^https://x.com/?a=1 script-path=https://x.com/old.js,requires-body=true',
            PREFIX+'[Script]\ncron "0 2 * * *" script-path=https://x.com/old.js',
            PREFIX+'[Script]\nNamed = script-path=https://x.com/a.js # inline comment',
            PREFIX+'[Rule] // section comment\nDOMAIN,x.com,REJECT ; inline comment',
            PREFIX+'[WireGuard A]\nmtu=1280\n[WireGuard B]\nmtu=1280',
            PREFIX+'[Ruleset A]\nDOMAIN,a.com\n[Ruleset B]\nDOMAIN,b.com',
            PREFIX+'[Panel]\np=script-name=s\n[Script]\ns=type=generic,script-path=https://x.com/s.js',
            PREFIX+'[URL Rewrite]\n^http://x.com http://{{{GATEWAY_ADDRESS}}}/ 302',
        ]
        for content in cases:
            with self.subTest(content=content):
                self.assertEqual(set(), self.codes(self.check(content), 'error'))

    def test_profile_directory_is_not_module_directory(self):
        (self.base/'helper.js').write_text('// beside the module only')
        profile = self.base/'profile'; profile.mkdir()
        content = PREFIX+'[Script]\ns=type=generic,script-path=helper.js'
        m = self.check(content)
        self.assertIn('script-local-unchecked', self.codes(m))
        self.assertNotIn('script-local-missing', self.codes(m))
        m = self.check(content, profile_dir=str(profile))
        self.assertIn('script-local-missing', self.codes(m))
        (profile/'helper.js').write_text('// beside the profile')
        self.assertNotIn('script-local-missing', self.codes(self.check(content, profile_dir=str(profile))))

    def test_arguments_defaults_and_unresolved_fields(self):
        content = PREFIX+'#!arguments=p,engine:webview\n[Script]\ns=type=BAD,pattern=^https://x.com,script-path=https://x.com/s.js,argument="{{{p}}}",engine={{{engine}}}'
        m = self.check(content)
        self.assertIn('script-type', self.codes(m))  # not hidden by unrelated placeholder
        self.assertIn('parameter-unchecked', self.codes(m))
        self.assertEqual({'p'}, m.unresolved)
        m = self.check(PREFIX+'#!arguments=t:BAD\n[Script]\ns=type={{{t}}},script-path=https://x.com/s.js')
        self.assertIn('script-type', self.codes(m))
        m = self.check(PREFIX+'#!arguments=p:Group\n[Rule]\nDOMAIN,x.com,{{{p}}}')
        self.assertIn('rule-policy-module', self.codes(m))
        m = self.check(PREFIX+'#!arguments=p:REJECT\n[Rule]\nDOMAIN,x.com,{{{p}}}', arguments={'p':'DIRECT'})
        self.assertEqual(set(), self.codes(m, 'error'))

    def test_placeholder_case_and_reserved_name(self):
        m = self.check(PREFIX+'#!arguments=foo:1\n[General]\ntest-timeout={{{Foo}}}')
        self.assertIn('placeholder-undeclared', self.codes(m))
        m = self.check(PREFIX+'[URL Rewrite]\n^http://x.com http://{{{GATEWAY_ADDRESS}}}/ header')
        self.assertIn('gateway-placeholder', self.codes(m))
        m = self.check(PREFIX+'[MITM]\nhostname = {{{GATEWAY_ADDRESS}}}')
        self.assertIn('placeholder-undeclared', self.codes(m))

    def test_utf8_crlf_and_bom(self):
        p=self.base/'enc.sgmodule'
        p.write_bytes(b'\xef\xbb\xbf'+(PREFIX+'[Rule]\nDOMAIN,x.com,REJECT').replace('\n','\r\n').encode())
        self.assertNotIn('encoding', self.codes(L.lint(str(p))))
        p.write_bytes(b'\xff'+PREFIX.encode())
        self.assertIn('encoding', self.codes(L.lint(str(p))))

    def test_strict_warning_exit_and_cli_json(self):
        content=PREFIX+'[Rule]\nDOMAIN,x.com,REJECT-DROP'
        self.assertIn('rule-policy-undocumented', self.codes(self.check(content, strict=True), 'error'))
        p=self.base/'cli.sgmodule'; p.write_text(content)
        stream=io.StringIO()
        with contextlib.redirect_stdout(stream):
            code=L.main([str(p),'--json','--strict'])
        self.assertEqual(1, code)
        report=json.loads(stream.getvalue())
        self.assertIn('NOT verified', report['verification'])
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(2, L.main([str(self.base/'missing.sgmodule')]))

    def test_all_shipped_templates(self):
        for path in sorted((BASE.parent/'assets').glob('*.sgmodule')):
            with self.subTest(template=path.name):
                self.assertEqual(set(), self.codes(L.lint(str(path), strict=True), 'error'))


if __name__ == '__main__':
    unittest.main(verbosity=2)

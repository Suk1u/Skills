#!/usr/bin/env python3
"""Best-effort static checks for Surge modules (Python 3.9+; no network/JS).

Usage: python3 surge_module_lint.py module.sgmodule [--json] [--strict]
       [--profile-dir DIRECTORY] [--arg NAME=VALUE ...]

This is NOT Surge's parser. Defaults and supplied arguments are expanded for
checks; unresolved fields and environment requirements are reported, not proven
valid. Regex checks use Python, not Surge/ICU; jq and JS are never executed.
Exit: 0 no static errors, 1 static errors (or warnings with --strict), 2 I/O/usage.
Do not put passwords/tokens in --arg: they can appear in shell history/output.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import json
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

SECTION_RE = re.compile(r'^\[([^\]]+)\]\s*$')
META_RE = re.compile(r'^#!\s*([A-Za-z0-9_-]+)\s*=\s*(.*)$')
PLACEHOLDER_RE = re.compile(r'\{\{\{([^{}]+)\}\}\}')
RULE_TYPES = set('DOMAIN DOMAIN-SUFFIX DOMAIN-KEYWORD DOMAIN-WILDCARD DOMAIN-SET '
                 'IP-CIDR IP-CIDR6 GEOIP IP-ASN USER-AGENT URL-REGEX PROCESS-NAME '
                 'DEST-PORT SRC-PORT IN-PORT SRC-IP DEVICE-NAME MAC-ADDRESS PROTOCOL '
                 'HOSTNAME-TYPE SUBNET CELLULAR-RADIO CELLULAR-CARRIER AND OR NOT '
                 'SCRIPT RULE-SET FINAL'.split())
SCRIPT_TYPES = set('http-request http-response cron event dns rule generic'.split())
RULE_POLICIES = {'DIRECT', 'REJECT', 'REJECT-TINYGIF'}
REJECT_VARIANTS = {'REJECT-DROP', 'REJECT-NO-DROP'}
DOCUMENTED_SECTIONS = set('general,mitm,rule,script,url rewrite,header rewrite,host,ip rewrite,mtproto,snell server'.split(','))
CORPUS_SECTIONS = {'body rewrite', 'map local', 'panel'}
FORBIDDEN_SECTIONS = {'proxy', 'proxy group'}
HEADER_ACTIONS = {'header-add': 4, 'header-del': 3, 'header-replace': 4,
                  'header-replace-regex': 5}
MITM_KEYS = {'hostname', 'skip-server-cert-verify'}
CA_KEYS = {'ca-p12', 'ca-passphrase', 'ca-keystore-name'}
META_KEYS = set('name desc system arguments arguments-desc requirement category author '
                'icon homepage version date tag loon_version openurl system_version repo'.split())
SCRIPT_KEYS = set('type script-path script-update-interval timeout argument engine debug '
                  'pattern requires-body max-size binary-body-mode full-header-mode '
                  'cronexp event-name wake-system ability'.split())


@dataclass
class Issue:
    level: str
    line: int
    code: str
    message: str


@dataclass
class Module:
    path: str
    meta: dict = field(default_factory=dict)
    meta_lines: dict = field(default_factory=dict)
    sections: list = field(default_factory=list)
    issues: list = field(default_factory=list)
    unresolved: set = field(default_factory=set)
    defaults: dict = field(default_factory=dict)
    profile_dir: str | None = None

    def add(self, level, line, code, message):
        self.issues.append(Issue(level, line, code, message))


def strip_comment(text):
    """Protect quotes and URLs; inline comments require preceding whitespace."""
    quote = None
    i = 0
    while i < len(text):
        c = text[i]
        if c == '\\':
            i += 2
            continue
        if quote:
            if c == quote:
                quote = None
        elif c in '\"\'':
            quote = c
        elif i > 0 and text[i-1].isspace() and (c in '#;' or text[i:i+2] == '//'):
            return text[:i].rstrip()
        i += 1
    return text


def open_quote(text):
    quote = None
    i = 0
    while i < len(text):
        c = text[i]
        if c == '\\':
            i += 2; continue
        if quote:
            if c == quote:
                quote = None
        elif c in '\"\'':
            quote = c
        i += 1
    return quote


def split_top(text, sep=','):
    """Preserve empty components; protect quoted values/regex groups/classes."""
    out, start, quote, stack = [], 0, None, []
    i = 0
    while i < len(text):
        c = text[i]
        if c == '\\':
            i += 2
            continue
        if quote:
            if c == quote:
                quote = None
        elif c in '\"\'':
            quote = c
        elif c in '([{':
            stack.append(c)
        elif c in ')]}' and stack:
            expected = {')': '(', ']': '[', '}': '{'}[c]
            if stack[-1] == expected:
                stack.pop()
        elif c == sep and not stack:
            out.append(text[start:i].strip())
            start = i + 1
        i += 1
    out.append(text[start:].strip())
    return out


def split_fields(text):
    out, buf, quote = [], [], None
    i = 0
    while i < len(text):
        c = text[i]
        if c == '\\' and i+1 < len(text):
            buf.extend(text[i:i+2]); i += 2; continue
        if quote:
            buf.append(c)
            if c == quote:
                quote = None
        elif c in '\"\'':
            buf.append(c); quote = c
        elif c.isspace():
            if buf:
                out.append(''.join(buf)); buf = []
        else:
            buf.append(c)
        i += 1
    if buf:
        out.append(''.join(buf))
    return out


def unquote(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in '\"\'':
        q, value = value[0], value[1:-1]
        if q == '"':
            # Decode only documented escapes; do not turn regex \b into backspace.
            value = re.sub(r'\\([\\"])', lambda m: m.group(1), value)
    return value


def parse_kv(parts):
    kv, leftovers = {}, []
    for part in parts:
        if '=' in part:
            k, v = part.split('=', 1)
            kv[k.strip().lower()] = unquote(v)
        else:
            leftovers.append(part)
    return kv, leftovers


def unresolved(value):
    return bool(PLACEHOLDER_RE.search(value))


def regex_check(mod, line, pattern):
    """Advisory only: Python regex syntax is not Surge/ICU syntax."""
    if unresolved(pattern):
        return
    try:
        re.compile(unquote(pattern))
    except re.error as e:
        mod.add('warning', line, 'regex-review',
                f'Python regex check reports {e}; verify with Surge/ICU (not equivalent engines).')


def parse_module(path):
    mod = Module(str(path))
    raw = Path(path).read_bytes()
    if raw.startswith(b'\xef\xbb\xbf'):
        mod.add('info', 1, 'bom', 'UTF-8 BOM detected.'); raw = raw[3:]
    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError:
        mod.add('error', 1, 'encoding', 'Invalid UTF-8; repair encoding before loading.')
        text = raw.decode('utf-8', 'replace')
    current = None
    for n, raw_line in enumerate(text.splitlines(), 1):
        line = raw_line.strip()
        if not line:
            continue
        if current is None:
            meta = META_RE.match(line)
            if meta:
                k, v = meta.group(1).lower(), meta.group(2)
                if k in mod.meta:
                    mod.add('warning', n, 'meta-duplicate', f'Duplicate metadata #{k}.')
                mod.meta[k] = v.strip(); mod.meta_lines[k] = n
                continue
        if '#!REQUIREMENT' in line or '//!REQUIREMENT' in line or re.search(r'#!(?:IOS|MACOS|TVOS)-ONLY', line):
            mod.add('info', n, 'condition-unchecked', 'Environment-dependent line: validate in the target Surge environment.')
            # Do not evaluate NSPredicate expressions using Python/eval.
            if line.startswith('#!'):
                continue
        if line.startswith(('#', ';', '//')):
            continue
        line = strip_comment(line)
        sec = SECTION_RE.match(line)
        if sec:
            current = (sec.group(1), n, []); mod.sections.append(current)
        elif current is None:
            mod.add('error', n, 'stray-line', 'Non-metadata content before the first section.')
        else:
            if open_quote(line):
                mod.add('warning', n, 'quotes-unclosed', 'Possibly unclosed quote; verify quoting in Surge (regex literals may need separate review).')
            current[2].append((n, line))
    return mod


def check_meta_and_expand(mod, supplied):
    # Metadata is recommended, not claimed mandatory by the official module page.
    if not unquote(mod.meta.get('name', '')).strip():
        mod.add('warning', 1, 'meta-name', 'Missing display name; recommended by this skill, not proof of a Surge parse error.')
    if not mod.meta.get('desc'):
        mod.add('warning', 1, 'meta-desc', 'Missing description.')
    for k in mod.meta:
        if k not in META_KEYS:
            mod.add('info', mod.meta_lines[k], 'meta-unverified', f'Metadata {k!r} is not verified by this checker; no runtime claim.')
    declared = set()
    for part in split_top(mod.meta.get('arguments', '')):
        if not part:
            continue
        name, colon, default = part.partition(':')
        name = name.strip()
        if name in declared:
            mod.add('warning', mod.meta_lines['arguments'], 'argument-duplicate', f'Duplicate argument {name!r}.')
        declared.add(name)
        if not re.fullmatch(r'[A-Za-z0-9_]+', name):
            mod.add('warning', mod.meta_lines['arguments'], 'arg-name', f'{name!r}: use ASCII letters/digits/underscore for documented portability.')
        if colon:
            mod.defaults[name] = unquote(default)
    for k in supplied:
        if k not in declared:
            mod.add('error', 1, 'argument-unknown', f'Supplied argument {k!r} is not declared.')
    values = {**mod.defaults, **supplied}
    used = set()
    new_sections = []
    for sec, n, lines in mod.sections:
        out = []
        for num, line in lines:
            def replace(m):
                name = m.group(1)  # do not trim: substitution is case-sensitive/exact
                if name == 'GATEWAY_ADDRESS' and sec.lower() == 'url rewrite':
                    # Built-in only in 302/307 replacement; validate position later.
                    return m.group(0)
                used.add(name)
                if name not in declared:
                    mod.add('error', num, 'placeholder-undeclared', f'Undeclared placeholder: {m.group(0)}')
                if name not in values:
                    mod.unresolved.add(name)
                    mod.add('info', num, 'parameter-unchecked', f'No value for {name!r}; dependent fields remain unchecked.')
                    return m.group(0)
                return values[name]
            expanded = PLACEHOLDER_RE.sub(replace, line)
            if '\n' in expanded or '\r' in expanded:
                mod.add('error', num, 'argument-newline', 'Argument inserts a newline; single-line checking cannot safely validate this.')
                continue
            expanded = expanded.strip()
            if expanded.startswith(('#', ';', '//')):
                continue
            out.append((num, strip_comment(expanded)))
        new_sections.append((sec, n, out))
    mod.sections = new_sections
    for name in declared - used:
        mod.add('warning', mod.meta_lines.get('arguments', 1), 'argument-unused', f'Argument {name!r} is declared but unused.')


def check_sections(mod):
    seen = set()
    for sec, n, _ in mod.sections:
        key = sec.lower().strip()
        if key in seen:
            mod.add('warning', n, 'section-duplicate', f'Duplicate section [{sec}].')
        seen.add(key)  # named sections are compared by FULL name, not by family
        if key in FORBIDDEN_SECTIONS:
            mod.add('error', n, 'section-forbidden', f'Official module docs prohibit [{sec}].')
        elif key not in DOCUMENTED_SECTIONS | CORPUS_SECTIONS and not key.startswith(('wireguard ', 'ruleset ')):
            mod.add('warning', n, 'section-unverified', f'[{sec}] is outside the documented module override list; do not assume profile support implies module support.')


def check_rules(mod, n, line):
    parts = split_top(line)
    typ = parts[0].upper()
    if unresolved(typ):
        return
    if typ not in RULE_TYPES:
        mod.add('error', n, 'rule-type', f'Unknown rule type {typ!r}.')
    required = 2 if typ == 'FINAL' else 3
    if len(parts) < required or any(not p for p in parts[:required]):
        mod.add('error', n, 'rule-fields', 'Rule has missing/empty TYPE, VALUE or POLICY fields.'); return
    policy = unquote(parts[1 if typ == 'FINAL' else 2])
    if not unresolved(policy):
        if policy.upper() in REJECT_VARIANTS:
            mod.add('warning', n, 'rule-policy-undocumented', 'REJECT variant is observed in modules but not listed by the official module page; verify on target Surge.')
        elif policy.upper() not in RULE_POLICIES:
            mod.add('error', n, 'rule-policy-module', 'Module rules are documented for DIRECT/REJECT/REJECT-TINYGIF, not user policies/groups.')
    if typ == 'FINAL':
        mod.add('warning', n, 'module-final', 'Avoid FINAL in modules: prepended catch-all can shadow main-profile rules.')
    if typ == 'URL-REGEX':
        regex_check(mod, n, parts[1])


def script_declaration(line):
    # Legacy syntax can contain '=' inside pattern; recognize type first.
    first = line.split(None, 1)[0] if line.split() else ''
    if first in SCRIPT_TYPES and '=' not in first:
        legacy = re.match(r'^(\S+)\s+(.+?)\s+(?=[A-Za-z][\w-]*\s*=)(.*)$', line)
        if not legacy:
            return '', {}, ['incomplete legacy declaration']
        typ, value, params = legacy.groups()
        kv, flags = parse_kv(split_top(params))
        kv['type'] = typ
        value_key = {'http-request': 'pattern', 'http-response': 'pattern', 'cron': 'cronexp', 'event': 'event-name'}.get(typ)
        if value_key:
            kv[value_key] = unquote(value)
            name = Path(kv.get('script-path', '')).name
        else:
            name = value
        return name, kv, flags
    if '=' not in line:
        return '', {}, [line]
    name, params = line.split('=', 1)
    kv, flags = parse_kv(split_top(params))
    return name.strip(), kv, flags


def check_script(mod, n, line):
    name, kv, flags = script_declaration(line)
    if not name:
        mod.add('error', n, 'script-name', 'Missing script name/declaration.')
    typ = kv.get('type', 'generic')
    if not unresolved(typ) and typ not in SCRIPT_TYPES:
        mod.add('error', n, 'script-type', f'Unknown script type {typ!r}.')
    for key in kv.keys() - SCRIPT_KEYS:
        mod.add('info', n, 'script-key-unverified', f'Unverified script parameter {key!r}.')
    if flags:
        mod.add('warning', n, 'script-tokens', 'Unparsed script parameters; check commas/quotes.')
    path = kv.get('script-path', '')
    if not path:
        mod.add('error', n, 'script-path', 'Missing script-path.')
    elif not unresolved(path) and not path.startswith(('https://', 'http://')):
        p = Path(path)
        if not p.is_absolute() and mod.profile_dir is None:
            mod.add('info', n, 'script-local-unchecked', 'Relative script-path needs --profile-dir; it is NOT relative to the module directory.')
        else:
            candidate = p if p.is_absolute() else Path(mod.profile_dir) / p
            if not candidate.is_file():
                mod.add('warning', n, 'script-local-missing', 'Local script does not exist relative to the supplied profile directory.')
    key = {'http-request': 'pattern', 'http-response': 'pattern', 'cron': 'cronexp', 'event': 'event-name'}.get(typ)
    if key and not kv.get(key):
        mod.add('error', n, 'script-required', f'{typ} requires {key}=.')
    if 'pattern' in kv:
        regex_check(mod, n, kv['pattern'])
    for key in ('timeout', 'max-size'):
        v = kv.get(key)
        if v is not None and not unresolved(v):
            valid = bool(re.fullmatch(r'-?\d+' if key == 'max-size' else r'\d+(?:\.\d+)?', v))
            if not valid or (key == 'timeout' and float(v) <= 0) or (key == 'max-size' and int(v) < -1):
                mod.add('error', n, 'script-' + key, f'Invalid numeric {key}.')
    v = kv.get('engine')
    if v is not None and not unresolved(v) and v not in {'auto', 'jsc', 'webview'}:
        mod.add('error', n, 'script-engine', 'engine must be auto/jsc/webview.')
    if typ == 'event' and kv.get('event-name') and not unresolved(kv['event-name']) and kv['event-name'] not in {'network-changed', 'notification', 'engine-started', 'profile-reloaded'}:
        mod.add('warning', n, 'script-event', 'Unknown documented event; verify target version.')
    if typ == 'cron' and kv.get('cronexp') and not unresolved(kv['cronexp']):
        if len(kv['cronexp'].split()) not in (5, 6):
            mod.add('error', n, 'script-cron', 'cronexp must have 5 or 6 fields.')
    for key in ('requires-body', 'binary-body-mode', 'full-header-mode', 'debug', 'wake-system'):
        if key in kv and not unresolved(kv[key]) and kv[key].lower() not in {'true', 'false', '1', '0'}:
            mod.add('error', n, 'script-boolean', f'Invalid boolean for {key}.')
    return name, typ


def check_mitm(mod, n, line):
    if '=' not in line:
        mod.add('error', n, 'mitm-form', 'Expected key = value.'); return
    key, value = line.split('=', 1); key, value = key.strip().lower(), value.strip()
    if key in CA_KEYS:
        mod.add('error', n, 'mitm-ca', 'A module cannot replace the MITM CA certificate.')
    elif key not in MITM_KEYS and not unresolved(key):
        mod.add('warning', n, 'mitm-key', 'Key outside documented module MITM overrides (hostname, skip-server-cert-verify).')
    if key != 'hostname' or unresolved(value):
        return
    value = re.sub(r'^%(?:APPEND|INSERT)%\s*', '', value)
    hosts = split_top(value)
    if '*' in hosts:
        mod.add('warning', n, 'mitm-broad', 'Bare * decrypts a broad scope even with exclusions; avoid as a default.')
    if not value:
        mod.add('info', n, 'mitm-empty', 'Empty hostname list; may intentionally clear scope.')
    for host in hosts:
        if host and '/' in host:
            mod.add('warning', n, 'mitm-regex', 'MITM hostname uses Host List syntax, not URL/regex syntax.')


def check_http(mod, sec, n, line):
    fields = split_fields(line)
    if not fields:
        return
    if sec == 'url rewrite':
        if len(fields) not in (2, 3):
            mod.add('error', n, 'urlrewrite-fields', 'Expected pattern replacement [header|302|307|reject].'); return
        typ = fields[2] if len(fields) == 3 else 'header'
        if not unresolved(typ) and typ not in {'header', '302', '307', 'reject'}:
            mod.add('error', n, 'urlrewrite-type', 'Unknown URL Rewrite type.')
        if not unresolved(fields[1]) and typ == 'header':
            try:
                scheme = urlsplit(unquote(fields[1])).scheme
            except ValueError:
                scheme = ''
            if scheme not in {'http', 'https', 'ws'}:
                mod.add('warning', n, 'urlrewrite-target', 'Header-mode target must be an http/https/ws URL.')
        if any('{{{GATEWAY_ADDRESS}}}' in f for f in fields):
            if typ not in {'302', '307'} or '{{{GATEWAY_ADDRESS}}}' not in fields[1] or '{{{GATEWAY_ADDRESS}}}' in fields[0]:
                mod.add('error', n, 'gateway-placeholder', 'GATEWAY_ADDRESS is documented only in 302/307 replacement values.')
        regex_check(mod, n, fields[0])
    elif sec == 'header rewrite':
        if fields[0] in {'http-request', 'http-response'}:
            fields = fields[1:]
        if len(fields) < 2:
            mod.add('error', n, 'headerrewrite-fields', 'Missing pattern/action.'); return
        action = fields[1]
        if not unresolved(action):
            if action not in HEADER_ACTIONS:
                mod.add('error', n, 'headerrewrite-action', 'Unknown header action.')
            elif len(fields) != HEADER_ACTIONS[action]:
                mod.add('error', n, 'headerrewrite-arity', f'{action} needs {HEADER_ACTIONS[action]} fields including pattern/action.')
        regex_check(mod, n, fields[0])
        if len(fields) >= 3 and unquote(fields[2]).lower() in {'content-length', 'transfer-encoding'}:
            mod.add('error', n, 'header-framing', 'Header Rewrite cannot change message framing headers.')
    elif sec == 'map local':
        kv, flags = parse_kv(fields[1:]); typ = kv.get('data-type', 'file')
        if not unresolved(typ) and typ not in {'file', 'text', 'tiny-gif', 'base64'}:
            mod.add('error', n, 'maplocal-type', 'Unknown data-type.')
        if typ in {'file', 'text', 'base64'} and 'data' not in kv:
            mod.add('error', n, 'maplocal-data', 'Missing data= (data-type defaults to file).')
        if flags:
            mod.add('warning', n, 'maplocal-tokens', 'Unparsed Map Local tokens; check quoting.')
        status = kv.get('status-code')
        if status is not None and not unresolved(status) and (not status.isdigit() or not 200 <= int(status) <= 999):
            mod.add('error', n, 'maplocal-status', 'status-code must be 200..999.')
        if typ == 'base64' and 'data' in kv and not unresolved(kv['data']):
            try:
                base64.b64decode(kv['data'], validate=True)
            except (ValueError, binascii.Error):
                mod.add('error', n, 'maplocal-base64', 'Invalid base64 data.')
        regex_check(mod, n, fields[0])
    elif sec == 'body rewrite':
        typ = fields[0]
        if unresolved(typ):
            return
        if typ in {'http-request-jq', 'http-response-jq'}:
            if len(fields) != 3 or not unquote(fields[-1]).strip():
                mod.add('error', n, 'bodyrewrite-jq', 'Expected direction URL-pattern nonempty quoted jq expression.')
        elif typ not in {'http-request', 'http-response'}:
            mod.add('error', n, 'bodyrewrite-direction', 'Unknown Body Rewrite direction.')
        elif len(fields) < 4 or (len(fields)-2) % 2:
            mod.add('error', n, 'bodyrewrite-pairs', 'Expected direction URL-pattern regex/replacement pairs.')
        if len(fields) > 1:
            regex_check(mod, n, fields[1])


def lint(path, strict=False, profile_dir=None, arguments=None):
    mod = parse_module(path); mod.profile_dir = profile_dir
    check_meta_and_expand(mod, arguments or {}); check_sections(mod)
    scripts, panels = {}, []
    for name, _, lines in mod.sections:
        sec = name.lower().strip()
        for n, line in lines:
            if sec == 'rule':
                check_rules(mod, n, line)
            elif sec == 'script':
                script_name, typ = check_script(mod, n, line)
                scripts.setdefault(script_name, set()).add(typ)
            elif sec == 'mitm':
                check_mitm(mod, n, line)
            elif sec in {'url rewrite', 'header rewrite', 'body rewrite', 'map local'}:
                check_http(mod, sec, n, line)
            elif sec == 'panel':
                if '=' not in line:
                    mod.add('error', n, 'panel-form', 'Expected name = panel parameters.'); continue
                _, params = line.split('=', 1); kv, flags = parse_kv(split_top(params))
                if flags:
                    mod.add('warning', n, 'panel-tokens', 'Unparsed panel parameters.')
                if 'style' in kv and not unresolved(kv['style']) and kv['style'] not in {'good', 'info', 'alert', 'error'}:
                    mod.add('error', n, 'panel-style', 'Unknown panel style.')
                if 'script-name' in kv:
                    panels.append((n, kv['script-name']))
                elif not kv.get('title'):
                    mod.add('warning', n, 'panel-title', 'Static panel has no title.')
    for n, name in panels:
        if unresolved(name):
            continue
        if not name:
            mod.add('error', n, 'panel-script', 'Empty script-name.')
        elif name not in scripts:
            mod.add('warning', n, 'panel-script-missing', 'Referenced script is not in this module; it may be supplied by the profile.')
        elif 'generic' not in scripts[name] and not any(unresolved(t) for t in scripts[name]):
            mod.add('warning', n, 'panel-script-type', 'Panels use generic scripts, not HTTP/cron scripts.')
    if strict:
        for issue in mod.issues:
            if issue.level == 'warning':
                issue.level = 'error'
    return mod


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('path'); parser.add_argument('--json', action='store_true')
    parser.add_argument('--strict', action='store_true')
    parser.add_argument('--profile-dir'); parser.add_argument('--arg', action='append', default=[])
    args = parser.parse_args(argv)
    values = {}
    for value in args.arg:
        k, sep, v = value.partition('=')
        if not sep or not k:
            parser.error('--arg requires NAME=VALUE')
        values[k] = v
    try:
        mod = lint(args.path, args.strict, args.profile_dir, values)
    except (OSError, ValueError) as e:
        print(f'Cannot check module: {e}', file=sys.stderr); return 2
    payload = {'file': str(Path(mod.path).absolute()), 'name': mod.meta.get('name', ''),
               'errors': sum(i.level == 'error' for i in mod.issues),
               'warnings': sum(i.level == 'warning' for i in mod.issues),
               'unresolved_arguments': sorted(mod.unresolved),
               'verification': 'best-effort static only; Surge load, regex engine, jq, JavaScript and traffic behavior NOT verified',
               'issues': [i.__dict__ for i in mod.issues]}
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"{mod.path}: {payload['errors']} static error(s), {payload['warnings']} warning(s)")
        for i in mod.issues:
            print(f'{mod.path}:{i.line}: {i.level}: [{i.code}] {i.message}')
        print(payload['verification'])
    return 1 if payload['errors'] else 0


if __name__ == '__main__':
    sys.exit(main())

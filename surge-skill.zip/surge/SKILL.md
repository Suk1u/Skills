---
name: surge
description: Surge（iOS/macOS/tvOS）配置与模块专家。编写、审查、调试 .sgmodule 模块、Profile、规则、策略组、代理协议、DNS、MITM、URL/Header/Body 重写、Map Local、JavaScript 脚本、Panel、HTTP API 与 surge-cli。Use when the user asks about Surge modules, profiles, rules, policy groups, proxies, MITM, rewrite rules, Surge scripts, panels, or Surge troubleshooting.
---

# Surge 专家

用于 Surge（nssurge）相关的配置编写、模块制作、代码审查和故障排查。目标是产出**能被 Surge 真正加载并生效**的配置，而不是看起来像的配置。

## 先确认三件事

1. **平台**：iOS / macOS / tvOS？很多键和功能是平台独占的。
2. **Surge 版本**：新特性有明确版本门槛（如 Smart iOS 5.11+/Mac 5.7+，Body Rewrite iOS 5.10+/Mac 5.6+，`#!requirement` iOS 5.10+/Mac 5.6+）。不确定就让用户看"设置 → 关于"。
3. **目标**：写新模块 / 改现有配置 / 解释行为 / 排障。不同目标读不同参考。

## 核心心智模型

```
主 Profile（.conf）
  + 分离段（#!include .dconf）
  + 启用的模块（.sgmodule，优先级高于主配置）
  = 实际生效配置（surge-cli profile diff 可查看）
```

流量路径（HTTP 相关）：

```
原始 TCP/UDP → 接管、识别协议、规则与出站策略
HTTP 消息 → Header Rewrite → URL Rewrite → Body Rewrite → HTTP Script
            Map Local 命中可直接返回本地响应（不请求上游）
HTTPS 消息 → 先经 MITM 解密，才能进入上述 HTTP 消息处理

这是概念图，不是所有处理阶段的严格时序。
http-request 脚本在该请求的规则匹配和上游发送之前运行；
URL Rewrite 的 header 模式只有第一条匹配规则生效。
```

关键事实：

- **模块不能定义 `[Proxy]` / `[Proxy Group]`**，模块规则只能用内置策略（`DIRECT`、`REJECT`、`REJECT-TINYGIF`）。
- **处理 HTTPS 消息 URL、头部或 body 的重写与 http-request/http-response 脚本需要 MITM**。rule/dns/event/cron/generic 脚本不以 MITM 为前提。
- **每个方向最多一个 HTTP 脚本**（第一条命中的 request 脚本 + 第一条命中的 response 脚本）。
- 模块的 Rule/Script/URL Rewrite 等行式内容插入到对应段顶部；General/MITM 键值与内联规则集采用不同的合并方式，不能笼统说所有行都前插。
- `requires-body` 会缓冲整个 body，是 iOS 内存问题的主要来源。

## 技术选型（先选最简单的）

| 需求 | 首选 |
|---|---|
| 屏蔽域名 | `[Rule]` + `REJECT`（不需要 MITM） |
| 屏蔽 URL | `[URL Rewrite] ... _ reject` 或 `URL-REGEX` 规则 |
| 返回空/固定 JSON | `[Map Local] data-type=text` |
| 删除 JSON 字段 | `[Body Rewrite] http-response-jq` |
| 改请求/响应头 | `[Header Rewrite]` |
| 动态逻辑、Cookie、加密、protobuf | `[Script]` |
| 定时任务 | `type=cron` |
| 展示信息 | `[Panel]` + `type=generic` |

原则：能 Rule 就不 MITM；能 Map Local 就不脚本；能 jq 就不正则。

## 工作流 A：写一个模块

1. **明确行为**：目标 App/域名、要改的请求或响应、失败时的表现。
2. **选技术**：优先静态规则；仅动态逻辑超出静态功能时用脚本，只有需要读取/修改 body 时才打开 requires-body。
3. **搭骨架**：
   ```ini
   #!name=...
   #!desc=...
   #!system=ios
   #!category=...
   #!author=...
   #!homepage=...
   #!date=2026-11-05
   #!arguments=...
   #!arguments-desc=...

   [Rule]
   ...
   [Map Local]
   ...
   [Script]
   ...
   [MITM]
   hostname = %APPEND% ...
   ```
4. 上面的骨架只是段名索引，**只保留需要的段**；纯 Rule、cron 或 Panel 模块不要自动添加 MITM。
5. **MITM 精确到实际域名**，不要 `*`。
6. **参数用 `{{{name}}}`**，并在 `#!arguments` 声明；参数名用 ASCII。
7. **跑 lint**：
   ```bash
   python3 ~/.claude/skills/surge/scripts/surge_module_lint.py path/to/module.sgmodule
   ```
8. **验证**：装模块 → 看请求 Notes / 脚本日志 → 关模块再测一次。
9. 交付时说明：依赖 MITM？依赖版本？参数怎么填？怎么卸载/关闭？

模板：`assets/module-minimal.sgmodule`、`module-rewrite.sgmodule`、`module-script.sgmodule`、`module-panel.sgmodule`，以及脚本模板 `assets/script-http-response.js`、`assets/script-panel.js`。

## 工作流 B：改配置 / 写规则

1. 先判断是 Profile、分离段还是模块；**模块不能改的东西**不要硬塞。
2. 规则顺序：具体 → 宽泛，域名 → IP，`FINAL` 最后。
3. 需要 DNS 的 IP 规则放后面；不能本地解析的域名直接 `DOMAIN` 走代理；`FINAL` 可加 `dns-failed`。
4. 大量域名用 `DOMAIN-SET`；混合类型用 `RULE-SET`。
5. 用 `surge-cli rule match/explain` 验证，不要靠猜。

## 工作流 C：排障

1. 请求查看器里有没有这条请求？没有 = 接管问题；有 = 转发/处理问题。
2. 看请求详情 → Notes 的错误。
3. HTTPS 重写不生效：先查 MITM 开关、hostname 覆盖、CA 信任。
4. 规则不生效：查是否被更早规则截胡、模块规则位置、`FINAL` 位置、QUIC。
5. 脚本不生效：`pattern`、`script-path`、`requires-body`、`$done()`、脚本日志。
6. 模块不生效：启用状态 → `surge-cli profile diff` → 冲突/参数。
7. 需要更细：`dns trace`、`rule explain`、`log watch`、`dump performance`。

详见 `references/troubleshooting.md`。surge-cli 程序只在 Mac 上提供；iOS/tvOS 可用本机请求详情、脚本编辑器与远程控制器，或从 Mac 用 `--remote` 连接。具体 CLI 参数先看目标版本的 help，本 skill 未在 Surge 真机运行这些命令。

## 证据与验证等级

- 先按目标版本的 App 内 Profile Syntax / 官方专题页核对；仓库样例只是实践证据，不是解析器规范。
- 文档没有承诺的行为（参数名扩展、特殊更新间隔、模块附加段）明确标注，不凭仓库里出现过就宣称可用。
- linter 是辅助检查器，不是 Surge 解析器；通过它不等于配置加载成功，更不等于功能成功。
- 需要更完整的参数表或来源追溯时读 `references/sources.md`。

## 速查

### 模块元数据

模块手册列出 name/desc/system/arguments/arguments-desc/requirement；category 在更新日志中有分类功能证据。author/homepage/icon/date/version 及 Loon 生态的额外元数据在仓库常见，但不要把未文档化的展示效果、loon_version 等当成 Surge 兼容性保证。

### 模块可改的段

官方可覆盖：`General`、`MITM`（仅 hostname/skip-server-cert-verify）、`WireGuard *`、`MTProto`、`Snell Server`、`Ruleset *`、`Rule`、`Script`、`URL Rewrite`、`Header Rewrite`、`Host`、`IP Rewrite`。

实践中模块还常用 `Body Rewrite`、`Map Local`、`Panel`（官方列表未列；真实模块大量使用，但发布前应在目标版本实测）。

### 合并操作符

- `key = value`：覆盖
- `key = %APPEND% value`：追加
- `key = %INSERT% value`：前插
- `%REPLACE%` 未文档化，不要写。

### 规则类型

域名：`DOMAIN`、`DOMAIN-SUFFIX`、`DOMAIN-KEYWORD`、`DOMAIN-WILDCARD`、`DOMAIN-SET`
IP：`IP-CIDR`、`IP-CIDR6`、`GEOIP`、`IP-ASN`
HTTP：`USER-AGENT`、`URL-REGEX`
来源/端口：`SRC-IP`、`SRC-PORT`、`DEST-PORT`、`IN-PORT`、`DEVICE-NAME`、`MAC-ADDRESS`、`PROCESS-NAME`
网络：`PROTOCOL`、`HOSTNAME-TYPE`、`SUBNET`、`CELLULAR-RADIO`、`CELLULAR-CARRIER`
逻辑：`AND`、`OR`、`NOT`
其他：`SCRIPT`、`RULE-SET`、`FINAL`

参数：`no-resolve`、`extended-matching`、`pre-matching`、`dns-failed`、`requires-resolve`、`notification-text=`、`update-interval=`。

### 脚本参数

`type`、`script-path`、`script-update-interval`、`timeout`、`argument`、`engine`、`debug`、`pattern`、`requires-body`、`max-size`、`binary-body-mode`、`full-header-mode`、`cronexp`、`event-name`、`wake-system`。

### 脚本类型

`http-request`、`http-response`、`rule`、`dns`、`event`、`cron`、`generic`。

## 质量红线

- 不发明语法；不确定就查 `references/` 或让用户确认版本。
- 不在模块里写 `[Proxy]` / `[Proxy Group]`；不引用用户策略组作为模块规则策略。
- 不把 `example.com` 留在成品里。
- 不默认 `hostname = *`；MITM 范围要能解释。
- 不默认 `requires-body=true` / `max-size=-1`；先证明需要读 body。
- 不写没有 `$done()` 的脚本；异常路径要兜底。
- HTTP 脚本先确认流量已进入 HTTP 引擎；HTTPS 需对应 MITM，不要求每个 HTTP 脚本都新增分流规则。
- `max-size=0` 语义未文档化；用 `-1` 或明确字节数。
- 远程脚本要可信、尽量固定版本；不要在模块里放明文密码/Token。
- 交付前跑 lint，并说明"未在真机验证"的部分。

## 参考文件

| 文件 | 内容 |
|---|---|
| `references/modules.md` | 模块格式、元数据、参数、限制、Loon 迁移、发布检查清单 |
| `references/profile.md` | Profile 格式、分离/托管配置、[General]、DNS、Host、Keystore、平台差异 |
| `references/rules.md` | 全部规则类型、参数、DNS 交互、RULE-SET/DOMAIN-SET、FINAL、REJECT |
| `references/policies.md` | 全部代理协议、TLS、UDP、内置策略、策略组与测速 |
| `references/http-rewrite.md` | MITM、URL/Header/Body 重写、Map Local、处理流水线 |
| `references/scripting.md` | 脚本类型、全部 JS API、`$done` 契约、配方、限制 |
| `references/patterns.md` | 去广告/解锁/签到/面板/DNS 的真实模式与反模式 |
| `references/tools.md` | Panel、HTTP API、surge-cli、URL Scheme、Logbook、MCP |
| `references/features.md` | 网关、Ponte、Snell 服务端、DHCP、IP Rewrite、MTProto、端口转发、增强模式 |
| `references/troubleshooting.md` | 接管/转发/DNS/MITM/模块/网关的排障流程 |
| `references/operations.md` | 服务商订阅、tvOS、功能资格、远程控制、NAT/STUN 与 L3 安全 |
| `references/sources.md` | 固定 commit、原始手册快照、统计口径与验证边界 |

## 工具

```bash
# 结构检查（不联网、不执行 JS）
python3 ~/.claude/skills/surge/scripts/surge_module_lint.py module.sgmodule --strict

# 查看模块合并后的有效配置
surge-cli profile diff

# 解释某请求为什么走这条策略
surge-cli help rule explain

# DNS 全链路
surge-cli dns trace example.com
```

Surge 自身还带了一个 agent skill（`/Applications/Surge.app/Contents/Resources/Skills/`），侧重 `surge-cli` 控制；本 skill 侧重配置/模块编写与知识体系，两者可配合。

## 版本说明

本 skill 基于 2026-11 的官方手册与知识库，以及两个真实模块仓库（Rabbit-Spec/Surge、QingRex/LoonKissSurge）的 543 个模块分析。Surge 更新频繁；遇到未标注版本的新键，先在目标版本上验证再写进交付物。
#!/usr/bin/env python3
"""Static linter for Surge .sgmodule modules.

Checks structure, metadata, section usage, script declarations, module
restrictions, argument placeholders, MITM host lists and rewrite syntax.
It does NOT execute JavaScript or contact the network.

Usage:
    python3 surge_module_lint.py path/to/module.sgmodule [--json] [--strict]

Exit status: 0 = no errors (warnings allowed), 1 = errors, 2 = usage error.
"""
from __future__ import annotations

import json
import os
import re
import sys
from dataclasses import dataclass, field

SECTION_RE = re.compile(r"^\[([^\]]+)\]\s*$")
META_RE = re.compile(r"^#!\s*([A-Za-z0-9_-]+)\s*=\s*(.*)$")
PLACEHOLDER_RE = re.compile(r"\{\{\{([^{}]+)\}\}\}")

KNOWN_META = {
    "name", "desc", "system", "author", "homepage", "icon", "category",
    "date", "tag", "arguments", "arguments-desc", "requirement", "version",
    "openurl", "open-url", "run", "disable-script-hook", "raw-url",
    "loon_version", "system_version", "repo", "manual", "howto", "auther",
}
KNOWN_SECTIONS = {
    "general", "proxy", "proxy group", "rule", "host", "url rewrite",
    "header rewrite", "body rewrite", "map local", "mitm", "keystore",
    "ssid setting", "script", "panel", "ponte", "port forwarding",
    "ip rewrite", "testing", "dhcp", "snell server", "mtproto",
}
MODULE_FORBIDDEN_SECTIONS = {"proxy", "proxy group", "keystore"}
# The manual says module rules may use internal policies DIRECT/REJECT/REJECT-TINYGIF.
# Real modules also use the other REJECT variants, so they are only a warning.
MODULE_ALLOWED_RULE_POLICIES = {
    "DIRECT", "REJECT", "REJECT-TINYGIF", "REJECT-DROP", "REJECT-NO-DROP",
}
RULE_PARAMS = {
    "no-resolve", "extended-matching", "pre-matching", "dns-failed",
    "requires-resolve", "force-remote-dns",
}
SCRIPT_TYPES = {
    "http-request", "http-response", "cron", "event", "dns", "rule",
    "generic",
}
REWRITE_TYPES = {"header", "302", "307", "reject"}
MAP_LOCAL_TYPES = {"file", "text", "tiny-gif", "base64"}
HEADER_ACTIONS = {
    "header-add", "header-del", "header-replace", "header-replace-regex",
}
MITM_MODULE_KEYS = {"hostname", "skip-server-cert-verify"}


@dataclass
class Issue:
    level: str  # error | warning | info
    line: int
    code: str
    message: str


@dataclass
class Module:
    path: str
    meta: dict[str, str] = field(default_factory=dict)
    sections: list[tuple[str, int, list[tuple[int, str]]]] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)


def split_top(text: str, sep: str = ",") -> list[str]:
    """Split on sep outside quotes, parentheses, brackets and braces."""
    out, buf = [], []
    quote = None
    depth = 0
    i = 0
    while i < len(text):
        ch = text[i]
        if quote:
            buf.append(ch)
            if ch == "\\" and i + 1 < len(text):
                buf.append(text[i + 1])
                i += 2
                continue
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
            buf.append(ch)
        elif ch in "([{":
            depth += 1
            buf.append(ch)
        elif ch in ")]}":
            depth = max(0, depth - 1)
            buf.append(ch)
        elif ch == sep and depth == 0:
            out.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
        i += 1
    out.append("".join(buf).strip())
    return [x for x in out if x != ""]


def split_fields(text: str) -> list[str]:
    """Whitespace split outside quotes."""
    out, buf, quote = [], [], None
    i = 0
    while i < len(text):
        ch = text[i]
        if quote:
            buf.append(ch)
            if ch == "\\" and i + 1 < len(text):
                buf.append(text[i + 1])
                i += 2
                continue
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
            buf.append(ch)
        elif ch.isspace():
            if buf:
                out.append("".join(buf))
                buf = []
        else:
            buf.append(ch)
        i += 1
    if buf:
        out.append("".join(buf))
    return out


def unquote(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        return value[1:-1]
    return value


def parse_kv(tokens: list[str]) -> tuple[dict[str, str], list[str]]:
    kv, flags = {}, []
    for tok in tokens:
        if "=" in tok:
            k, v = tok.split("=", 1)
            kv[k.strip().lower()] = unquote(v.strip())
        else:
            flags.append(tok)
    return kv, flags


def parse_module(path: str) -> Module:
    mod = Module(path=path)
    with open(path, "rb") as f:
        raw = f.read()
    if raw.startswith(b"\xef\xbb\xbf"):
        mod.issues.append(Issue("warning", 1, "bom", "File starts with a UTF-8 BOM."))
        raw = raw[3:]
    text = raw.decode("utf-8", "replace")
    if "\r\n" in text:
        mod.issues.append(Issue("info", 1, "crlf", "File uses CRLF line endings."))
        text = text.replace("\r\n", "\n")

    current: tuple[str, int, list[tuple[int, str]]] | None = None
    for lineno, line in enumerate(text.split("\n"), 1):
        stripped = line.strip()
        if not stripped:
            continue
        sec = SECTION_RE.match(stripped)
        if sec:
            current = (sec.group(1), lineno, [])
            mod.sections.append(current)
            continue
        meta = META_RE.match(stripped)
        if meta and current is None:
            mod.meta[meta.group(1).lower()] = meta.group(2).strip()
            continue
        if current is None:
            if not stripped.startswith(("#", ";", "//")):
                mod.issues.append(Issue("error", lineno, "stray-line",
                                        "Content before the first section is not metadata."))
            continue
        if stripped.startswith(("#", ";", "//")):
            continue
        current[2].append((lineno, stripped))
    return mod


def check_meta(mod: Module) -> None:
    add = mod.issues.append
    if not mod.meta.get("name", "").strip():
        add(Issue("error", 1, "meta-name", "Missing #!name."))
    if not mod.meta.get("desc", "").strip():
        add(Issue("warning", 1, "meta-desc", "Missing #!desc; users cannot tell what the module does."))
    if "system" in mod.meta:
        system = unquote(mod.meta["system"]).lower()
        if system not in {"ios", "mac", "macos", "tvos", "ipados", "all"}:
            add(Issue("warning", 1, "meta-system", f"Unknown #!system value: {system}"))
    for key in mod.meta:
        if key not in KNOWN_META:
            add(Issue("info", 1, "meta-unknown", f"Non-standard metadata key #!{key} (ignored by Surge)."))
    if "arguments" in mod.meta:
        names = [p.split(":", 1)[0].strip() for p in split_top(mod.meta["arguments"])]
        for name in names:
            if not re.fullmatch(r"[A-Za-z0-9_]+", name):
                add(Issue("warning", 1, "arg-name",
                          f"Argument name {name!r} is not ASCII letters/digits/underscore; "
                          "Surge documents only those, and non-ASCII names are not portable."))


def check_sections(mod: Module) -> None:
    seen = {}
    for name, lineno, _ in mod.sections:
        base = name.strip().lower()
        key = base
        if base.startswith("wireguard ") or base.startswith("tailscale ") or base.startswith("ruleset "):
            key = base.split(" ", 1)[0] + " *"
        if key in MODULE_FORBIDDEN_SECTIONS:
            mod.issues.append(Issue("error", lineno, "section-forbidden",
                                    f"[{name}] cannot be patched by a module."))
        elif key not in KNOWN_SECTIONS and key not in {"wireguard *", "tailscale *", "ruleset *"}:
            mod.issues.append(Issue("warning", lineno, "section-unknown",
                                    f"Unknown section [{name}]; check spelling (Surge preserves it as-is)."))
        if key in seen:
            mod.issues.append(Issue("warning", lineno, "section-duplicate",
                                    f"Section [{name}] appears more than once."))
        seen[key] = True


def check_placeholders(mod: Module) -> None:
    declared = set()
    if "arguments" in mod.meta:
        for part in split_top(mod.meta["arguments"]):
            declared.add(part.split(":", 1)[0].strip())
    used: dict[str, int] = {}
    for name, _, lines in mod.sections:
        for lineno, line in lines:
            for m in PLACEHOLDER_RE.finditer(line):
                used.setdefault(m.group(1).strip(), lineno)
    for name, lineno in used.items():
        if name not in declared:
            mod.issues.append(Issue("error", lineno, "placeholder-undeclared",
                                    f"Placeholder {{{{{name}}}}} is not declared in #!arguments."))
    for name in declared:
        if name not in used:
            mod.issues.append(Issue("warning", 1, "argument-unused",
                                    f"Argument {name!r} is declared but never referenced."))


def check_rules(mod: Module) -> None:
    for name, _, lines in mod.sections:
        if name.strip().lower() != "rule":
            continue
        for lineno, line in lines:
            if "{{{" in line:
                continue
            parts = split_top(line)
            if not parts:
                continue
            rtype = parts[0].strip().upper()
            if rtype == "FINAL":
                if len(parts) < 2:
                    mod.issues.append(Issue("error", lineno, "rule-final", "FINAL needs a policy."))
                continue
            if len(parts) < 3:
                mod.issues.append(Issue("error", lineno, "rule-fields",
                                        "Rule needs at least TYPE,VALUE,POLICY."))
                continue
            policy = parts[2].strip()
            if rtype in {"AND", "OR", "NOT"}:
                if len(parts) >= 3:
                    policy = parts[2].strip()
            if not re.fullmatch(r"[A-Za-z0-9_.-]+", policy.split("=")[0]):
                mod.issues.append(Issue("warning", lineno, "rule-policy",
                                        f"Unusual policy token {policy!r}."))
                continue
            if policy.upper() not in MODULE_ALLOWED_RULE_POLICIES and "," not in policy:
                mod.issues.append(Issue("warning", lineno, "rule-policy-module",
                                        f"Module rules normally use only DIRECT/REJECT/REJECT-TINYGIF; got {policy!r}."))


def check_scripts(mod: Module) -> None:
    for name, _, lines in mod.sections:
        if name.strip().lower() != "script":
            continue
        for lineno, line in lines:
            templated = "{{{" in line
            if "=" not in line:
                mod.issues.append(Issue("error", lineno, "script-form",
                                        "Script line must look like: name = type=...,script-path=..."))
                continue
            _, rest = line.split("=", 1)
            parts = split_top(rest)
            kv, flags = parse_kv(parts)
            stype = kv.get("type", "generic").lower()
            if stype not in SCRIPT_TYPES and not templated:
                mod.issues.append(Issue("error", lineno, "script-type", f"Unknown script type {stype!r}."))
            if "script-path" not in kv or not kv["script-path"]:
                mod.issues.append(Issue("error", lineno, "script-path", "Missing script-path."))
            elif "{{{" not in kv["script-path"]:
                sp = kv["script-path"]
                if not re.match(r"^(https?://|/)", sp) and not os.path.isfile(
                        os.path.join(os.path.dirname(os.path.abspath(mod.path)), sp)):
                    mod.issues.append(Issue("warning", lineno, "script-local",
                                            f"Local script not found next to the module: {sp}"))
            if stype in {"http-request", "http-response"} and not kv.get("pattern"):
                mod.issues.append(Issue("error", lineno, "script-pattern",
                                        f"{stype} requires pattern=."))
            if stype == "cron" and not kv.get("cronexp"):
                mod.issues.append(Issue("error", lineno, "script-cron", "cron requires cronexp=."))
            if stype == "event" and not kv.get("event-name"):
                mod.issues.append(Issue("error", lineno, "script-event", "event requires event-name=."))
            if "max-size" in kv and "{{{" not in kv["max-size"] and not re.fullmatch(r"-?\d+", kv["max-size"]):
                mod.issues.append(Issue("error", lineno, "script-max-size", "max-size must be an integer."))
            if "timeout" in kv and "{{{" not in kv["timeout"] and not re.fullmatch(r"\d+(\.\d+)?", kv["timeout"]):
                mod.issues.append(Issue("error", lineno, "script-timeout", "timeout must be a number of seconds."))
            if "engine" in kv and "{{{" not in kv["engine"] and kv["engine"].lower() not in {"auto", "jsc", "webview"}:
                mod.issues.append(Issue("error", lineno, "script-engine", "engine must be auto, jsc or webview."))
            if flags:
                mod.issues.append(Issue("info", lineno, "script-flags", f"Unparsed tokens: {flags}"))


def check_mitm(mod: Module) -> None:
    for name, _, lines in mod.sections:
        if name.strip().lower() != "mitm":
            continue
        for lineno, line in lines:
            if "{{{" in line:
                continue  # templated line: final syntax depends on the user's arguments
            if "=" not in line:
                mod.issues.append(Issue("error", lineno, "mitm-form", "MITM lines must be key = value."))
                continue
            key, value = line.split("=", 1)
            key = key.strip().lower()
            if key not in MITM_MODULE_KEYS:
                mod.issues.append(Issue("warning", lineno, "mitm-key",
                                        f"Modules normally patch only hostname/skip-server-cert-verify; got {key}."))
            if key == "hostname":
                hosts = [h.strip() for h in split_top(value) if h.strip()]
                if not hosts:
                    mod.issues.append(Issue("error", lineno, "mitm-empty", "Empty MITM hostname list."))
                if "*" in hosts and not any(h.startswith("-") for h in hosts):
                    mod.issues.append(Issue("warning", lineno, "mitm-broad",
                                            "hostname contains a bare * with no exclusions; MITM scope is very broad."))
                for h in hosts:
                    if h.startswith("%"):
                        continue
                    if "/" in h:
                        mod.issues.append(Issue("warning", lineno, "mitm-regex",
                                                f"MITM hostname is not a regex: {h!r}"))


def check_http(mod: Module) -> None:
    for name, _, lines in mod.sections:
        sec = name.strip().lower()
        for lineno, line in lines:
            if "{{{" in line:
                continue  # templated line: final syntax depends on the user's arguments
            if sec == "url rewrite":
                fields = split_fields(line)
                if len(fields) < 2:
                    mod.issues.append(Issue("error", lineno, "urlrewrite-fields",
                                            "URL Rewrite needs: regex replacement [header|302|307|reject]."))
                    continue
                rtype = fields[2].lower() if len(fields) >= 3 else "header"
                if rtype not in REWRITE_TYPES:
                    mod.issues.append(Issue("error", lineno, "urlrewrite-type",
                                            f"Unknown URL Rewrite type {rtype!r}."))
            elif sec == "header rewrite":
                fields = split_fields(line)
                offset = 0
                if fields and fields[0].lower() in {"http-request", "http-response"}:
                    offset = 1
                if len(fields) < offset + 3:
                    mod.issues.append(Issue("error", lineno, "headerrewrite-fields",
                                            "Header Rewrite needs direction, regex, action, field [value]."))
                    continue
                action = fields[offset + 1].lower()
                if action not in HEADER_ACTIONS:
                    mod.issues.append(Issue("error", lineno, "headerrewrite-action",
                                            f"Unknown header action {action!r}."))
                if action in {"header-add", "header-replace", "header-replace-regex"} and len(fields) < offset + 4:
                    mod.issues.append(Issue("error", lineno, "headerrewrite-value",
                                            f"{action} needs a value."))
            elif sec == "map local":
                fields = split_fields(line)
                if not fields:
                    continue
                kv, _ = parse_kv(fields[1:])
                dtype = kv.get("data-type", "file").lower()
                if dtype not in MAP_LOCAL_TYPES:
                    mod.issues.append(Issue("error", lineno, "maplocal-type",
                                            f"data-type must be file/text/tiny-gif/base64, got {dtype!r}."))
                if dtype in {"text", "file", "base64"} and "data" not in kv:
                    mod.issues.append(Issue("error", lineno, "maplocal-data",
                                            f"data-type={dtype} requires data=."))
                if "status-code" in kv:
                    try:
                        code = int(kv["status-code"])
                        if not 200 <= code <= 999:
                            raise ValueError
                    except ValueError:
                        mod.issues.append(Issue("error", lineno, "maplocal-status",
                                                "status-code must be an integer in 200..999."))
            elif sec == "body rewrite":
                fields = split_fields(line)
                if not fields:
                    continue
                direction = fields[0].lower()
                if direction in {"http-request-jq", "http-response-jq"}:
                    if len(fields) < 3:
                        mod.issues.append(Issue("error", lineno, "bodyrewrite-jq",
                                                f"{direction} needs: url-pattern jq-expression."))
                elif direction in {"http-request", "http-response"}:
                    if len(fields) < 4:
                        mod.issues.append(Issue("error", lineno, "bodyrewrite-fields",
                                                "Body Rewrite needs: direction url-pattern regex replacement."))
                    elif (len(fields) - 2) % 2 != 0:
                        mod.issues.append(Issue("warning", lineno, "bodyrewrite-pairs",
                                                "Regex/replacement pairs are unbalanced."))
                else:
                    mod.issues.append(Issue("error", lineno, "bodyrewrite-direction",
                                            f"Body Rewrite must start with http-request/http-response[-jq], got {direction!r}."))
            elif sec == "panel":
                if "=" not in line:
                    mod.issues.append(Issue("error", lineno, "panel-form", "Panel line must be Name = key=value,..."))
                    continue
                _, rest = line.split("=", 1)
                kv, _ = parse_kv(split_top(rest))
                if "title" not in kv:
                    mod.issues.append(Issue("warning", lineno, "panel-title", "Panel has no title."))
                if "style" in kv and kv["style"] not in {"good", "info", "alert", "error"}:
                    mod.issues.append(Issue("error", lineno, "panel-style",
                                            "style must be good, info, alert or error."))
                if "script-name" in kv and not kv["script-name"]:
                    mod.issues.append(Issue("error", lineno, "panel-script", "script-name is empty."))


def lint(path: str, strict: bool = False) -> Module:
    mod = parse_module(path)
    check_meta(mod)
    check_sections(mod)
    check_placeholders(mod)
    check_rules(mod)
    check_scripts(mod)
    check_mitm(mod)
    check_http(mod)
    if strict:
        for issue in mod.issues:
            if issue.level == "warning":
                issue.level = "error"
    return mod


def main(argv: list[str]) -> int:
    args = [a for a in argv[1:] if not a.startswith("--")]
    flags = {a for a in argv[1:] if a.startswith("--")}
    if len(args) != 1:
        print(__doc__.strip())
        return 2
    if not os.path.isfile(args[0]):
        print(f"not a file: {args[0]}", file=sys.stderr)
        return 2
    mod = lint(args[0], strict="--strict" in flags)
    errors = sum(1 for i in mod.issues if i.level == "error")
    warnings = sum(1 for i in mod.issues if i.level == "warning")
    payload = {
        "file": os.path.abspath(mod.path),
        "name": unquote(mod.meta.get("name", "")),
        "sections": [s[0] for s in mod.sections],
        "arguments": [p.split(":", 1)[0].strip() for p in split_top(mod.meta.get("arguments", ""))] if "arguments" in mod.meta else [],
        "errors": errors,
        "warnings": warnings,
        "issues": [i.__dict__ for i in mod.issues],
    }
    if "--json" in flags:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"{mod.path}: {payload['name'] or '(no name)'} — {errors} error(s), {warnings} warning(s)")
        for i in mod.issues:
            print(f"  {os.path.basename(mod.path)}:{i.line}: {i.level}: [{i.code}] {i.message}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
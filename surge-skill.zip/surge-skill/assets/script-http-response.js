// Template: http-response script that removes ad fields from a JSON body.
// Module line:
//   ads = type=http-response, pattern=^https?://api\.example\.com/v1/feed, \
//         script-path=https://example.com/js/ads.js, requires-body=true, max-size=2097152, timeout=10
//
// Rules:
// - requires-body must be true to read/replace the body.
// - Call $done() exactly once on every path.
// - Never return a body when requires-body is false.

(function () {
  try {
    if (!$response.body) {
      $done({});
      return;
    }

    var obj = JSON.parse($response.body);

    // Example: delete known ad containers without failing when absent.
    if (obj.data) {
      delete obj.data.ads;
      delete obj.data.banners;
      if (Array.isArray(obj.data.items)) {
        obj.data.items = obj.data.items.filter(function (item) {
          return !item || item.isAd !== true;
        });
      }
    }

    $done({ body: JSON.stringify(obj) });
  } catch (e) {
    console.log("ads.js failed: " + e);
    $done({}); // leave the response untouched
  }
})();
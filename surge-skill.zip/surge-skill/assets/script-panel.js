// Template: generic script used as a Surge Panel data source.
// Module lines:
//   [Panel]
//   ExampleStatus = title="Example Status", content="Loading…", style=info, \
//                   script-name=example-status, update-interval=60
//   [Script]
//   example-status = type=generic, timeout=10, script-path=https://example.com/js/status-panel.js
//
// Rules:
// - Panel results require {title, content, style?, icon?, "icon-color"?}.
// - $trigger is "button" when the user taps the panel, "auto-interval" for the timer.
// - Call $done() exactly once.

(function () {
  function fail(message) {
    $done({ title: "Example Status", content: message, style: "error" });
  }

  if (typeof $httpClient === "undefined") {
    fail("This script must run inside Surge.");
    return;
  }

  $httpClient.get({ url: "https://api.ipify.org?format=json", timeout: 8 }, function (err, resp, data) {
    if (err) {
      fail("Request failed: " + err);
      return;
    }
    if (resp.status !== 200) {
      fail("HTTP " + resp.status);
      return;
    }
    $done({
      title: "Example Status",
      content: "Public IP: " + data,
      style: "info",
      icon: "network",
      "icon-color": "#007aff"
    });
  });
})();
# Surge 配置（Profile）参考

Profile 是 Surge 行为的唯一来源。INI 风格纯文本，按 `[Section]` 分节。

## 1. 格式与文件类型

```ini
[General]
loglevel = notify

[Proxy]
ProxyA = http, 1.2.3.4, 80

[Rule]
DOMAIN-SUFFIX,example.com,ProxyA
FINAL,DIRECT
```

- 文件类型：`.conf`（完整配置）、`.dconf`（分离段）、`.sgmodule`（模块）。
- 注释：行首 `#`、`;`、`//`；行尾注释也可以，但注释符前至少一个空格。
- `[General]`/`[MITM]` 等键值段顺序无关；`[Rule]` 等行式段顺序即行为。
- 未知段会原样保留，不报错。
- 双引号值中 `\"` 表示引号、`\\` 表示反斜杠（iOS 5.21+/Mac 6.8+）。

### 完整段列表

| 段 | 用途 |
|---|---|
| `[General]` | 全局设置 |
| `[Proxy]` | 代理策略 |
| `[Proxy Group]` | 策略组 |
| `[Rule]` | 规则 |
| `[Host]` | 本地 DNS 映射 |
| `[URL Rewrite]` | URL 重写 |
| `[Header Rewrite]` | 头部重写 |
| `[Body Rewrite]` | Body 重写 |
| `[Map Local]` | 本地 Mock |
| `[MITM]` | HTTPS 解密 |
| `[Keystore]` | 证书/私钥 |
| `[SSID Setting]` | 按网络/子网覆盖设置 |
| `[Script]` | 脚本 |
| `[Panel]` | 信息面板 |
| `[Ponte]` | Surge Ponte |
| `[Port Forwarding]` | 端口转发 |
| `[IP Rewrite]` | IP 层处理 |
| `[Testing]` | 吞吐测试 |
| `[DHCP]` | DHCP 服务（Mac 网关） |
| `[Snell Server]` | 内置 Snell 服务端 |
| `[MTProto]` | 内置 MTProto 服务端 |
| `[WireGuard <name>]` | WireGuard 配置 |
| `[Tailscale <name>]` | Tailscale 配置 |
| `[Ruleset <name>]` | 内联规则集 |

## 2. 分离配置（Detached Profile）

```ini
[Proxy]
#!include Proxy.dconf

[Proxy Group]
#!include Group.dconf

[Rule]
#!include Rule.dconf
```

- 被引用文件必须含对应 `[Section]` 声明；可含一个、多个段或完整配置。
- 单文件专用 include：UI 可编辑，改动静默写回该文件。
- 多文件 include：该段在 UI 中只读。
- 混排（iOS 5.22+/Mac 6.9+）：`#!include` 与普通行可混用，按出现位置展开；行式段仍可编辑。
- 通配段（iOS 5.22+/Mac 6.9+）：`[Ruleset *]`、`[WireGuard *]`、`[Tailscale *]` 可从另一个配置/URL 导入所有同名段。
- Mac 6.0+ 可直接 include 远程托管配置 URL，形成本地 overlay。
- `[Rule]` 中的 `FINAL` 会立即终止匹配，其后的 include/规则永远不生效。

## 3. 托管配置

```ini
#!MANAGED-CONFIG https://example.com/surge.conf interval=60 strict=true
```

| 参数 | 默认 | 说明 |
|---|---|---|
| `interval` | 86400 秒 | 最短更新间隔；到点不保证立即更新 |
| `strict` | false | 到期后必须成功更新；即使 strict，用户仍可通过小组件/VPN 开关启动 |

- 新远程配置也必须含 `#!MANAGED-CONFIG`，否则会退化为普通配置。
- 托管配置本地不可编辑；要改就复制或做关联配置。
- 可在托管配置中用 `#!FORBIDDEN-AUTO-UPGRADE smart-group` 阻止升级时自动把 url-test/load-balance 组改成 smart（iOS 5.11+/Mac 5.7+）。

## 4. 行级条件（Line Requirement）

```ini
Group = url-test, policyA, policyB #!REQUIREMENT CORE_VERSION<22
DOMAIN,reject.com,REJECT #!MACOS-ONLY
Domain,x,REJECT #!REQUIREMENT "SYSTEM=='iOS' AND LANGUAGE=='zh-Hans'"
```

变量：`CORE_VERSION`、`SYSTEM`（iOS/macOS/tvOS）、`SYSTEM_VERSION`、`DEVICE_MODEL`、`LANGUAGE`、`DEVICE_NAME`（iOS 5.22+/Mac 6.9+）。

运算符：`=` `==` `>=` `=>` `<=` `=<` `>` `<` `!=` `<>` `AND` `&&` `OR` `||` `NOT` `!` `BEGINSWITH` `CONTAINS` `ENDSWITH` `LIKE` `MATCHES`。字符串用单引号；含空格的表达式用双引号。

简化标记：`#!IOS-ONLY`、`#!MACOS-ONLY`、`#!TVOS-ONLY`（iOS 5.14.3+/Mac 5.10+）。

Core Version：Mac 6.8/iOS 5.21 起为 `major*1000000 + minor*1000 + patch`；更早：`20` = Mac 5.6/iOS 5.10（Body Rewrite、内联 Map Local），`22` = Mac 5.7/iOS 5.11（Smart Group）。

## 5. [General] 常用键

键名不区分大小写；全部可选。

### 日志

| 键 | 值/默认 | 说明 |
|---|---|---|
| `loglevel` | verbose/info/notify/warning，notify | verbose 明显影响性能 |
| `debug-cpu-usage` / `debug-memory-usage` | false | 排障用 |

### DNS

| 键 | 说明 |
|---|---|
| `dns-server` | 逗号分隔 IP[:port] 或 `system`；默认用系统 DNS；并发查询，先答先得 |
| `encrypted-dns-server` | `https://`/`h3://`/`quic://`/`tls://`/`tcp://` URL；配了它后传统 DNS 只用于连通性测试和解析加密 DNS 的主机名 |
| `encrypted-dns-follow-outbound-mode` | 默认 false；加密 DNS 走 DIRECT，开启后走规则 |
| `encrypted-dns-skip-cert-verification` | 默认 false，不安全 |
| `allow-dns-svcb` | 默认 false；禁止 SVCB 以迫使系统用 A 记录 |
| `use-local-host-item-for-proxy` | 默认 false；开启后 `[Host]` 的 IP 映射会用于代理连接 |
| `hijack-dns` | 如 `8.8.8.8:53` 或 `*:53`，劫持硬编码 DNS |
| `always-real-ip` | Host List；这些域名返回真实 IP 而非 Fake IP |

### IPv6 / VIF

| 键 | 默认 | 说明 |
|---|---|---|
| `ipv6` | false | 完整 IPv6 支持，会查询 AAAA |
| `ipv6-vif` | disabled | `disabled`/`auto`/`always` |
| `tun-excluded-routes` | — | VIF 绕过的 CIDR |
| `tun-included-routes` | — | 增加更小路由 |
| `icmp-forwarding` | true | 增强模式下转发 ICMP（ping） |

### 代理 / 远程控制

| 键 | 说明 |
|---|---|
| `skip-proxy` | Host List；iOS 强制走 VIF、macOS 写入系统代理例外；**不是**分流 |
| `exclude-simple-hostnames` | 简单主机名也跳过代理 |
| `proxy-restricted-to-lan` | 默认 true，代理服务仅限当前子网 |
| `gateway-restricted-to-lan` | 默认 true，网关仅限当前子网 |
| `external-controller-access` | `key@ip:port`，如 `key@0.0.0.0:6165` |
| `http-api` | `key@ip:port`，如 `key@0.0.0.0:6166` |
| `http-api-tls` | HTTP API 用 HTTPS（需 MITM CA） |
| `http-api-web-dashboard` | 在 API 端口提供 Web Dashboard |
| `http-api-mcp` | iOS 6.0+/Mac 6.11+，提供 `/v1/mcp` |

### 连通性测试

| 键 | 默认 | 说明 |
|---|---|---|
| `internet-test-url` | `http://bing.com/` | 互联网/DIRECT 测试 URL |
| `proxy-test-url` | `http://bing.com/` | 代理默认测试 URL |
| `test-timeout` | 5 秒 | 代理测试超时；DIRECT 为 10 秒 |
| `proxy-test-udp` | — | `hostname@ipv4`，UDP 测试 |

### 流量处理

| 键 | 说明 |
|---|---|
| `force-http-engine-hosts` | Host List；把 TCP 当 HTTP 处理（仅明文）；默认只匹配 80，`:port`/`:0`/`*:0` |
| `always-raw-tcp-hosts` | Host List；跳过协议嗅探 |
| `always-raw-tcp-keywords` | Mac 5.5+；按子串跳过嗅探 |
| `udp-policy-not-supported-behaviour` | `REJECT`/`DIRECT`，Mac 6.0+ 默认 REJECT |
| `udp-priority` | 默认 true，高负载优先 UDP（游戏模式） |
| `block-quic` | `per-policy`/`all-proxy`/`all`/`always-allow`，默认 per-policy |
| `show-error-page` | Mac 5.8+，默认 true |
| `show-error-page-for-reject` | 默认 false |

### iOS 专属

| 键 | 说明 |
|---|---|
| `compatibility-mode` | 0 auto / 1 Proxy+VIF / 2 Proxy only / 3 VIF only / 4 Proxy+VIF(VIF 地址) / 5 VIF only 多小路由 |
| `auto-suspend` | 检测到 Surge Mac 网关接管时自动暂停，默认 true |
| `allow-wifi-access` / `allow-hotspot-access` | 允许局域网/热点使用代理服务 |
| `wifi-access-http-port` / `wifi-access-socks5-port` | 默认 6152 / 6153 |
| `wifi-access-http-auth` | `username:password` |
| `wifi-assist` / `all-hybrid` | Wi-Fi 差时用蜂窝 / 同时用两者 |
| `hide-vpn-icon` | 隐藏 VPN 图标 |
| `include-all-networks` | 接管所有流量（可能影响 AirDrop/Xcode） |
| `include-local-networks` / `include-apns` / `include-cellular-services` / `include-device-communication` | 需配合 include-all-networks |

### Mac 专属

| 键 | 说明 |
|---|---|
| `http-listen` | `[password@]address[:port]`，默认 6152；多个用逗号 |
| `socks5-listen` | `[user:pass@]address[:port]`，默认 6153 |
| `set-system-socks-proxy` | 默认 true |
| `read-etc-hosts` | 默认 true，读取 /etc/hosts |
| `subnet-exp-wifi-always-match` | 默认 true |

## 6. DNS 行为

### 内部 DNS 客户端

- 同时向所有 DNS 服务器查询，先返回的有效答案获胜。
- 1 秒无答案重发；5 次（约 5 秒）后失败。
- A/AAAA：开启 IPv6 且网络支持时并行查询；连续 5 次只有 A 答案则暂停 AAAA。
- 缓存：按 TTL；乐观缓存（过期先返回、后台刷新）；iOS 200 条 / macOS 2000 条，LRU；网络变化自动清空。
- 特殊主机名：无点主机名拼接系统搜索域；`.local` 走系统解析；末尾点去掉并抑制搜索域；IP 字面量直接返回。

### Fake IP（VIF 开启时）

- 监听：macOS `198.18.0.2`，iOS `198.18.0.4`，IPv6 `fd00:6152::2`；`198.18.0.2–198.18.0.9` 都视为 Surge DNS。
- A/AAAA 直接返回 `198.18.0.0/15` 中的 Fake IP，并持久记录映射；连接到达时还原成域名做规则匹配。
- TTL：iOS 5 秒 / macOS 30 秒。
- 非 A/AAAA（TXT/MX 等）转发上游。
- `hijack-dns` 劫持硬编码 DNS；只有能解析为 DNS 查询的包会被劫持。
- `always-real-ip` 豁免 Fake IP，返回真实地址。
- 默认拒绝 SVCB(type 65)，迫使客户端回退 A；`allow-dns-svcb=true` 放行。
- pre-matching REJECT：REJECT 返回无记录、REJECT-DROP 静默丢弃、REJECT-NO-DROP 返回 sink `198.18.0.244`。

### [Host] 本地 DNS 映射

```ini
[Host]
abc.com = 1.2.3.4
abc.com = 1.2.3.4, 5.6.7.8, ::1
*.dev = 6.7.8.9
foo.com = bar.com
bar.com = server:8.8.8.8
example.com = server:https://cloudflare-dns.com/dns-query
Macbook = server:system
example.com = script:dnspod
DOMAIN-SET:https://example.com/domains.txt = server:https://doh.example.com/dns-query
RULE-SET:https://example.com/rules.txt = 10.0.0.10
```

- 从上到下，第一条命中生效。
- 通配 `*`/`?` 对完整主机名做简单匹配；`*.google.com` 不匹配 `google.com`。
- 别名类似 CNAME，会以新名字重新解析。
- `server:` 可指定 IP、加密 DNS URL、多个服务器（iOS 5.21+/Mac 6.8+）。
- `server:system`/`server:syslib` 交给系统；增强模式下仍是转发给系统配置的 DNS；`server:force-syslib`（Mac 6.4.3+）强制系统解析库。
- `script:<name>` 使用 `type=dns` 脚本。
- `DOMAIN-SET:`/`RULE-SET:`（Mac 5.10+）把整个列表绑定到 DNS 映射；只有域名类条目有效。
- 代理服务器的主机名永远不会匹配 `[Host]`，避免解析循环。
- macOS 会把 `/etc/hosts` 追加在 profile 之后（profile 优先）；`read-etc-hosts=false` 关闭。

## 7. [SSID Setting] 按网络覆盖

```ini
[SSID Setting]
"SSID:My Home" dns-server=192.168.1.1,encrypted-dns-server=off
"SSID:My Home" tfo-behaviour=force-enabled
```

- 网络表达式与 `SUBNET` 规则相同：`SSID:`、`BSSID:`、`ROUTER:`、`TYPE:`、`MCCMNC:`。
- 可覆盖：`dns-server`、`encrypted-dns-server`、`tfo-behaviour`、`suspend` 等。
- `tfo-behaviour`：`auto`/`force-enabled`/`force-disabled`。

## 8. [Keystore]

```ini
[Keystore]
cert1 = type=p12, base64=<base64>, password=123456
key1  = type=openssh-private-key, base64=<base64>
```

- `type` 可省略：有 password → p12；无 password → openssh-private-key。
- 用途：TLS 客户端证书 `client-cert=cert1`；MITM CA `ca-keystore-name=cert1`（优先于 `ca-p12`）；SSH 私钥 `private-key=key1`。

## 9. 平台差异（影响配置）

- Mac 独占：网关/DHCP、Ponte 服务端、`external` 策略、`PROCESS-NAME`、`MAC-ADDRESS`、`surge-cli`、Dashboard、`http-listen`/`socks5-listen` 等。增强模式两端都有，但 Mac 需手动开启；iOS 属 VPN 接管并默认开启。
- iOS 独占：蜂窝运行、`compatibility-mode`、`CELLULAR*` 策略、`hybrid`、`CELLULAR-*` 规则、Cellular Fallback、URL Scheme 的 `start`/`stop`/`toggle`（`install-config`/`install-module` 两端可用）、`allow-wifi-access` 等。
- 平台专属键在另一端被忽略；同一份配置可共享，按行用 `#!IOS-ONLY` 等限制。
- tvOS：核心与 iOS 一致，脚本/WireGuard 可用；无本机 UI，配置由 iOS 部署；依赖 UI 的功能不可用。

## 10. 常见错误

- 以为 `skip-proxy` 是分流：它只决定"系统代理 vs VIF"，规则仍会匹配。
- 托管配置里直接改内容：会被覆盖；应复制或做关联配置。
- 在 `[Rule]` 中间放 `FINAL`：后面的规则全部失效。
- `[Host]` 里写正则：它是通配符语法，不是正则。
- 配了 `encrypted-dns-server` 却还指望 `dns-server` 解析普通域名：传统 DNS 只做 bootstrap。
- 开启 `ipv6` 后 DNS 变慢：不需要时保持 false。
- `always-real-ip` 写得过宽：会失去 Fake IP 的零延迟优势。
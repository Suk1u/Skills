# Surge 规则系统参考

来源：manual.nssurge.com（现行手册）。所有语法以手册为准；标注版本的是新特性。

## 1. 求值与优先级

- `[Rule]` 从上到下逐条匹配，**第一条命中即决定策略**，后面的规则不再执行。
- 主配置的规则必须由一条启用的 `FINAL` 收尾，否则配置校验失败；模块本身不含 `FINAL`，它的行合并进主配置后由主配置的 `FINAL` 收尾。
- 出站模式为 Direct / Global 时，规则列表**完全不参与**。
- 带 `pre-matching` 的规则会被单独提取，在 DNS 查询 / TCP 握手阶段优先检查。
- 顺序原则：具体 → 宽泛；域名规则 → IP 规则；`FINAL` 永远最后。

## 2. 规则语法

```
TYPE,VALUE,POLICY[,参数...]
```

- VALUE 含逗号时必须用双引号或单引号包住（如正则、逻辑子规则）。
- POLICY：代理策略名、策略组名、内置策略（`DIRECT`、REJECT 家族）、`DEVICE:<name>`（Ponte）。
- 行尾支持 `//`、`#`、`;` 注释（注释符前至少一个空格）。
- 未知参数会被静默忽略。

### 通用参数

| 参数 | 形式 | 适用 | 作用 |
|---|---|---|---|
| `no-resolve` | flag | IP-CIDR/6、GEOIP、IP-ASN、RULE-SET、DOMAIN-SET | 未解析的域名直接跳过该规则，不触发 DNS |
| `extended-matching` | flag | DOMAIN 系、URL-REGEX、RULE-SET、DOMAIN-SET | 同时匹配 TLS SNI 与 HTTP Host/:authority |
| `pre-matching` | flag | 域名系、IP 系、SRC-IP、端口、SUBNET、蜂窝、逻辑规则、RULE-SET/DOMAIN-SET | 在 DNS/握手阶段提前拒绝；策略必须是 REJECT 家族 |
| `dns-failed` | flag | 仅 FINAL | DNS 解析失败时仍使用 FINAL 的策略 |
| `requires-resolve` | flag | 仅 SCRIPT | 先解析域名，脚本可读 `$request.dnsResult` |
| `notification-text=<text>` | kv | 任意规则含 FINAL | 命中时发通知 |
| `notification-interval=<sec>` | kv | 任意规则含 FINAL | 同一规则通知最小间隔，默认 300 秒 |
| `update-interval=<sec>` | kv | RULE-SET、DOMAIN-SET | 远程资源重新下载间隔，默认 86400；负数禁用 |
| `always-capture=<session>` | kv | 任意规则含 FINAL | 强制开启 HTTP 抓包（调试） |

## 3. 域名规则

| 类型 | 匹配 |
|---|---|
| `DOMAIN` | 完全相等 |
| `DOMAIN-SUFFIX` | 域名本身及所有子域（`google.com` 不匹配 `content-google.com`） |
| `DOMAIN-KEYWORD` | 主机名包含子串；通配符按字面处理 |
| `DOMAIN-WILDCARD` | `*`（可跨点）、`?`、`[...]` 字符类 |
| `DOMAIN-SET` | 外部纯域名列表（见 §8） |

```ini
DOMAIN,www.apple.com,Proxy
DOMAIN-SUFFIX,apple.com,DIRECT
DOMAIN-KEYWORD,google,Proxy
DOMAIN-WILDCARD,api-*.example.com,Proxy
DOMAIN-SUFFIX,example.com,Proxy,extended-matching
```

- 匹配大小写不敏感；末尾根点 `example.com.` 会被忽略。
- 默认只匹配请求主机名；`extended-matching` 额外匹配 TLS SNI 与 Host/:authority，适合客户端直接连 IP 的场景。
- 域名规则**不触发 DNS**，应放在 IP 规则之前。

## 4. IP 规则与 DNS

| 类型 | 匹配 |
|---|---|
| `IP-CIDR` | IPv4 网段；Mac 6.0+ 可省略掩码（视为 /32） |
| `IP-CIDR6` | IPv6 网段；单地址视为 /128 |
| `GEOIP` | ISO 国家代码，大小写不敏感；`UNKNOWN` 匹配数据库无结果 |
| `IP-ASN` | 十进制 ASN 或 `AS13335`；`UNKNOWN` 同理 |

```ini
IP-CIDR,192.168.0.0/16,DIRECT,no-resolve
IP-CIDR6,2001:db8::/32,Proxy
GEOIP,US,DIRECT
IP-ASN,13335,Proxy
```

DNS 行为（关键）：

- 请求目标是 IP 字面量：直接匹配，GEOIP/IP-ASN 直接查库。
- 目标是域名：求值到**第一条 IP 类规则**时暂停，做一次 DNS，再回到该规则继续；结果缓存。
- DNS 失败：除非 `FINAL` 带 `dns-failed`，否则整个请求以 DNS 错误失败。
- `no-resolve`：未解析的域名直接跳过该规则，不触发查询。
- IP-CIDR 测第一个 IPv4 记录；IP-CIDR6 测第一个 IPv6 记录；GEOIP/IP-ASN 优先 IPv4，回退 IPv6。

## 5. HTTP 规则

仅对进入 Surge HTTP 引擎的请求生效；HTTPS 需 MITM 才能看到完整 URL/UA。

```ini
USER-AGENT,Instagram*,DIRECT
URL-REGEX,"^https://example\.com/(a|b),?c",Proxy
```

- `USER-AGENT`：通配符 `*`/`?`，**大小写敏感**。
- `URL-REGEX`：对完整 URL 做正则，**大小写敏感**，模式只要在 URL 中命中即可（需要前缀匹配时用 `^`）；含逗号要加引号。
- `URL-REGEX` 支持 `extended-matching`。
- iOS 15 起系统不在 CONNECT 中发送 UA，未 MITM 时 HTTPS 的 UA 规则通常不可用。

## 6. 来源、端口、进程

```ini
DEST-PORT,80-81,DIRECT
SRC-PORT,>=50000,DIRECT
IN-PORT,6152,DIRECT
SRC-IP,192.168.20.0/24,Proxy
DEVICE-NAME,Kids-iPad,REJECT
MAC-ADDRESS,A4:83:E7:11:22:33,Proxy
PROCESS-NAME,Telegram,Proxy
```

- 端口值：单值、闭区间 `10000-20000`、`>`/`<`/`>=`/`<=`。
- 来源类规则只对**其他设备**的流量有意义（网关模式、代理服务、DHCP、Ponte）。
- `PROCESS-NAME` 仅 Mac；`MAC-ADDRESS` Mac 6.1.0+ 且仅同局域网。
- `DEVICE-NAME` 支持 `*`/`?`，大小写敏感。

## 7. 协议与网络

```ini
PROTOCOL,STUN,REJECT
HOSTNAME-TYPE,IPv6,REJECT
SUBNET,SSID:Office-*,DIRECT
CELLULAR-RADIO,LTE,DIRECT
CELLULAR-CARRIER,310260,Proxy
```

- `PROTOCOL` 取值（区分大小写）：`HTTP`、`HTTPS`、`TCP`、`UDP`、`QUIC`、`STUN`、`MTProto`、`DOH`、`DOH3`、`DOQ`、`DOT`、`DNS`。
  - `TCP` 同时匹配 HTTP/HTTPS/MTProto；`UDP` 同时匹配 QUIC/STUN。
  - `DOH*`/`DOQ`/`DOT`/`DNS` 只匹配 Surge 自己的 DNS 请求；默认绕过规则直连，需 `encrypted-dns-follow-outbound-mode=true` 才走规则。
  - 不支持 `pre-matching`。
- `HOSTNAME-TYPE`（Mac 5.7.3+）：`IPv4`、`IPv6`、`DOMAIN`、`SIMPLE`，大小写敏感。
- `SUBNET` 表达式：`SSID:`、`BSSID:`、`ROUTER:`、`TYPE:WIFI|WIRED|CELLULAR`、`MCCMNC:`；裸值向后兼容。
- `CELLULAR-*` 仅 iOS，且仅在非 Wi-Fi 时生效。

## 8. 逻辑规则

```ini
AND,((SRC-IP,192.168.1.110),(DOMAIN-SUFFIX,example.com)),DIRECT
OR,((DOMAIN-SUFFIX,a.com),(DOMAIN-SUFFIX,b.com)),Proxy
NOT,((SRC-IP,192.168.1.110)),Proxy
```

- 子规则写在括号内，**不带策略**，与 RULE-SET 文件内的写法相同。
- `AND`/`OR` 短路求值；`NOT` 只接受一个子规则。
- 可嵌套，最大深度 10；子规则可以是规则集内合法的任意类型（含 RULE-SET、SCRIPT），不能是 FINAL。
- 子规则可带自己的 `no-resolve`/`extended-matching`；`pre-matching` 只能加在整个逻辑规则上，且要求所有子规则类型支持、策略为 REJECT 家族。

```ini
AND,((DOMAIN-SUFFIX,example.com),(SUBNET,TYPE:CELLULAR)),Proxy
AND,((PROTOCOL,UDP),(RULE-SET,https://example.com/streaming.list)),REJECT
AND,((SRC-IP,192.168.1.120),(NOT,((RULE-SET,LAN)))),Proxy
```

## 9. SCRIPT 规则

```ini
[Script]
ssid-rule = type=rule,script-path=ssid-rule.js

[Rule]
SCRIPT,ssid-rule,DIRECT,requires-resolve
```

脚本返回 `$done({matched: true/false})`。结果在同一次请求求值中缓存；缺少脚本或禁用脚本时视为不匹配。规则脚本在连接热路径执行，保持短小，推荐 `engine=jsc`。

```js
var ok = ($request.hostname === 'home.com' && $network.wifi.ssid === 'My Home');
$done({matched: ok});
```

## 10. RULE-SET、DOMAIN-SET、内联规则集

### RULE-SET

```ini
RULE-SET,https://example.com/streaming.list,Proxy,no-resolve,update-interval=43200
RULE-SET,LAN,DIRECT
RULE-SET,Streaming,StreamingProxy
```

解析顺序：内置名（`SYSTEM`、`LAN`）→ 内联 `[Ruleset <name>]` 段名 → URL / 本地文件。

规则集文件写法（**不含策略列**）：

```text
# 注释
DOMAIN-SUFFIX,example.com
DOMAIN,cdn.example.org,extended-matching
IP-CIDR,203.0.113.0/24,no-resolve
IP-ASN,13335
```

- 文件内允许逐行 `no-resolve`/`extended-matching`；**不允许 FINAL 和 pre-matching**。
- 行级选项可应用到整组：`RULE-SET,...,no-resolve,extended-matching`。
- 无效行会被跳过并警告；空行/`#`/`//`/`;` 为注释。
- 大列表会预编译为域名索引/IP 二进制库；同一 URL 不能同时作为 RULE-SET 和 DOMAIN-SET。

### DOMAIN-SET

```ini
DOMAIN-SET,https://example.com/adblock.txt,REJECT
DOMAIN-SET,my-domains.txt,Proxy
```

文件每行一个域名：

```text
example.com        # 精确匹配
.ads.example.org   # 自身及所有子域
```

仅能匹配域名，适合几十万条的广告/追踪列表；比 RULE-SET 更省内存。

### 内联与嵌套（Mac 5.3.1+ / iOS 5.22 起增强）

```ini
[Ruleset Media]
RULE-SET,Streaming
DOMAIN-SUFFIX,video.example

[Ruleset Streaming]
DOMAIN-SUFFIX,stream.example

[Rule]
RULE-SET,Media,Proxy
```

- 内联规则集可嵌套（最多 8 层），循环引用会在加载时拒绝。
- 模块可以向同名内联规则集**追加**行；不能删除或重排已有行（iOS 5.23+/Mac 6.10+）。

## 11. FINAL 与 REJECT 家族

```ini
FINAL,Proxy,dns-failed
```

- `FINAL` 必须存在且启用（模块除外）；`dns-failed` 让 DNS 失败时仍落到 FINAL。
- REJECT 家族：
  - `REJECT`：拒绝；HTTP 显示错误页（受 `show-error-page-for-reject` 控制）。
  - `REJECT-TINYGIF`：HTTP 返回 1px GIF，其他连接断开；网页广告常用。
  - `REJECT-DROP`：静默丢弃，避免客户端疯狂重试。
  - `REJECT-NO-DROP`：同 `REJECT`，但不会被自动升级为 DROP。
- 30 秒内同目标命中 50 次会升级为 DROP（现行手册阈值）。
- `pre-matching` 在 DNS 阶段返回无记录 / sink 地址，TCP SYN 阶段直接 RST 或丢包；支持域名系、IP 系、SRC-IP、端口、SUBNET、蜂窝、逻辑规则和 RULE-SET/DOMAIN-SET（顶层规则）。

## 12. 模块中的规则限制

- 模块的 `[Rule]` 行插入到主配置规则列表**顶部**。
- 模块规则只能使用内置策略：`DIRECT`、`REJECT`、`REJECT-TINYGIF`（实践中 `REJECT-DROP`/`REJECT-NO-DROP` 也常见，但按文档以三者为准）。
- 模块不能新增代理策略或策略组，因此规则只能指向内置策略。
- 需要走代理的规则应写在主配置或通过 `[Ruleset *]` 引入。

## 13. 排错清单

1. `surge-cli profile diff` 看模块/包含后的最终配置。
2. 请求详情 → Notes 看命中规则、DNS、失败原因。
3. 规则不生效：检查是否被更靠前的规则截胡；模块规则是否在顶部；`FINAL` 是否提前出现。
4. 域名走了错误线路：检查 IP 规则是否在域名规则之前触发了解析。
5. HTTPS 规则失效：`URL-REGEX`/`USER-AGENT` 需要 MITM。
6. 广告漏网：确认 QUIC 已处理（`PROTOCOL,QUIC` 或 `block-quic`），否则请求绕开 HTTP 规则。
7. DNS 失败导致全断：给 IP 规则加 `no-resolve`，或给 `FINAL` 加 `dns-failed`。
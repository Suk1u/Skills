# Surge 模块（.sgmodule）编写指南

模块是对当前配置的**补丁**，优先级高于主配置，可独立开关。适合：给不可编辑的托管配置打补丁、一键切换某项设置、分发别人写好的功能、按设备/场景定制。

## 1. 模块 vs 分离配置

| | 模块 `.sgmodule` | 分离配置 `.dconf` |
|---|---|---|
| 本质 | 覆盖/追加主配置的某些段 | 把主配置的段拆到另一个文件 |
| 生效 | 启用后覆盖主配置 | 始终是主配置的一部分 |
| 可关闭 | 是，独立开关 | 否 |
| 能改 Proxy/策略组 | 否 | 是（作为配置的一部分） |
| 适合 | 临时补丁、功能分发 | 线路/规则拆分、多设备共享 |

模块启用状态**不会**通过 iCloud 同步到其他设备。

## 2. 模块能改什么

官方文档列出的可覆盖段：

| 段 | 合并语义 |
|---|---|
| `[General]`、`[MITM]` | `key = value` 覆盖；`key = %APPEND% value` 追加；`key = %INSERT% value` 前插。MITM 只能操作 `hostname` 和 `skip-server-cert-verify` |
| `[WireGuard *]` | 覆盖/追加键 |
| `[MTProto]`、`[Snell Server]` | 整段替换（必须写完整） |
| `[Ruleset *]` | 向同名内联规则集追加行；不能删除/重排 |
| `[Rule]`、`[Script]`、`[URL Rewrite]`、`[Header Rewrite]`、`[Host]`、`[IP Rewrite]` | 新行插入到原内容**顶部** |

实践中还广泛使用 `[Map Local]`、`[Body Rewrite]`、`[Panel]`（KISS/Rabbit 语料大量出现，官方 `#!requirement` 示例也明确提到 Body Rewrite），同样按行插入/覆盖处理。保险起见，发布前在目标 Surge 版本实测。

**不能做**：

- 不能定义或修改 `[Proxy]`、`[Proxy Group]`。
- 不能改 MITM 的 CA 证书（`ca-p12`/`ca-passphrase`/`ca-keystore-name`）。
- 模块中的 `[Rule]` 只能用内置策略：`DIRECT`、`REJECT`、`REJECT-TINYGIF`（语料里也见 `REJECT-DROP`/`REJECT-NO-DROP`，但超出文档承诺，不建议依赖）。
- 不能改主配置的 UI 可编辑内容；模块设置覆盖主配置后，UI 里改不动。

## 3. 文件与元数据

文件名任意，扩展名 `.sgmodule`；UTF-8 纯文本。`#!` 行必须位于第一个 `[Section]` 之前。

```ini
#!name=Example: Remove Ads
#!desc=Blocks banner and splash ads in Example App. Requires MITM.
#!system=ios
#!category=Ads
#!author=Your Name
#!homepage=https://example.com/module
#!icon=https://example.com/icon.png
#!date=2026-11-05
#!version=1.0.0
#!arguments=enableLog:false
#!arguments-desc=enableLog: print debug output to the script log
```

### 官方文档保证的键

| 键 | 说明 |
|---|---|
| `#!name` | 模块名（必填） |
| `#!desc` | 描述（强烈建议） |
| `#!system` | 限制平台，如 `ios`、`mac`、`tvos` |
| `#!arguments` | 参数表声明 |
| `#!arguments-desc` | 参数表整体说明（不是逐项说明，但社区普遍当逐项文档用） |
| `#!requirement` | 版本/平台条件表达式 |

### 客户端识别但手册未列的键

`#!category` 会被模块页用于分类（iOS 更新日志明确新增分类字段）；`#!author`、`#!homepage`、`#!icon` 会被客户端用于展示；`#!version` 是第三方约定；`#!date` 通常不展示。**Loon 专有键**（`#!loon_version`、`#!openUrl`、`#!tag`、`#!system_version`、`#!repo`）在 Surge 中忽略，移植时应删除或保留但不依赖。

注意：`#!system = ios` 中间不能有空格；`#!auther` 是拼写错误。语料中存在这些错误，不要模仿。

## 4. 参数表（Module Arguments）

```ini
#!arguments=hostname:example.com, enable_mitm:true, title:"My Panel"
#!arguments-desc=hostname: 目标域名\nenable_mitm: 是否启用 MITM
```

- 逗号分隔 `键:默认值`；默认值可省略（空字符串）。含逗号/空格的值用双引号包住。
- 键名建议只用字母、数字、下划线；文档明确要求。中文键、`Languages[0]`、`UPDATE-INTERVAL` 在语料中存在且似乎可用，但不要主动使用。
- 引用：`{{{键}}}`，**大小写敏感**；应用模块前做纯文本替换，可出现在任意段、任意位置（包括脚本名、规则值、面板名、MITM 主机名）。注意：替换不改变模块规则只能用内置策略的限制，不能把策略位替换成用户策略组。
- 未声明的占位符不会被替换，且可能导致配置校验失败；声明了但未使用的参数是死参数。
- 用户填写的值保存在模块实例中，下次编辑会回显。
- 不支持 `%PARAMETER%` 和 query-string 形式。

```ini
[General]
force-http-engine-hosts = %APPEND% {{{hostname}}}

[MITM]
hostname = %APPEND% {{{hostname}}}

[Script]
example = type=generic, script-path=script/example.js, argument="{{{enable_mitm}}}"
```

脚本里通过 `$argument` 读取 `argument=` 的字符串。约定可用 `k=v&k=v`（Rabbit 风格），脚本自行 split；值含 `=`/`&` 时先 `encodeURIComponent`。

**参数不能做条件包含**：替换发生在应用前，无法根据布尔值删除整行。需要"关闭某功能"时，可以让参数替换脚本名/域名，使该行指向一个不存在的脚本或被排除的域名。语料常见填 `#` 表示禁用，但这是社区约定、不是官方语义；`#` 出现在行中可能只生成非法域名/策略，发布前必须实测。

## 5. 版本与平台条件

```ini
#!requirement=CORE_VERSION>=20
#!requirement=CORE_VERSION>=20 && (SYSTEM=='iOS' || SYSTEM=='tvOS')
```

变量：`CORE_VERSION`（数字）、`SYSTEM`（macOS/iOS/tvOS）、`SYSTEM_VERSION`、`DEVICE_MODEL`、`LANGUAGE`。运算符与行级条件相同（`>=`、`&&`、`||`、`==`、`CONTAINS` 等）。

Core Version 参考：

- `20` = Surge Mac 5.6.0 / iOS 5.10.0（Body Rewrite、内联 Map Local）
- `22` = Mac 5.7.0 / iOS 5.11.0（Smart Group）
- 新规则：`major*1000000 + minor*1000 + patch`，如 Mac 6.8.0/iOS 5.21.0 = `6008000`

## 6. [Script] 在模块中的写法

```ini
[Script]
ads = type=http-response, pattern=^https?://api\.example\.com/v1/feed, script-path=https://example.com/js/ads.js, requires-body=true, max-size=1048576, timeout=10, engine=webview, argument="{{{enableLog}}}"
```

- 现代写法 `name = type=...,pattern=...,script-path=...`；旧式 `<type> <pattern> script-path=...` 仍兼容但不推荐。
- 模块内脚本名要唯一、稳定；Panel 的 `script-name` 必须逐字一致。
- **相对 `script-path` 相对 profile 目录，不是模块所在目录**。分发给他人时用 https URL；本地开发才用相对路径。
- 远程脚本建议固定版本（`.../v1.2.3/x.js`），`releases/latest` 会悄悄改变行为；语料中 `script-update-interval=0` 很常见，通常意为频繁检查更新，手册未明确 0 的语义，谨慎使用。
- `requires-body` 尽量少开；`max-size` 用明确字节数，`-1` 才是不限制（`0` 的语义未文档化）。
- protobuf/gRPC 用 `binary-body-mode=1`；大 JSON 用 `engine=webview`；`rule`/`dns` 用 `jsc`。
- cron 脚本在 iOS 上加 `wake-system=1`，并避免每小时超过 10 次。
- 脚本里的 `$done()` 必须恰好一次；异常要兜底。

## 7. [MITM] 在模块中的写法

```ini
[MITM]
hostname = %APPEND% api.example.com, cdn.example.com
```

- `hostname` 是 Host List，不是正则：`*`/`?` 通配，`-` 排除且要放前面，`:port` 指定端口。
- 模块只能改 `hostname` 与 `skip-server-cert-verify`。
- 只列脚本/重写真正需要的域名；不要习惯性 `*`。
- 非标准端口的明文 HTTP 用 `[General] force-http-engine-hosts = %APPEND% host:port`；不想被解析的主机用 `always-raw-tcp-hosts`。
- HTTPS 未开 MITM 时，模块里的 URL Rewrite / Header Rewrite / Body Rewrite / Map Local / 脚本全部静默失效。

## 8. 模块与 Loon / 其他客户端

KISS（LoonKissSurge）语料里仍有大量 Loon 痕迹。移植到 Surge 时：

| Loon 写法 | Surge 处理 |
|---|---|
| `#!loon_version`、`#!openUrl`、`#!system_version`、`#!tag` | 忽略；可删除 |
| `hostname-disabled = ...` | **Surge 支持**（MITM 段，从有效 hostname 列表中移除主机）；模块只能改 `hostname` 与 `skip-server-cert-verify`，不要依赖它 |
| `[Plugin]` 段 | Surge 不识别；内容是元数据，移到 `#!` 头 |
| `[Rewrite]` 段 | Surge 拆成 `[URL Rewrite]` / `[Header Rewrite]`；需按行转换 |
| `^url - reject`（Loon URL Rewrite） | Surge 文档写作 `^url _ reject`（正则、替换占位、类型）。`-` 在实践中也能被接受（语料大量使用），但新写用 `_` |
| `type=...,pattern=...,script-path=...` | Surge 支持（现代写法） |
| `requires-body=true` / `1` | 两者都支持 |
| `max-size=0` | 未文档化；改用 `-1` 或明确字节数 |
| `%APPEND%` / `%INSERT%` | Surge 支持（General/MITM） |
| `$httpClient`、`$persistentStore`、`$notification`、`$done`、`$argument` | 基本兼容，但参数顺序/字段需逐个核对 |
| `argument="[...]"` 数组式 | Surge 只把它当普通字符串；脚本自行解析 |
| 中文/带连字符参数名 | 可能可用，但非文档保证；发布建议 ASCII+下划线 |

转换后务必用 linter + 真机验证；语法"看起来对"不等于 Surge 会接受。

## 9. 模块分发

- 托管：把 `.sgmodule` 放在可公开访问的 HTTPS URL（GitHub raw 最常用）。
- 安装：Surge 内"模块 → 安装模块 → 输入 URL"，或 `surge:///install-module?url=<URL-encoded>`。
- 本地模块：把 `.sgmodule` 放进 profile 目录。
- 建议同时提供：`#!name`、`#!desc`、`#!author`、`#!homepage`（README/使用说明）、`#!icon`、`#!category`、`#!date`、`#!version`。
- README 写清：用途、安装链接、必填参数、如何获取 Cookie/Token、更新方式、已知限制、兼容版本。
- 不要分发含明文账号、密码、Cookie、私有 token 的模块；改用 `#!arguments` 或 `$persistentStore`。
- 远程脚本 = 远程代码执行；只引用可信来源，并尽量固定版本。

## 10. 应用顺序与冲突

- 模块设置覆盖主配置；多个模块同时启用时，相对顺序会影响冲突结果。
- 行式段是"插入到顶部"：模块规则先于主配置规则；模块之间的相对行序也可能受应用顺序影响。
- 不要依赖隐式顺序。用 `surge-cli profile diff` 查看应用模块后的最终配置。
- 与其他模块冲突时：缩小 MITM/规则范围、用更具体的域名、把可选项做成参数。

## 11. 调试与验证

1. 安装/启用模块，确认没有配置校验错误。
2. `surge-cli profile diff` 看最终合并结果。
3. 请求查看器确认请求进入 HTTP 引擎、命中规则/脚本，查看 Notes。
4. 脚本：`debug=true` + `console.log`；或脚本编辑器手动运行；Logbook 远程看日志。
5. 面板：先看静态 content，点刷新看脚本返回；`update-interval=-1` 便于手动测试。
6. 关掉模块再测一次，确认问题确实由模块引起。
7. iOS 上注意 NE 内存：大 body、`max-size=-1`、WebView 大对象都可能导致进程被系统终止。

## 12. 发布前检查清单

**结构**
- [ ] `#!name`、`#!desc` 存在；需要时加 `category/icon/homepage/author/date/version`。
- [ ] 只改允许的段；没有 `[Proxy]`/`[Proxy Group]`/CA。
- [ ] 用 `%APPEND%` 而不是直接覆盖用户的 General/MITM 值。
- [ ] 模块规则只用 `DIRECT`/`REJECT`/`REJECT-TINYGIF`。
- [ ] 所有 `{{{占位符}}}` 都在 `#!arguments` 中声明，且没有多余参数。
- [ ] 没有残留 `example.com` 占位域名。

**脚本**
- [ ] 每条脚本有 `type`、`script-path`；HTTP 类有 `pattern`。
- [ ] `requires-body` 只在必要 URL 开启；`max-size` 合理。
- [ ] 远程脚本固定版本；本地脚本不用于分发。
- [ ] 每个分支恰好一次 `$done()`；异常有兜底。
- [ ] 脚本名与 Panel `script-name` 一致。

**MITM**
- [ ] hostname 只覆盖必要域名；排除项在前。
- [ ] 需要 MITM 的模块在 desc 中明确提示用户开启 MITM 并安装 CA。
- [ ] 不需要 MITM 的模块（纯 cron/panel）不要声明 MITM。

**发布**
- [ ] 真机验证：安装 → 启用 → 触发 → 看 Notes/日志 → 关闭 → 确认无残留。
- [ ] README 完整；参数有说明；版本/日期更新。
- [ ] 用 `scripts/surge_module_lint.py` 跑一遍。

## 13. 语料中的真实反模式

- 在 http-request 脚本里串行发网络请求，导致请求卡到 timeout。
- `requires-body=true` + `max-size=-1` 处理 MB 级 protobuf，iOS 上 OOM。
- 缺少 `$done()` 或异常路径不兜底，表现为"装上了但没效果"。
- 修改 header 时破坏 Content-Length/Transfer-Encoding。
- MITM 用 `*` 或 `*.tencent.com` 这类过宽范围。
- 脚本 URL 写死个人域名，域名失效后模块全挂。
- 把账号密码写进 JS 或模块。
- cron `*/5 * * * *` + 面板 `update-interval=1`，耗电。
- 参数占位符未声明/大小写不一致、`argument` 引号不闭合。
- 在模块里直接覆写用户的 `dns-server`/`encrypted-dns-server`，与用户配置冲突。
- 直接照搬 Loon 的 `max-size=0`、中文参数名，或误以为 Surge 不支持 `hostname-disabled`。

## 14. 模板

- `assets/module-minimal.sgmodule`
- `assets/module-rewrite.sgmodule`
- `assets/module-script.sgmodule`
- `assets/module-panel.sgmodule`
- `assets/script-http-response.js`（响应改写脚本模板）
- `assets/script-panel.js`（面板脚本模板）

用 `python3 scripts/surge_module_lint.py <file>` 做结构检查。
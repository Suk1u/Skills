# Surge 进阶功能参考

覆盖网关、Ponte、内置服务端、DHCP、IP Rewrite、MTProto、端口转发、增强模式等。多数需要 Mac，且配置键有明确版本门槛。

## 1. 网关模式（Mac）

Surge Mac 作为局域网设备的 L3 网关：把设备网关与 DNS 指向 Mac，流量走同一套规则/策略。**开关在 Mac UI，不在 profile**。

- 可以让 Surge 同时充当 DHCP 服务器，自动下发自己为网关/DNS。
- 设备列表可在 Mac App、Dashboard、`surge-cli device` 查看；可给设备改名。
- 按设备分流：

```ini
DEVICE-NAME,Apple-TV,Proxy
SRC-IP,192.168.1.100,DIRECT
MAC-ADDRESS,A4:83:E7:11:22:33,Proxy
```

- `gateway-restricted-to-lan` 默认 true，只接受当前子网设备。
- UDP Fast Path（Mac 6.4+，仅 VM 网关）：客户端 1 秒 ≥10 个或 10 秒 ≥30 个新 UDP 连接时降级为纯 L3 转发，绕过规则/MITM；目标端口 <1024 与 FakeIP 的 UDP 不降级。Dashboard 可按设备开关；Mac 6.11+ 可全局关闭。
- 详细排障见 `troubleshooting.md`。

## 2. Surge Ponte

设备间私有网络，同 iCloud 账户自动注册；可用确认码共享给另一账户。

- 任意 Surge 设备可作**客户端**；**只有 Surge Mac 能作服务端**。
- 用 `<name>.sgponte` 访问（设备名来自系统设置，不是公网 DNS）。
- 可作为策略：`DEVICE:<name>`。
- 通道：Direct、NAT Traversal、Proxy NAT Traversal、LAN Only、IPv6，自动选择。

```ini
[Ponte]
client-proxy-name = Relay-Proxy
server-proxy-name = Proxy-A, Proxy-B
```

| 键 | 说明 |
|---|---|
| `client-proxy-name` | 需要中继时使用的代理策略 |
| `server-proxy-name` | 服务端可用于代理穿透的策略，必须支持 Full Cone UDP 中继 |

- 同 LAN 自动走 LAN；访问本机名时策略转为 DIRECT。
- 中国大陆出境 UDP 丢包严重时，客户端最好也配同一代理。
- 端到端加密；但 `external-controller-access` 的局域网直连不加密，不要暴露到公网。

## 3. 内置 Snell 服务端

```ini
[Snell Server]
interface = 0.0.0.0
port = 6160
psk = RANDOM_KEY_HERE
version = 6
mode = default
```

| 键 | 说明 |
|---|---|
| `interface` | 监听地址；iOS/tvOS 上 `0.0.0.0` 绑定当前 Wi-Fi/以太网与 loopback，并跟随网络变化 |
| `port` | TCP 端口 |
| `psk` | 预共享密钥，客户端必须一致 |
| `version` | `1` 或 `6`，默认 1 |
| `mode` | `default`/`unshaped`/`unsafe-raw`，仅 v6；客户端必须一致 |

- Mac/iOS/tvOS 都支持（iOS 5.21+）；常开的 Apple TV 可作家中入口。v6 需要 Mac 6.8.0+（对应 iOS 版本）。
- 客户端：`snell, host, 6160, psk=..., version=6`。
- 模块可提供 `[Snell Server]`（iOS 5.23+/Mac 6.10+），整段替换。

## 4. DHCP 服务端（Mac）

随网关模式启用；静态分配的 IP 会从动态池排除（Mac 6.8+）。

```ini
[DHCP]
max-lease-time = 86400
default-lease-time = 43200
min-lease-time = 600
one-lease-per-client = true
ping-check = true
```

默认值通常够用。网络中只能有一个 DHCP 服务器；Mac 必须有线、静态 IP。

## 5. [SSID Setting] 按网络覆盖

```ini
[SSID Setting]
SSID:MyHome suspend=true
"SSID:Office-*" dns-server=192.168.1.1,encrypted-dns-server=off
TYPE:CELLULAR cellular-fallback=off
```

| 参数 | 平台 | 说明 |
|---|---|---|
| `suspend` | 两端 | 匹配网络下暂停 Surge；iOS 不会断开 VPN 隧道，只是停止处理流量。**不要与 `include-all-networks=true` 同用**，否则该网络下完全无网 |
| `cellular-fallback` | iOS | `default`/`off`/`wifi-assist`/`hybrid` |
| `cellular-mode` | Mac | 把匹配网络视为计量网络，启用 Metered Network Mode |
| `tfo-behaviour` | 两端 | `auto`/`force-enabled`/`force-disabled` |
| `dns-server` | 两端 | 覆盖全局 DNS |
| `encrypted-dns-server` | 两端 | 覆盖全局加密 DNS；`off` 可显式关闭 |

## 6. IP Rewrite

```ini
[IP Rewrite]
10.7.0.1 = reflect
203.0.113.0/24 = reject
2001:db8::/32 = drop
```

- 语法：`IP/CIDR = action`，从上到下第一条命中。
- 作用在 VIF 的 IP 层，早于 TCP/UDP 栈、规则与策略；不会出现在请求列表。
- 只对 VIF 流量（增强模式、网关模式）生效，不影响代理服务请求。
- 若目标被 `tun-excluded-routes` 或本地路由覆盖，先用 `tun-included-routes` 把它导回 VIF。

| 动作 | 行为 |
|---|---|
| `reflect` | 交换源/目的后发回；网关模式下反射给 LAN 设备 |
| `reject` | TCP 回 RST，其他包回 ICMP administratively prohibited |
| `drop` | 静默丢弃 |

典型用途：SideStore 等本机开发服务（`10.7.0.1 = reflect`），配合 `tun-included-routes = %INSERT% 10.7.0.1/32`。

## 7. MTProto 代理服务端

```ini
[MTProto]
interface = 127.0.0.1
port = 5753
secret = 0123456789abcdef0123456789abcdef
ipv6 = false
```

- Telegram 专用入口，不是通用代理；Surge 不持有 Telegram 授权密钥，不能解密/修改消息。
- `secret` 为 32 位十六进制（16 字节），可用 `openssl rand -hex 16` 生成；可带 `dd` 前缀；不支持 `ee`（Fake TLS）。
- `interface`：`127.0.0.1` 本机；局域网用具体地址；`0.0.0.0` 所有 IPv4（注意防火墙）。iOS 上 `0.0.0.0` 会被改写为 `127.0.0.1`。
- `ipv6`：出口 DC 地址族，不是监听。
- `dc-config-url` 可覆盖 DC 映射；默认从 Surge 的 GitHub 拉取，缓存 30 天。
- 规则可用 `PROTOCOL,MTProto` 匹配；目标通常是 IP，用 IP/ASN 规则更可靠。
- 每个 `[MTProto]` 只能有一个监听。

## 8. 端口转发

```ini
[Port Forwarding]
0.0.0.0:6841 localhost:3306 policy=SQL-Server-Proxy
```

- 格式：`监听地址:端口 目标主机:端口 [policy=策略]`。
- 不依赖系统代理/增强模式；没有 `policy` 时走正常规则匹配。
- iOS 5.14.3+/Mac 5.10+。

## 9. 增强模式（VIF）

- 创建虚拟网卡并注册默认路由，接管原始流量，不依赖系统代理设置。
- iOS 是 VPN 接管的一部分，默认开启；Mac 需手动启动。
- VIF 只处理 TCP/UDP/ICMP；其他协议无法通过。
- ICMP 不能代理，由 VIF 自己回响应；`icmp-forwarding` 控制是否转发。
- Fake IP 应答：macOS `198.18.0.2`，iOS `198.18.0.4`，IPv6 `fd00:6152::2`；连接到达时还原域名。
- Mac 5.8+ 使用 Network Extension 实现，旧的 `vif-mode` 等键仅为兼容保留，不再影响运行。

## 10. 测试与吞吐

- `internet-test-url`：互联网连通性/DIRECT 测试 URL。
- `proxy-test-url`：代理默认测试 URL。
- `test-timeout`：代理测试超时，默认 5 秒；DIRECT 10 秒。
- `proxy-test-udp`：UDP 测试，`hostname@ipv4`。
- `[Testing]` 段用于吞吐测试（按需在 App 内配置）。
- `surge-cli test-policy-bandwidth` / `benchmark` 可做策略带宽与加密性能测试。

## 11. 计量网络（Mac）

`[SSID Setting]` 中 `cellular-mode=true` 会把匹配网络标记为计量网络，启用 Metered Network Mode：只有允许列表中的应用可访问互联网，其他进程被拒绝。允许列表在 Mac UI 配置。

## 12. 平台速查

| 功能 | Mac | iOS | tvOS |
|---|---|---|---|
| 增强模式 | 手动开启 | VPN 接管默认 | 同 iOS |
| 网关/DHCP | ✅ | ❌ | ❌ |
| Ponte 服务端 | ✅ | ❌ | ❌ |
| 内置 Snell 服务端 | ✅ | ✅（5.21+） | ✅ |
| MTProto 服务端 | ✅（6.8+） | ✅（5.21+） | ❌ |
| 外部代理程序 | ✅ | 视为 REJECT | ❌ |
| `PROCESS-NAME` 规则 | ✅ | 忽略 | 忽略 |
| `MAC-ADDRESS` 规则 | ✅ | ❌ | ❌ |
| surge-cli / Dashboard | ✅ | 远程控制 | 远程控制 |
| URL Scheme 安装 config/module | ✅ | ✅ | ❌ |
| URL Scheme start/stop/toggle | ❌ | ✅ | ❌ |

平台专属键在另一端被忽略，因此同一份配置可以共享；需要限制行时用 `#!MACOS-ONLY` 等。

## 13. 常见坑

- `suspend=true` 与 `include-all-networks=true` 同用会导致该网络完全断网。
- DHCP 场景网络里出现第二个 DHCP 服务器会互相抢答。
- IP Rewrite 不生效：目标没被路由到 VIF，先加 `tun-included-routes`。
- MTProto 的 `secret` 必须是 32 位十六进制；`ee` 前缀不支持。
- Ponte 服务端只能是 Mac；iOS 只能作客户端。
- 网关模式不要用 Wi-Fi 作上行；P2P/下载器不适合走网关。
- 外部代理程序在 iOS 上会被当作 REJECT，不要写进跨平台配置。
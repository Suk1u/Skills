# Surge 排障指南

## 1. 先分类：接管问题还是转发问题

1. 打开请求查看器（Mac）或"最近的请求"（iOS）。
2. 访问 `https://bing.com`。
3. 列表里没有该请求 → **接管问题**；有 → **转发问题**（看请求详情 → Notes）。

改过抓包过滤器时，先确认测试请求没被隐藏。

## 2. 接管问题（Mac）

### 系统代理

```bash
scutil --proxy
```

正确结果应包含：

```
HTTPEnable : 1
HTTPPort : 6152
HTTPProxy : 127.0.0.1
HTTPSEnable : 1
HTTPSPort : 6152
HTTPSProxy : 127.0.0.1
```

不一致说明被其他软件抢占，或 Surge 的"设置为系统代理"没开。

### 增强模式

- 系统设置 → 网络 → VPN，确认 Surge 已开启；其他 VPN 会抢占。
- 验证：`ping apple.com` 返回 `198.18.x.x`，再 `curl -vvv https://apple.com`。
- 异常且重启无效：设置 → 系统权限总览 → 移除网络扩展与 VPN 配置 → 重启 → 重开 Surge。

### iOS

正常开启几乎不会接管失败；先重启，仍无效则重置网络设置。

## 3. 只在某些域名失败

- 检查 `skip-proxy`：其中的主机不走系统代理；删除对应项。
- 增强模式访问**内网 IP** 无法接管是正常的（存在更小、优先级更高的路由）。给该 IP 配 `[Host]` 域名，再让规则命中该域名。
- 检查是否有 VPN/其他代理同时运行；必要时用自定义 `direct` 策略绑定 `interface`。

## 4. 转发问题

请求详情 → Notes 常见错误：

| 错误 | 含义 | 处理 |
|---|---|---|
| `Connection refused` | 代理端口拒绝 | 检查代理配置/服务端 |
| `Connection timeout` | 连接超时 | 检查地址、端口、网络、防火墙 |
| `No upstream DNS server` | 没有有效 DNS | 配置 `dns-server` |
| `No route to host` | 本机无网络或路由错误 | 检查网络/代理 |
| `DNS error` | 解析失败 | 检查 DNS；给 IP 规则加 `no-resolve`；给 FINAL 加 `dns-failed` |
| `MITM Failed` | 证书/Pinning | 安装并信任 CA；Pinning 通常无法绕过 |

网络质量提示：TCP 握手超过 2000ms 时，Surge 会向所有传统 DNS 发查询；2000ms 内无应答就提示。频繁误报先检查 DNS 是否可达（中国大陆用 8.8.8.8 常不通）。

## 5. DNS 问题

### 请求查看器只显示 IP、不显示域名

原因：客户端 DNS 没指向 Surge 的 Fake IP 地址。

- 客户端 DNS 改为 `198.18.0.2`（IPv6 `fd00:6152::2`）。
- 不能改 DNS 的设备：开启"劫持所有发往 53 端口的 UDP DNS 查询"（`hijack-dns = *:53`）。
- 检查 IPv6 RA 下发的 DNS；关闭设备/浏览器的 DoH/DoT。
- 加密 DNS 场景给规则加 `extended-matching`，用 Host/SNI 匹配。
- `gateway.icloud.com`、`tether.edge.apple` 等以 IP 请求是预期行为。

### 解析慢/失败

- `dns-server` 不要用本地不可达的境外 DNS。
- 开启 `ipv6` 会并行查 AAAA，可能增加延迟；不需要就关。
- 配了 `encrypted-dns-server` 后，传统 DNS 只做 bootstrap；确认加密 DNS 可达。
- `[Host]` 是通配符语法，不是正则；`server:` 可指定单独 DNS。
- `server:syslib` 在增强模式下不生效；需要强制系统解析用 `server:force-syslib`（Mac 6.4.3+）。

## 6. MITM / 重写 / 脚本问题

| 现象 | 检查 |
|---|---|
| HTTPS 重写完全不生效 | MITM 总开关；hostname 是否覆盖；CA 是否安装并信任 |
| 只有部分请求生效 | pattern 是否锚定；URL 是否被 302/其他重写先改掉；是否走 QUIC |
| 脚本没运行 | `pattern`、`script-path`、脚本类型；`requires-body` 是否必要；脚本是否报错 |
| 脚本运行但无效果 | 是否调用了 `$done()`；返回值字段是否正确；是否被另一个同名脚本抢先 |
| 面板不更新 | `script-name` 是否一致；`update-interval`；`$trigger` 分支 |
| 修改 body 后请求失败 | 是否开了 `requires-body`；是否破坏 Content-Length；是否 chunked/100-continue |
| Map Local 不生效 | Rewrite 总开关；data-type/data 是否匹配；是否被更早的规则/重写截胡 |

调试手段：

- `debug=true`：每次从磁盘重载，`console.log` 写入请求 Notes。
- 脚本编辑器手动运行（mock 输入）。
- `surge-cli profile diff` 看模块合并结果。
- Logbook / `surge-cli logbook` 看配置重载、网络切换、脚本输出。
- 抓包查看器对比请求前后。

## 7. 模块问题

- 模块装了没效果：确认已启用；`profile diff` 看行是否插入；MITM/脚本是否满足前提。
- 规则被截胡：模块规则在顶部，但同一模块内先写的优先；检查是否有更早的 `pre-matching`。
- 配置校验失败：占位符未声明、参数名非法、段名拼错、脚本引用不存在。
- 与其他模块冲突：缩小范围、用参数、调整启用顺序；以 `profile diff` 为准。
- 本地模块的 `script-path` 相对 profile 目录，不是模块目录。

## 8. 网关模式

### 客户端无法上网

- 客户端网关是否指向 Surge Mac；DNS 是否 `198.18.0.2`。
- DHCP 场景：网络中只能有一个 DHCP 服务器；Mac 必须有线、静态 IP。
- 紧急恢复：关闭 Surge DHCP，重新开启主路由 DHCP。

### 性能差

1. 关闭 Surge 测外网（SpeedTest/WiFiman）；不达标查路由器/交换机/网线/ISP。
2. 内网 `iperf3`；有线千兆应 900Mbps+。
3. 开 Surge + 空白配置再测；偏低看 CPU。
4. 配加密代理 + 全局再测；受线路带宽与网关性能双重限制。

- 必须有线；排查时关闭 Jumbo MTU。
- P2P/下载器/直播可能瞬间数千连接，不适合走网关。
- Mac 6.4+ 的 VM UDP Fast Path 会把高频 UDP 客户端降级为 L3 转发，绕过代理规则与 MITM；目标端口 <1024 或 FakeIP 的 UDP 不走 Fast Path。

### IPv6 RA

- Surge 发更高优先级的单播 RA，只影响被接管设备；不分配地址前缀，原路由 RA 不能关。
- 原 RA 的 DNS 若是 link-local/路由自身地址，会绕过 Surge；应置空或改为公网 DNS。
- PS5 不支持；部分 Windows 报 Event 4205，可改手动 IPv6。

## 9. Ponte / 远程控制

- Ponte 只有 Mac 能作服务端（以现行手册为准）。
- `external-controller-access` 的局域网直连**不加密**，不要做端口转发/DMZ。
- HTTP API / Web Dashboard 不能经 Ponte 访问；外部控制器可以。
- 30 秒内 10 次认证失败会临时封禁来源；`surge-cli security ban` 查看/清除。

## 10. 耗电与性能

- 基带统计会把全机流量电耗算在 Surge 头上；官方实测 24 小时额外消耗 <2%。
- 主要额外开销：加解密、频繁 cron 唤醒。cron 每小时 >10 次会警告。
- `loglevel=verbose` 显著影响性能，不要日常开启。
- 大 body 脚本、`requires-body`、WebView 大对象会增加内存；iOS NE 有硬限制。
- Smart 组比 url-test 更省测试开销；成员很多时优先 Smart。

## 11. 常见冲突

- AdGuard、Viscosity、Little Snitch 与增强模式冲突。
- 其他 VPN 抢占系统代理/默认路由。
- `include-all-networks` 可能影响 AirDrop、Xcode 调试、USB Dashboard。
- 与 Parallels/VMware 桥接模式冲突（VM 网关）。
- macOS 26 起菜单栏图标可能被系统设置隐藏。

## 12. 排障顺序总结

1. 重启设备/App；确认问题可复现。
2. 请求查看器判断接管/转发。
3. 接管：系统代理 → 增强模式 → 权限/冲突。
4. 转发：Notes 错误 → DNS → 代理服务端 → 规则。
5. 重写/脚本：MITM → pattern → 脚本日志 → `$done()`。
6. 模块：启用状态 → `profile diff` → 冲突/参数。
7. 网关：客户端网关/DNS → DHCP 唯一性 → 有线/性能 → RA。
8. 仍无法定位：`surge-cli rule explain`、`dns trace`、`log watch`、`dump performance`。
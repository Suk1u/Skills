# Surge JavaScript 脚本参考

Surge 用 JavaScript 扩展能力。脚本在 `[Script]` 段声明，由 HTTP 流量、规则匹配、DNS、系统事件、cron 或手动触发。要求 Surge iOS 4+ / Mac 3.3.0+。

## 1. 脚本类型

| type | 触发 | 典型用途 |
|---|---|---|
| `http-request` | 请求发出前，URL 命中 pattern | 改 URL/头/body、直接返回 mock、阻断 |
| `http-response` | 响应返回客户端前 | 改状态码/头/body、去广告 |
| `rule` | 规则求值到 `SCRIPT` 行 | 自定义匹配条件 |
| `dns` | `[Host]` 中 `script:name` | 自定义 DNS 解析 |
| `event` | 系统事件 | 网络变化、通知、引擎启动、配置重载 |
| `cron` | 定时 | 签到、定时切换策略 |
| `generic` | 仅手动/面板/快捷指令/API | 工具脚本、Panel 数据源 |

## 2. 声明语法

现代写法（推荐）：

```ini
[Script]
modify-req = type=http-request, pattern=^https?://httpbin\.org, script-path=http-request.js, requires-body=true, max-size=16384
nightly    = type=cron, cronexp="0 2 * * *", script-path=cron.js
on-net     = type=event, event-name=network-changed, script-path=net.js
dnspod     = type=dns, script-path=dnspod.js
ssid-rule  = type=rule, script-path=ssid-rule.js
panel      = type=generic, script-path=panel.js
```

旧写法仍兼容（新配置不要用）：

```ini
http-response ^http://example.com script-path=x.js,requires-body=true
```

### 参数

| 参数 | 说明 |
|---|---|
| `type` | 七种类型之一；缺省 `generic`；未知类型整行被拒绝 |
| `script-path` | 必填；相对路径（相对 profile 目录）、绝对路径或 http(s) URL；远程脚本自动下载缓存 |
| `script-update-interval` | 远程脚本更新间隔，秒，默认 86400 |
| `timeout` | 脚本最长运行秒数，默认 5；超时终止并告警 |
| `argument` | 任意字符串，脚本内为 `$argument` |
| `engine` | `auto`/`jsc`/`webview`，默认 auto |
| `debug` | 本地脚本每次从磁盘重载；HTTP 脚本的 console.log 写入请求 Notes；远程 URL 脚本不受重载影响 |
| `pattern` | http-request/http-response 必填，URL 正则 |
| `requires-body` | 缓冲完整 body 交给脚本，默认 false，开销大 |
| `max-size` | body 上限，字节；默认 iOS 1 MB / Mac 10 MB；`-1` 不限制（仍有硬上限） |
| `binary-body-mode` | body 以 `Uint8Array` 传递/返回 |
| `full-header-mode` | headers 以 `[{field,value}]` 数组传递，保留重复字段（如 Set-Cookie） |
| `cronexp` | cron 必填，5 段或 6 段（带秒），含空格要加引号 |
| `event-name` | event 必填：`network-changed`、`notification`、`engine-started`、`profile-reloaded` |
| `wake-system` | 仅 iOS，cron 到点时用静默本地通知唤醒 Surge |

## 3. 引擎选择

| 引擎 | 优点 | 缺点 | 适用 |
|---|---|---|---|
| `jsc` | 启动快、调用开销低 | 在 NE 进程内，占内存；最多 2 个并行 | 高频小脚本：rule、dns |
| `webview` | 独立进程、可用 JIT 与 WebAPI（fetch/crypto/TextDecoder）、不占 NE 内存 | 启动稍慢、跨进程传大 body 效率低；最多 3 个并行 | 复杂、解析 MB 级 JSON |
| `auto` | 有 WebView 时用 WebView | — | 默认 |

用 WebAPI 时显式写 `engine=webview`。tvOS 仅 JSC。

## 4. 全局对象

### $environment

```js
$environment.system            // "iOS" / "macOS" / "tvOS"
$environment["surge-version"]
$environment["surge-build"]
$environment.language
$environment["device-model"]   // iOS 5.9+ / Mac 5.5+
```

### $script

```js
$script.name
$script.type
$script.startTime        // UNIX 秒
$script.sessionID
$script.binaryBodyMode
```

### $network

```js
$network.wifi.ssid, $network.wifi.bssid
$network.v4.primaryAddress, $network.v4.primaryInterface, $network.v4.primaryRouter
$network.v6.primaryAddress, $network.v6.primaryInterface
$network.dns            // 当前 DNS 服务器数组
$network["cellular-data"].carrier / .radio   // iOS
```

### 其他

- `$argument`：脚本行 `argument=` 的字符串。
- `$trigger`：`editor` / `http-api` / `intent` / `button` / `auto-interval`；普通 HTTP/规则/DNS/事件/cron 触发时不存在。
- `$intent.parameter`：快捷指令传入。
- `$input`：面板调用时 `{purpose:"panel", position, panelName}`。

## 5. $done

每个脚本必须**恰好调用一次** `$done()`，否则超时告警。

```js
$done();                    // 不修改，继续
$done({});                  // 同上
$done({abort: true});       // http-request/response：断开连接
$done({matched: true});     // rule
$done({address: "1.2.3.4"}); // dns
$done({title: "...", content: "..."}); // generic + Panel
```

- http-request/response 中 `$done()` 与 `$done({})` 等价，都是原样继续。
- 未捕获异常会中止本次脚本，改动不生效。

## 6. $httpClient

```js
$httpClient.get(options, function(error, response, data) { ... });
```

方法：`get/post/put/delete/head/options/patch`。

options 可为 URL 字符串或：

```js
{
  url: "https://example.com/api",     // 必填，http(s)
  headers: {"Content-Type": "application/json"},
  body: "{}",                          // string / object(JSON) / TypedArray
  timeout: 5,
  policy: "Proxy",                     // 用指定策略发起
  "policy-descriptor": "...",          // 临时策略，优先于 policy
  insecure: true,                      // 不校验证书
  "auto-redirect": true,
  "auto-cookie": true,
  "binary-mode": false,
  "full-header-mode": false
}
```

回调：`error` 成功时为 null；`response` 含 `status` 与 `headers`；`data` 为字符串或 Uint8Array。

- 脚本发出的请求会出现在流量查看器。
- 单次运行最多 20 个并发；body 上限 iOS 32 MB / Mac 256 MB。

## 7. 其他 API

### $httpAPI

```js
$httpAPI("GET", "/v1/policies", null, function(result) { ... });
```

调用 Surge 自身 HTTP API，无需鉴权；GET 时 body 转 query；回调收到解析后的 JSON。

### $persistentStore

```js
$persistentStore.write("value", "key");  // 注意：data 在前，key 在后
$persistentStore.read("key");             // 不存在返回 null
$persistentStore.write(null, "key");      // 删除
```

- 只存字符串；值上限 iOS 4 MB / Mac 32 MB。
- 省略 key 时，同一 script-path 的脚本共享存储。
- Mac 调试路径：`~/Library/Application Support/com.nssurge.surge-mac/SGJSVMPersistentStore/`。

### $notification

```js
$notification.post(title, subtitle, body, options);
```

options：`action`（`open-url`/`clipboard`）、`url`、`text`、`media-url`、`media-base64` + `media-base64-mime`、`auto-dismiss`、`sound`。

- `notification` 事件脚本内**禁止**再调用 `$notification.post`，否则异常。

### $utils

```js
$utils.geoip(ip)      // ISO 国家代码
$utils.ipasn(ip)      // ASN
$utils.ipaso(ip)      // AS 组织名
$utils.ungzip(uint8)  // gzip 解压，失败返回 null
```

### $surge

```js
$surge.setSelectGroupPolicy("Group", "Proxy");
$surge.selectGroupDetails();            // {groups, decisions}
$surge.retestGroup("Auto", cb);
$surge.setOutboundMode("rule");         // direct / global-proxy / rule
$surge.setHTTPCaptureEnabled(true);
$surge.setRewriteEnabled(true);
$surge.setEnhancedModeEnabled(true);    // Mac
$surge.setCellularModeEnabled(true);    // Mac
$surge.logbook("message");
```

### 其他

- `console.log()`：写入脚本日志；debug 模式下 HTTP 脚本还会写入请求 Notes；单行上限 512 KB。
- `setTimeout(fn, delay)`：最长 24 小时，最多 64 个待执行；脚本结束会取消全部定时器。`clearTimeout` 仅 WebView。

## 8. 各类型输入/输出

### http-request

输入 `$request`：`url`、`method`、`headers`、`body`（requires-body 时）、`id`。

返回：

```js
$done({
  url: "https://new.example.com/path",   // 改 URL（不改 Host，必要时同时改 headers）
  headers: {...},                         // 替换全部请求头
  body: "...",                            // requires-body 时替换
  response: {                             // 直接返回响应，不请求上游
    status: 200,
    headers: {"Content-Type": "application/json"},
    body: '{"ok":true}'
  },
  abort: true                             // 或直接断开
});
```

- body 修改在 chunked 或 `Expect: 100-continue` 请求中不生效。
- 返回的 headers 不能与实际 body 分帧矛盾（错误的 Content-Length 会被拒绝）。

### http-response

输入 `$request`（url/method/headers/id）与 `$response`（status/headers/body）。

返回：`status`、`headers`、`body`（需 requires-body）、`abort`。没有 requires-body 时返回 body 会中止连接。

```js
let body = JSON.parse($response.body);
body.data.ads = [];
$done({body: JSON.stringify(body)});
```

### cron

输入 `$cronexp`。返回被忽略，`$done()` 即可。超过每小时 10 次会触发耗电警告。

### event

输入 `$event.name`、`$event.data`。notification 事件的数据含 title/subtitle/body/identifier/script-options。返回被忽略。

### rule

输入 `$request.hostname/destPort/sourcePort/protocol/processPath/userAgent/url/sourceIP/listenPort/dnsResult`。返回 `{matched: bool}`。

### dns

输入 `$domain`。返回 `{address}`、`{addresses}`、`{server}`、`{servers}`，可带 `ttl`；`$done({})` 回退标准解析。

### generic / Panel

手动运行返回被忽略。作为 Panel 数据源时返回：

```js
$done({
  title: "My Panel",     // 必填
  content: "Hello",
  style: "info",         // good / info / alert / error
  icon: "bolt.horizontal.circle.fill",  // SF Symbol
  "icon-color": "#FF0000"
});
```

## 9. 常用配方

### 9.1 条件短路（不发请求）

```js
if ($request.url.includes("/ads/")) {
  $done({response: {status: 204, headers: {}, body: ""}});
} else {
  $done({});
}
```

### 9.2 改写 JSON 响应

```js
let obj = JSON.parse($response.body);
obj.data = (obj.data || []).filter(x => !x.isAd);
$done({body: JSON.stringify(obj)});
```

### 9.3 捕获 Cookie / Token

```js
const m = ($request.headers.Cookie || "").match(/token=([^;]+)/);
if (m) $persistentStore.write(m[1], "token");
$done({});
```

### 9.4 用存储的 Token 发请求（签到）

```js
const token = $persistentStore.read("token");
$httpClient.post({
  url: "https://api.example.com/checkin",
  headers: {Authorization: "Bearer " + token}
}, function(err, resp, data) {
  $notification.post("签到", err ? "失败" : "成功", err || data);
  $done();
});
```

### 9.5 面板

```js
$httpClient.get("https://api.ipify.org", function(err, resp, data) {
  $done({title: "出口 IP", content: err || data, style: err ? "error" : "info"});
});
```

### 9.6 定时切换策略

```js
$surge.setSelectGroupPolicy("Proxy", "DIRECT");
$done();
```

### 9.7 网络变化

```js
$notification.post("网络变化", $network.wifi.ssid || "蜂窝", $network.dns.join(", "));
$done();
```

## 10. 性能与限制

- `requires-body` 会把整个 body 读入内存；iOS NE 内存有限，可能被系统终止。pattern 尽量窄，只对必要 URL 开 body。
- 超过并行引擎上限的会话排队；排队超过 timeout 即超时。
- 脚本超时默认 5 秒；签到/大文件处理要显式调大。
- 远程脚本会被缓存；开发时用 `debug=true` 或本地路径。
- 远程脚本 = 远程代码执行，只加载可信来源。

## 11. 调试

1. 脚本编辑器直接运行（`$trigger = "editor"`），可给 mock 输入。
2. `debug=true`：本地脚本每次从磁盘重载，console.log 出现在请求 Notes。
3. 日志：设备上的脚本日志，或 Logbook 远程查看。
4. HTTP API：`POST /v1/scripting/evaluate` 执行任意脚本；`POST /v1/scripting/cron/evaluate` 按名称运行 cron 脚本。
5. iOS 长按脚本手动运行；也可用快捷指令。
6. 常见错误：忘记 `$done()`、`$persistentStore.write` 参数顺序反了、在 response 脚本里没开 requires-body 却改 body、header 大小写不一致、`JSON.parse` 未捕获异常。

## 12. 兼容性提示

- Surge 与 Loon 的 API 高度相似（`$httpClient`、`$persistentStore`、`$notification`、`$done`、`$argument`），但 Surge 的 `$persistentStore.write` 是 `(data, key)`，Loon 常见写法可能不同；移植时逐个核对。
- 旧脚本中的 `$httpClient.get(url, cb)` 仍可用。
- `$request.headers` 的键大小写依客户端而定；读取时用不区分大小写的辅助函数更稳。